import 'package:cloud_firestore/cloud_firestore.dart' as fire;
import 'package:diemchat/constatnt/global.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:diemchat/models/groupModel.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:toast/toast.dart';
import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:diemchat/helper/sizeconfig.dart';
import 'package:diemchat/models/user.dart';
import 'package:diemchat/constatnt/Constant.dart';

class CreateGroup1 extends StatefulWidget {
  @override
  SelectBroadcastState createState() {
    return new SelectBroadcastState();
  }
}

class SelectBroadcastState extends State<CreateGroup1> {
  List userlist = [];

  String userId;
  FirebaseDatabase database = new FirebaseDatabase();
  TextEditingController titleController = TextEditingController();
  TextEditingController controller = new TextEditingController();
  ProgressDialog pr;
  String currentUserName;
  String currentUserImage;
  String currentUserToken;
  int badgeCount = 0;

  var userIds = [];
  var userNames = [];
  var userImages = [];
  var userTokens = [];

  Future getUsers() async {
    await fire.FirebaseFirestore.instance
        .collection("users")
        .orderBy("status", descending: true)
        .get()
        .then((value) {
      value.docs.forEach((element) {
        if (element.id != userId) {
          setState(() {
            userlist.add(element);
          });
        }
      });
    });
  }

  FirebaseAuth _auth = FirebaseAuth.instance;
  @override
  void initState() {
    super.initState();

    userId = _auth.currentUser.uid;

    getUsers();
  }

  var check = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.only(top: 25),
        child: Material(
          elevation: 10,
          child: Container(
            child: Column(
              children: <Widget>[
                Container(
                  height: SizeConfig.blockSizeVertical * 15,
                  child: Column(
                    children: <Widget>[
                      Padding(
                        padding:
                            const EdgeInsets.only(left: 20, right: 20, top: 15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            InkWell(
                              onTap: () {
                                Navigator.pop(context);
                              },
                              child: Text(
                                'Cancel',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: appColorBlue,
                                ),
                              ),
                            ),
                            Text(
                              'Katılımcı Ekle',
                              style: TextStyle(
                                fontSize: 16,
                                fontFamily: "MontserratBold",
                                color: appColorBlack,
                              ),
                            ),
                            InkWell(
                              onTap: () {
                                if (userIds.length > 1) {
                                  createGroup(context);
                                }
                              },
                              child: Text(
                                'Create',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: appColorBlue,
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Padding(
                          padding: const EdgeInsets.only(right: 15, left: 15),
                          child: Container(
                            decoration: new BoxDecoration(
                                color: Colors.green,
                                borderRadius: new BorderRadius.all(
                                  Radius.circular(15.0),
                                )),
                            height: 40,
                            child: Center(
                              child: TextField(
                                controller: controller,
                                onChanged: onSearchTextChanged,
                                style: TextStyle(color: Colors.grey),
                                decoration: new InputDecoration(
                                  border: new OutlineInputBorder(
                                    borderSide:
                                        new BorderSide(color: Colors.grey[200]),
                                    borderRadius: const BorderRadius.all(
                                      const Radius.circular(15.0),
                                    ),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide:
                                        new BorderSide(color: Colors.grey[200]),
                                    borderRadius: const BorderRadius.all(
                                      const Radius.circular(15.0),
                                    ),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide:
                                        new BorderSide(color: Colors.grey[200]),
                                    borderRadius: const BorderRadius.all(
                                      const Radius.circular(15.0),
                                    ),
                                  ),
                                  filled: true,
                                  hintStyle: new TextStyle(
                                      color: Colors.grey[600], fontSize: 14),
                                  hintText: "Search",
                                  contentPadding: EdgeInsets.only(top: 10.0),
                                  fillColor: Colors.grey[200],
                                  prefixIcon: Icon(
                                    Icons.search,
                                    color: Colors.grey[600],
                                    size: 25.0,
                                  ),
                                ),
                              ),
                            ),
                          )),
                    ],
                  ),
                ),
                mainWidget()
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget mainWidget() {
    print(userlist.length);
    return Expanded(
      child: userlist.length != 0
          ? controller.text != ""
              ? ListView.builder(
                  padding: const EdgeInsets.all(0),
                  itemCount: _searchResult.length,
                  itemBuilder: (BuildContext context, int index) {
                    return _searchResult[index].documentID == userId
                        ? Container()
                        : Row(
                            children: [
                              Expanded(
                                child: Column(
                                  children: <Widget>[
                                    new Divider(
                                      height: 1,
                                    ),
                                    new ListTile(
                                      onTap: () {},
                                      leading: new Stack(
                                        children: <Widget>[
                                          (_searchResult[index]["photo"] !=
                                                      null &&
                                                  _searchResult[index]["photo"]
                                                          .length >
                                                      0)
                                              ? CircleAvatar(
                                                  backgroundColor: Colors.grey,
                                                  backgroundImage:
                                                      new NetworkImage(
                                                          _searchResult[index]
                                                              ["photo"]),
                                                )
                                              : CircleAvatar(
                                                  backgroundColor:
                                                      Colors.grey[300],
                                                  child: Image.asset(
                                                    "assets/images/user.png",
                                                    height: 25,
                                                    color: Colors.white,
                                                  )),
                                        ],
                                      ),
                                      title: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          Text(
                                            _searchResult[index]["nick"],
                                            // "",
                                            style: new TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 15),
                                          ),
                                        ],
                                      ),
                                      subtitle: new Container(
                                        padding:
                                            const EdgeInsets.only(top: 5.0),
                                        child: new Row(
                                          children: [
                                            // Text(
                                            //   _searchResult[index].mobile ??
                                            //       "",
                                            //   style: TextStyle(
                                            //       fontWeight:
                                            //           FontWeight.normal,
                                            //       fontSize: 13),
                                            // )
                                            // ItemsTile(c.phones),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              userIds.contains(_searchResult[index].documentID)
                                  ? Padding(
                                      padding: const EdgeInsets.only(right: 20),
                                      child: InkWell(
                                          onTap: () {
                                            setState(() {
                                              userIds.remove(
                                                  _searchResult[index]
                                                      .documentID);
                                              userNames.remove(
                                                  _searchResult[index]["nick"]);
                                              userImages.remove(
                                                  _searchResult[index]
                                                      ["photo"]);
                                              userTokens.remove("1");
                                            });
                                          },
                                          child: Icon(
                                            Icons.check_circle,
                                            color: appColorBlue,
                                          )),
                                    )
                                  : Padding(
                                      padding: const EdgeInsets.only(right: 20),
                                      child: InkWell(
                                          onTap: () {
                                            setState(() {
                                              userIds.add(_searchResult[index]
                                                  .documentID);
                                              userNames.add(
                                                  _searchResult[index]["nick"]);
                                              userImages.add(
                                                  _searchResult[index]
                                                      ["photo"]);
                                              userTokens.add("1");
                                            });
                                          },
                                          child: Icon(
                                            Icons.radio_button_unchecked,
                                            color: appColorGrey,
                                          )),
                                    )
                            ],
                          );

                    // ListTile(
                    //   onTap: () {
                    //     // Navigator.of(context).push(MaterialPageRoute(
                    //     //     builder: (BuildContext context) => ContactDetailsPage(
                    //     //       c,onContactDeviceSave:contactOnDeviceHasBeenUpdated,
                    //     //         )));
                    //   },
                    //   leading: (c.avatar != null && c.avatar.length > 0)
                    //       ? CircleAvatar(backgroundImage: MemoryImage(c.avatar))
                    //       : CircleAvatar(child: Text(c.initials())),
                    //   title: Text(c.displayName ?? ""),
                    // );
                  },
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(0),
                  itemCount: userlist.length,
                  itemBuilder: (BuildContext context, int index) {
                    return userlist[index].documentID == userId
                        ? Container()
                        : Row(
                            children: [
                              Expanded(
                                child: Column(
                                  children: <Widget>[
                                    new Divider(
                                      height: 1,
                                    ),
                                    new ListTile(
                                      onTap: () {},
                                      leading: new Stack(
                                        children: <Widget>[
                                          (userlist[index]["photo"] != null &&
                                                  userlist[index]["photo"]
                                                          .length >
                                                      0)
                                              ? CircleAvatar(
                                                  backgroundColor: Colors.grey,
                                                  backgroundImage:
                                                      new NetworkImage(
                                                          userlist[index]
                                                              ["photo"]),
                                                )
                                              : CircleAvatar(
                                                  backgroundColor:
                                                      Colors.grey[300],
                                                  child: Image.asset(
                                                    "assets/images/user.png",
                                                    height: 25,
                                                    color: Colors.white,
                                                  )),
                                        ],
                                      ),
                                      title: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          Text(
                                            userlist[index]["nick"],
                                            // "",
                                            style: new TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 15),
                                          ),
                                        ],
                                      ),
                                      subtitle: new Container(
                                        padding:
                                            const EdgeInsets.only(top: 5.0),
                                        child: new Row(
                                          children: [
                                            // Text(
                                            //   _searchResult[index].mobile ??
                                            //       "",
                                            //   style: TextStyle(
                                            //       fontWeight:
                                            //           FontWeight.normal,
                                            //       fontSize: 13),
                                            // )
                                            // ItemsTile(c.phones),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              userIds.contains(userlist[index].documentID)
                                  ? Padding(
                                      padding: const EdgeInsets.only(right: 20),
                                      child: InkWell(
                                          onTap: () {
                                            setState(() {
                                              userIds.remove(
                                                  userlist[index].documentID);
                                              userNames.remove(
                                                  userlist[index]["nick"]);
                                              userImages.remove(
                                                  userlist[index]["photo"]);
                                              userTokens.remove("1");
                                            });
                                          },
                                          child: Icon(
                                            Icons.check_circle,
                                            color: appColorBlue,
                                          )),
                                    )
                                  : Padding(
                                      padding: const EdgeInsets.only(right: 20),
                                      child: InkWell(
                                          onTap: () {
                                            setState(() {
                                              userIds.add(
                                                  userlist[index].documentID);
                                              userNames
                                                  .add(userlist[index]["nick"]);
                                              userImages.add(
                                                  userlist[index]["photo"]);
                                              userTokens.add("1");
                                            });
                                          },
                                          child: Icon(
                                            Icons.radio_button_unchecked,
                                            color: appColorGrey,
                                          )),
                                    )
                            ],
                          );

                    // ListTile(
                    //   onTap: () {
                    //     // Navigator.of(context).push(MaterialPageRoute(
                    //     //     builder: (BuildContext context) => ContactDetailsPage(
                    //     //       c,onContactDeviceSave:contactOnDeviceHasBeenUpdated,
                    //     //         )));
                    //   },
                    //   leading: (c.avatar != null && c.avatar.length > 0)
                    //       ? CircleAvatar(backgroundImage: MemoryImage(c.avatar))
                    //       : CircleAvatar(child: Text(c.initials())),
                    //   title: Text(c.displayName ?? ""),
                    // );
                  },
                )

          // ListTile(
          //   onTap: () {
          //     // Navigator.of(context).push(MaterialPageRoute(
          //     //     builder: (BuildContext context) => ContactDetailsPage(
          //     //       c,onContactDeviceSave:contactOnDeviceHasBeenUpdated,
          //     //         )));
          //   },
          //   leading: (c.avatar != null && c.avatar.length > 0)
          //       ? CircleAvatar(backgroundImage: MemoryImage(c.avatar))
          //       : CircleAvatar(child: Text(c.initials())),
          //   title: Text(c.displayName ?? ""),
          // );

          : Center(
              child: CircularProgressIndicator(),
            ),
    );
  }

  void createGroup(BuildContext context) {
    showGeneralDialog(
        context: context,
        barrierDismissible: true,
        barrierLabel:
            MaterialLocalizations.of(context).modalBarrierDismissLabel,
        barrierColor: Colors.black45,
        transitionDuration: const Duration(milliseconds: 200),
        pageBuilder: (BuildContext buildContext, Animation animation,
            Animation secondaryAnimation) {
          return StatefulBuilder(
              builder: (BuildContext context, StateSetter setState1) {
            return Center(
              child: Container(
                width: 300,
                height: 200,
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Material(
                        child: Text(
                      'Enter Name of Group',
                      style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          fontFamily: "MontserratBold",
                          fontSize: SizeConfig.blockSizeHorizontal * 3.8),
                    )),
                    SizedBox(
                      height: 10,
                    ),
                    Material(
                      child: CustomtextField(
                        controller: titleController,
                        maxLines: 1,
                        textInputAction: TextInputAction.next,
                        hintText: 'Enter Group name',
                        prefixIcon: Container(
                          margin: EdgeInsets.all(10.0),
                          child: Icon(
                            Icons.campaign,
                            color: Colors.black,
                            size: 20.0,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 10),
                    SizedBox(
                      height: SizeConfig.blockSizeVertical * 5,
                      width: SizeConfig.screenWidth,
                      // ignore: deprecated_member_use
                      child: FlatButton(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        color: appColorGreen,
                        textColor: Colors.white,
                        padding: EdgeInsets.all(8.0),
                        onPressed: () {
                          // if (titleController.text.length > 0) {
                          //   GroupModel model = new GroupModel(userIds, [userId],
                          //       titleController.text, "", "");

                          //   var orderRef =
                          //       database.reference().child("group").push();
                          //   orderRef.set(model.toJson()).then((value) async {
                          //     fire.Firestore.instance
                          //         .collection("chatList")
                          //         .document(userId)
                          //         .collection(userId)
                          //         .document(orderRef.key)
                          //         .setData({
                          //       'id': orderRef.key,
                          //       'name': titleController.text,
                          //       'timestamp': DateTime.now()
                          //           .millisecondsSinceEpoch
                          //           .toString(),
                          //       'content': "you added in a group",
                          //       'badge': '1',
                          //       'profileImage': '',
                          //       'type': 0,
                          //       'archive': false,
                          //       'mute': false,
                          //       'chatType': "group"
                          //     }).then((onValue) async {});

                          //     for (var i = 0; i <= userIds.length; i++) {
                          //       fire.Firestore.instance
                          //           .collection("chatList")
                          //           .document(userIds[i])
                          //           .collection(userIds[i])
                          //           .document(orderRef.key)
                          //           .setData({
                          //         'id': orderRef.key,
                          //         'name': titleController.text,
                          //         'timestamp': DateTime.now()
                          //             .millisecondsSinceEpoch
                          //             .toString(),
                          //         'content': "you added in a group",
                          //         'badge': '1',
                          //         'profileImage': '',
                          //         'type': 0,
                          //         'archive': false,
                          //         'mute': false,
                          //         'chatType': "group"
                          //       }).then((onValue) async {
                          //         Navigator.of(context)
                          //             .pushReplacementNamed(APP_SCREEN);
                          //         //  Navigator.pop(context);
                          //         // Navigator.push(
                          //         //   context,
                          //         //   MaterialPageRoute(
                          //         //       builder: (context) => TabbarScreen()),
                          //         // );
                          //       });
                          //     }
                          //   });
                          //   print(orderRef.key);
                          // } else {
                          //   Toast.show("Enter group name", context,
                          //       duration: Toast.LENGTH_SHORT,
                          //       gravity: Toast.BOTTOM);
                          // }
                        },
                        child: Text(
                          "CREATE",
                          style: TextStyle(
                              fontSize: 14.0, fontFamily: "MontserratBold"),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            );
          });
        });
  }

  getUserData() async {
    final FirebaseDatabase database = new FirebaseDatabase();

    database.reference().child('user').child(userId).once().then((peerData) {
      setState(() {
        currentUserName = peerData.value['name'];
        currentUserImage = peerData.value['img'];
        currentUserToken = peerData.value['token'];

        userIds.add(userId);
        userNames.add(currentUserName);
        userImages.add(currentUserImage);
        userTokens.add(currentUserToken);
      });
    });
  }

  String searchQuery;
  onSearchTextChanged(String text) async {
    if (text.isEmpty) {
      setState(() {});
      return;
    }

    await FirebaseFirestore.instance.collection("users").get().then((value) {
      _searchResult.clear();
      searchQuery = text;
      value.docs.forEach((element) {
        if (element.id != userId) {
          if (element["nick"].toLowerCase().contains(text.toLowerCase()) ||
              element["bio"].toLowerCase().contains(text.toLowerCase())) {
            setState(() {
              _searchResult.add(element);
            });
          }
        }
      });
      // setState(() {
      //   searchList = searchList.where((s) {
      //     s["nick"]
      //         .toLowerCase()
      //         .contains(query.toLowerCase());
      //     return s["bio"]
      //         .toLowerCase()
      //         .contains(query.toLowerCase());
      //   }).toList();

      // });
    });

    setState(() {});
  }
}

List _searchResult = [];
