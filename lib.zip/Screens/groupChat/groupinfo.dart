import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:diemchat/constatnt/Constant.dart';
import 'package:diemchat/constatnt/global.dart';
import 'package:diemchat/helper/sizeconfig.dart';
import 'package:diemchat/models/groupModel.dart';

import 'package:cloud_firestore/cloud_firestore.dart' as cloud;

import '../mediaScreen.dart';
import '../staredMsg.dart';
import 'editGroup.dart';

// ignore: must_be_immutable
class GroupInfo extends StatefulWidget {
  String groupName;
  String groupKey;
  var ids;
  var imageMedia;
  var videoMedia;
  var docsMedia;

  GroupInfo(
      {this.groupName,
      this.groupKey,
      this.ids,
      this.imageMedia,
      this.videoMedia,
      this.docsMedia});
  @override
  GroupInfoState createState() {
    return new GroupInfoState();
  }
}

class GroupInfoState extends State<GroupInfo> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  bool _showLoader = true;
  FirebaseDatabase database = new FirebaseDatabase();
  String userId;
  String groupName = '';
  String groupImage = '';
  String groupDescription = '';
  var newPersonId = [];
  FirebaseAuth _auth = FirebaseAuth.instance;
  @override
  void initState() {
    userId = _auth.currentUser.uid;

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: appColorWhite,
          title: Text(
            "Group Bilgisi",
            style: TextStyle(
                fontFamily: "MontserratBold",
                fontSize: 17,
                color: appColorBlack),
          ),
          centerTitle: true,
          leading: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: Icon(
                Icons.arrow_back_ios,
                color: appColorBlue,
              )),
          actions: <Widget>[
            Container(
              width: 80,
              child: Padding(
                padding: const EdgeInsets.only(right: 15),
                child: IconButton(
                  padding: const EdgeInsets.all(0),
                  icon: CustomText(
                    text: "Düzenle",
                    alignment: Alignment.centerLeft,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    color: appColorBlue,
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => EditGroup(
                              groupName: groupName,
                              groupImage: groupImage,
                              groupDescription: groupDescription,
                              groupIds: widget.ids,
                              groupKey: widget.groupKey)),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
        body: _body());
  }

  Widget _body() {
    return StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection("groop")
            .doc(widget.groupKey)
            .snapshots(),
        builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.hasData) {
            groupName = snapshot.data["groupName"];
            groupImage = snapshot.data["groupImage"];
            return Container(
              color: bgcolor,
              child: Column(
                children: [
                  groupImage.length > 3
                      ? Image.network(
                          groupImage,
                          height: SizeConfig.blockSizeVertical * 30,
                          width: SizeConfig.screenWidth,
                          fit: BoxFit.cover,
                        )
                      : Container(),
                  Padding(
                    padding: const EdgeInsets.only(top: 0),
                    child: Container(
                      color: bgcolor,
                      child: Column(
                        children: <Widget>[
                          Container(
                            height: SizeConfig.blockSizeVertical * 8,
                            child: Center(
                              child: ListTile(
                                title: new Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: <Widget>[
                                    Expanded(
                                      flex: 3,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: <Widget>[
                                          new Text(
                                            snapshot.data["groupName"],
                                            style: new TextStyle(
                                                fontSize: SizeConfig
                                                        .blockSizeHorizontal *
                                                    4,
                                                fontWeight: FontWeight.bold,
                                                fontFamily: "MontserratBold",
                                                color: Colors.black),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: <Widget>[
                                          ClipOval(
                                            child: Material(
                                              color: Colors.white,
                                              child: InkWell(
                                                child: SizedBox(
                                                    width: 40,
                                                    height: 40,
                                                    child: Padding(
                                                      padding:
                                                          const EdgeInsets.all(
                                                              8.0),
                                                      child: Image.asset(
                                                        "assets/images/chat.png",
                                                        color: appColorBlue,
                                                      ),
                                                    )),
                                                onTap: () {
                                                  Navigator.pop(context);
                                                },
                                              ),
                                            ),
                                          ),
                                          // ClipOval(
                                          //   child: Material(
                                          //     color: Colors
                                          //         .grey[100], // button color
                                          //     child: InkWell(
                                          //       child: SizedBox(
                                          //           width: 40,
                                          //           height: 40,
                                          //           child: Padding(
                                          //             padding:
                                          //                 const EdgeInsets
                                          //                     .all(8.0),
                                          //             child: Image.asset(
                                          //               "assets/images/video_fill.png",
                                          //               color: appColorBlue,
                                          //             ),
                                          //           )),
                                          //       onTap: () {},
                                          //     ),
                                          //   ),
                                          // ),
                                          // ClipOval(
                                          //   child: Material(
                                          //     color: Colors
                                          //         .grey[100], // button color
                                          //     child: InkWell(
                                          //       child: SizedBox(
                                          //           width: 40,
                                          //           height: 40,
                                          //           child: Padding(
                                          //             padding:
                                          //                 const EdgeInsets
                                          //                     .all(10),
                                          //             child: Image.asset(
                                          //               "assets/images/grey_call.png",
                                          //               color: appColorBlue,
                                          //             ),
                                          //           )),
                                          //       onTap: () {},
                                          //     ),
                                          //   ),
                                          // ),
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => MediaScreen(
                                        imageMedia: widget.imageMedia,
                                        videoMedia: widget.videoMedia,
                                        docsMedia: widget.docsMedia)),
                              );
                            },
                            child: Container(
                              height: SizeConfig.blockSizeVertical * 6,
                              child: Center(
                                child: ListTile(
                                  title: new Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: <Widget>[
                                      Expanded(
                                        child: new Text(
                                          'Medya, Linkler ve Dokümanlar ',
                                          style: new TextStyle(
                                              fontSize: SizeConfig
                                                      .blockSizeHorizontal *
                                                  3.7,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.black),
                                        ),
                                      ),
                                      Icon(
                                        Icons.arrow_forward_ios,
                                        color: Colors.grey,
                                        size: 20,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Divider(
                            thickness: 1,
                          ),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 0),
                    child: Container(
                      child: Column(
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              Container(
                                  width: SizeConfig.screenWidth,
                                  color: bgcolor,
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        left: 20, top: 20, bottom: 10),
                                    child: Text(
                                      snapshot.data["joins"].length.toString() +
                                          ' katılımcı',
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  )),
                            ],
                          ),
                          Container(height: 0.5, color: Colors.grey),

                          // snapshot.data["createrId"].contains(userId)
                          //     ? ListTile(
                          //         leading: new Stack(
                          //           children: <Widget>[
                          //             InkWell(
                          //               child: Container(
                          //                   height: 40,
                          //                   width: 40,
                          //                   decoration: BoxDecoration(
                          //                       color: Colors.grey[300],
                          //                       shape: BoxShape.circle),
                          //                   child: Padding(
                          //                     padding:
                          //                         const EdgeInsets.all(8.0),
                          //                     child: Icon(
                          //                       Icons.add,
                          //                       color: appColorBlue,
                          //                     ),
                          //                   )),
                          //             ),
                          //           ],
                          //         ),
                          //         title: new Row(
                          //           mainAxisAlignment:
                          //               MainAxisAlignment.spaceBetween,
                          //           children: <Widget>[
                          //             new Text(
                          //               "Add Participants",
                          //               style: new TextStyle(
                          //                   fontWeight: FontWeight.bold,
                          //                   color: appColorBlue,
                          //                   fontSize: 14),
                          //             ),
                          //           ],
                          //         ),
                          //       )
                          //     : Container(),
                          Container(height: 0.5, color: Colors.grey),

                          Container(
                            child: ListView.builder(
                              padding: EdgeInsets.only(top: 0),
                              itemCount: snapshot.data["joins"].length,
                              physics: NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              itemBuilder: (context, index2) {
                                return groupWidget(snapshot.data, index2);
                              },
                            ),
                          ),
                          Container(height: 30),
                          // Container(height: 0.5, color: Colors.grey),
                          // Container(
                          //   color: Colors.white,
                          //   height: SizeConfig.blockSizeVertical * 6,
                          // ),
                          // Container(height: 0.5, color: Colors.grey),
                          // Container(
                          //   height: SizeConfig.blockSizeVertical * 6,
                          //   child: Center(
                          //     child: ListTile(
                          //       title: new Row(
                          //         children: <Widget>[
                          //           Expanded(
                          //             child: new Text(
                          //               'Exit Group',
                          //               style: new TextStyle(
                          //                   fontSize: SizeConfig
                          //                           .blockSizeHorizontal *
                          //                       3.5,
                          //                   fontWeight: FontWeight.bold,
                          //                   color: Colors.red),
                          //             ),
                          //           ),
                          //         ],
                          //       ),
                          //     ),
                          //   ),
                          // ),
                          // Container(height: 0.5, color: Colors.grey),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          }
          return Container();
        });
  }
}

Widget groupWidget(var ids, int index2) {
  return Container(
    color: Colors.white,
    child: Column(
      children: [
        StreamBuilder(
          stream: FirebaseFirestore.instance
              .collection("users")
              .doc(ids["joins"][index2])
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              return ListTile(
                leading: new Stack(
                  children: <Widget>[
                    InkWell(
                      onLongPress: () {},
                      child: snapshot.data["photo"] != ""
                          ? Container(
                              height: 40,
                              width: 40,
                              child: CircleAvatar(
                                //radius: 60,
                                foregroundColor: Theme.of(context).primaryColor,
                                backgroundColor: Colors.grey,
                                backgroundImage:
                                    new NetworkImage(snapshot.data["photo"]),
                              ),
                            )
                          : Container(
                              height: 40,
                              width: 40,
                              decoration: BoxDecoration(
                                  color: Colors.grey[300],
                                  shape: BoxShape.circle),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Icon(Icons.person),
                              )),
                    ),
                  ],
                ),
                title: new Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    new Text(
                      snapshot.data["nick"],
                      style: new TextStyle(fontWeight: FontWeight.bold),
                    ),
                    ids["createrId"].contains(snapshot.data.id)
                        ? Text(
                            "admin",
                            style: TextStyle(fontSize: 13),
                          )
                        : Container()
                  ],
                ),
                // subtitle: new Container(
                //   padding: const EdgeInsets.only(top: 5.0),
                //   child: new Text(
                //     'busy',
                //     style: new TextStyle(
                //         color: Colors.grey, fontSize: 15.0),
                //   ),
                // ),
              );
            }
            return Container(
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              alignment: Alignment.center,
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.max,
                  children: <Widget>[
                    CupertinoActivityIndicator(),
                  ]),
            );
          },
        ),
        Container(
          height: 0.3,
          color: Colors.grey,
        )
      ],
    ),
  );
}

  // void _settingModalBottomSheet(context, adminIds, peerId, allIds) {
  //   showModalBottomSheet(
  //       context: context,
  //       builder: (BuildContext bc) {
  //         return Container(
  //           child: new Wrap(
  //             children: <Widget>[
  //               // Center(
  //               //     child: new ListTile(
  //               //         title: Center(child: new Text('Info')),
  //               //         onTap: () => {})),
  //               // new ListTile(
  //               //   title: Center(child: new Text('Chat')),
  //               //   onTap: () => {},
  //               // ),
  //               adminIds.contains(peerId)
  //                   ? ListTile(
  //                       title: Center(child: new Text('Yöneticilikten çıkart')),
  //                       onTap: () {
  //                         var newAdminsIds = [];
  //                         newAdminsIds.addAll(adminIds);
  //                         newAdminsIds.remove(peerId);
  //                         DatabaseReference _userRef = database
  //                             .reference()
  //                             .child('group')
  //                             .child(widget.groupKey);
  //                         _userRef.update({
  //                           "createrId": newAdminsIds,
  //                         }).then((_) {
  //                           setState(() {
  //                             Navigator.pop(context);
  //                           });
  //                         });
  //                       },
  //                     )
  //                   : ListTile(
  //                       title: Center(child: new Text('Make Group Admin')),
  //                       onTap: () {
  //                         var newAdminsIds = [];
  //                         newAdminsIds.addAll(adminIds);
  //                         newAdminsIds.add(peerId);

  //                         DatabaseReference _userRef = database
  //                             .reference()
  //                             .child('group')
  //                             .child(widget.groupKey);
  //                         _userRef.update({
  //                           "createrId": newAdminsIds,
  //                         }).then((_) {
  //                           setState(() {
  //                             Navigator.pop(context);
  //                           });
  //                         });
  //                       },
  //                     ),
  //               ListTile(
  //                 title: Center(
  //                     child: new Text(
  //                   'Gruptan çıkart',
  //                   style: TextStyle(color: Colors.red),
  //                 )),
  //                 onTap: () {
  //                   Navigator.pop(context);
  //                   var newAdminsIds = [];
  //                   newAdminsIds.addAll(allIds);
  //                   newAdminsIds.remove(peerId);

  //                   DatabaseReference _userRef = database
  //                       .reference()
  //                       .child('group')
  //                       .child(widget.groupKey);
  //                   _userRef.update({
  //                     "userId": newAdminsIds,
  //                   }).then((_) {
  //                     cloud.Firestore.instance
  //                         .collection("chatList")
  //                         .document(peerId)
  //                         .collection(peerId)
  //                         .document(widget.groupKey)
  //                         .delete()
  //                         .then((value) {
  //                       setState(() {
  //                         _body();
  //                       });
  //                     });
  //                   });
  //                 },
  //               ),
  //               Center(
  //                 child: Padding(
  //                   padding: const EdgeInsets.only(bottom: 20),
  //                   child: new RawMaterialButton(
  //                     onPressed: () {
  //                       Navigator.pop(context);
  //                     },
  //                     elevation: 2.0,
  //                     fillColor: Colors.grey[300],
  //                     child: Icon(
  //                       Icons.close,
  //                       size: 20.0,
  //                     ),
  //                     padding: EdgeInsets.all(15.0),
  //                     shape: CircleBorder(),
  //                   ),
  //                 ),
  //               ),
  //             ],
  //           ),
  //         );
  //       });
  // }

  // addParticipants(allUsersId, groupName, groupImage) {
  //   showModalBottomSheet(
  //       context: context,
  //       shape: RoundedRectangleBorder(),
  //       isScrollControlled: true,
  //       backgroundColor: Colors.transparent,
  //       builder: (context) {
  //         return StatefulBuilder(
  //             builder: (BuildContext context, StateSetter setState1) {
  //           return DraggableScrollableSheet(
  //             initialChildSize: 0.6,
  //             builder:
  //                 (BuildContext context, ScrollController scrollController) {
  //               return SingleChildScrollView(
  //                 controller: scrollController,
  //                 child: Container(
  //                   height: 1200,
  //                   decoration: BoxDecoration(
  //                     borderRadius: BorderRadius.only(
  //                       topLeft: Radius.circular(20.0),
  //                       topRight: Radius.circular(20.0),
  //                     ),
  //                     color: Colors.white,
  //                   ),
  //                   child: Column(
  //                     children: <Widget>[
  //                       Container(
  //                         decoration: BoxDecoration(
  //                           borderRadius: BorderRadius.only(
  //                             topLeft: Radius.circular(20.0),
  //                             topRight: Radius.circular(20.0),
  //                           ),
  //                         ),
  //                         height: 60,
  //                         child: Padding(
  //                           padding: const EdgeInsets.only(
  //                               left: 15, right: 15, top: 5),
  //                           child: Row(
  //                             mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                             children: [
  //                               InkWell(
  //                                   onTap: () {
  //                                     Navigator.pop(context);
  //                                   },
  //                                   child: Text(
  //                                     "İptal",
  //                                     textAlign: TextAlign.start,
  //                                     style: TextStyle(color: appColorBlue),
  //                                   )),
  //                               Text(
  //                                 "Katılımcı Ekle",
  //                                 maxLines: 1,
  //                                 overflow: TextOverflow.ellipsis,
  //                                 textAlign: TextAlign.center,
  //                                 style: TextStyle(
  //                                     fontSize: 16,
  //                                     fontWeight: FontWeight.bold,
  //                                     fontStyle: FontStyle.normal,
  //                                     color: Colors.black),
  //                               ),
  //                               newPersonId.length > 0
  //                                   ? InkWell(
  //                                       onTap: () {
  //                                         for (var i = 0;
  //                                             i < newPersonId.length;
  //                                             i++) {
  //                                           cloud.Firestore.instance
  //                                               .collection("chatList")
  //                                               .document(newPersonId[i])
  //                                               .collection(newPersonId[i])
  //                                               .document(widget.groupKey)
  //                                               .setData({
  //                                             'id': widget.groupKey,
  //                                             'name': groupName,
  //                                             'timestamp': DateTime.now()
  //                                                 .millisecondsSinceEpoch
  //                                                 .toString(),
  //                                             'content': "you added in a group",
  //                                             'badge': '1',
  //                                             'profileImage': groupImage,
  //                                             'type': 0,
  //                                             'archive': false,
  //                                             'mute': false,
  //                                             'chatType': "group"
  //                                           }).then((onValue) async {
  //                                             newPersonId.addAll(allUsersId);

  //                                             DatabaseReference _userRef =
  //                                                 database
  //                                                     .reference()
  //                                                     .child('group')
  //                                                     .child(widget.groupKey);
  //                                             _userRef.update({
  //                                               "userId": newPersonId
  //                                                   .toSet()
  //                                                   .toList(),
  //                                             }).then((_) {
  //                                               setState(() {
  //                                                 _showLoader = true;
  //                                                 callFunction();
  //                                                 _body();
  //                                                 Navigator.pop(context);
  //                                               });
  //                                             });
  //                                           });
  //                                         }
  //                                       },
  //                                       child: Padding(
  //                                         padding:
  //                                             const EdgeInsets.only(right: 10),
  //                                         child: Text(
  //                                           "Ekle",
  //                                           textAlign: TextAlign.start,
  //                                           style: TextStyle(
  //                                             color: appColorBlue,
  //                                             fontWeight: FontWeight.bold,
  //                                           ),
  //                                         ),
  //                                       ))
  //                                   : Padding(
  //                                       padding:
  //                                           const EdgeInsets.only(right: 10),
  //                                       child: Text(
  //                                         "Ekle",
  //                                         textAlign: TextAlign.start,
  //                                         style: TextStyle(
  //                                           color: Colors.grey,
  //                                           fontWeight: FontWeight.bold,
  //                                         ),
  //                                       ),
  //                                     )
  //                             ],
  //                           ),
  //                         ),
  //                       ),
  //                       Container(
  //                         height: 500,
  //                         child: FutureBuilder(
  //                           future: FirebaseDatabase.instance
  //                               .reference()
  //                               .child("user")
  //                               .once(),
  //                           builder: (context, snapshot) {
  //                             if (snapshot.hasData) {
  //                               var lists = [];
  //                               Map<dynamic, dynamic> values =
  //                                   snapshot.data.value;
  //                               values.forEach((key, values) {
  //                                 lists.add(values);
  //                               });
  //                               return ListView.builder(
  //                                 itemCount: lists.length,
  //                                 itemBuilder:
  //                                     (BuildContext context, int index) {
  //                                   return allUsersId
  //                                           .contains(lists[index]["userId"])
  //                                       ? Container()
  //                                       : userId == lists[index]["userId"]
  //                                           ? Container()
  //                                           : Row(
  //                                               children: [
  //                                                 Expanded(
  //                                                   child: Column(
  //                                                     children: <Widget>[
  //                                                       new Divider(
  //                                                         height: 1,
  //                                                       ),
  //                                                       new ListTile(
  //                                                         onTap: () {},
  //                                                         leading: new Stack(
  //                                                           children: <Widget>[
  //                                                             (lists[index]["img"] !=
  //                                                                         null &&
  //                                                                     lists[index]["img"]
  //                                                                             .length >
  //                                                                         0)
  //                                                                 ? CircleAvatar(
  //                                                                     backgroundColor:
  //                                                                         Colors
  //                                                                             .grey,
  //                                                                     backgroundImage:
  //                                                                         new NetworkImage(lists[index]
  //                                                                             [
  //                                                                             "img"]),
  //                                                                   )
  //                                                                 : CircleAvatar(
  //                                                                     backgroundColor:
  //                                                                         Colors.grey[
  //                                                                             300],
  //                                                                     child:
  //                                                                         Text(
  //                                                                       "",
  //                                                                       style: TextStyle(
  //                                                                           color: Colors
  //                                                                               .green,
  //                                                                           fontSize:
  //                                                                               20,
  //                                                                           fontWeight:
  //                                                                               FontWeight.bold),
  //                                                                     )),
  //                                                           ],
  //                                                         ),
  //                                                         title: new Row(
  //                                                           mainAxisAlignment:
  //                                                               MainAxisAlignment
  //                                                                   .spaceBetween,
  //                                                           children: <Widget>[
  //                                                             new Text(
  //                                                               lists[index][
  //                                                                       "name"] ??
  //                                                                   "",
  //                                                               style: new TextStyle(
  //                                                                   fontWeight:
  //                                                                       FontWeight
  //                                                                           .bold),
  //                                                             ),
  //                                                           ],
  //                                                         ),
  //                                                         subtitle:
  //                                                             new Container(
  //                                                           padding:
  //                                                               const EdgeInsets
  //                                                                       .only(
  //                                                                   top: 5.0),
  //                                                           child: new Row(
  //                                                             children: [
  //                                                               Text(lists[
  //                                                                       index]
  //                                                                   ["mobile"])
  //                                                               // ItemsTile(c.phones),
  //                                                             ],
  //                                                           ),
  //                                                         ),
  //                                                       ),
  //                                                     ],
  //                                                   ),
  //                                                 ),
  //                                                 newPersonId.contains(
  //                                                         lists[index]
  //                                                             ["userId"])
  //                                                     ? InkWell(
  //                                                         onTap: () {},
  //                                                         child: IconButton(
  //                                                           onPressed: () {
  //                                                             setState1(() {
  //                                                               newPersonId.remove(
  //                                                                   lists[index]
  //                                                                       [
  //                                                                       "userId"]);
  //                                                             });
  //                                                           },
  //                                                           icon: Icon(
  //                                                             Icons
  //                                                                 .check_circle,
  //                                                             color:
  //                                                                 appColorBlue,
  //                                                             size: 28,
  //                                                           ),
  //                                                         ))
  //                                                     : IconButton(
  //                                                         onPressed: () {
  //                                                           setState1(() {
  //                                                             newPersonId.add(
  //                                                                 lists[index][
  //                                                                     "userId"]);
  //                                                           });
  //                                                         },
  //                                                         icon: Icon(
  //                                                           Icons
  //                                                               .radio_button_off_outlined,
  //                                                           color: Colors.grey,
  //                                                           size: 28,
  //                                                         ),
  //                                                       ),
  //                                                 Container(
  //                                                   width: 20,
  //                                                 )
  //                                               ],
  //                                             );
  //                                 },
  //                               );
  //                             }
  //                             return Container(
  //                               height: MediaQuery.of(context).size.height,
  //                               width: MediaQuery.of(context).size.width,
  //                               alignment: Alignment.center,
  //                               child: Column(
  //                                   mainAxisAlignment: MainAxisAlignment.center,
  //                                   crossAxisAlignment:
  //                                       CrossAxisAlignment.center,
  //                                   mainAxisSize: MainAxisSize.max,
  //                                   children: <Widget>[
  //                                     CupertinoActivityIndicator(),
  //                                   ]),
  //                             );
  //                           },
  //                         ),
  //                       ),
  //                     ],
  //                   ),
  //                 ),
  //               );
  //             },
  //           );
  //         });
  //       });
  // }

