import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:diemchat/constatnt/global.dart';
import 'package:diemchat/helper/sizeconfig.dart';
import 'package:image_picker/image_picker.dart';
import 'package:toast/toast.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;

// ignore: must_be_immutable
class EditGroup extends StatefulWidget {
  String groupName;
  String groupImage;
  String groupDescription;
  var groupIds;
  String groupKey;

  EditGroup(
      {this.groupName,
      this.groupImage,
      this.groupDescription,
      this.groupIds,
      this.groupKey});
  @override
  _EditProfileState createState() => _EditProfileState();
}

class _EditProfileState extends State<EditGroup> {
  String userId;
  bool isLoading = false;
  final TextEditingController nameController = TextEditingController();
  File _image;
  Future getImage() async {
    // ignore: unused_local_variable
    final picker = ImagePicker();
    final imageFile =
        await picker.getImage(source: ImageSource.gallery, imageQuality: 50);

    if (imageFile != null) {
      setState(() {
        if (imageFile != null) {
          _image = File(imageFile.path);
        } else {
          print('No image selected.');
        }
      });
    }
  }

  FirebaseAuth _auth = FirebaseAuth.instance;
  @override
  void initState() {
    nameController.text = widget.groupName;

    setState(() {
      userId = _auth.currentUser.uid;
      //getUserData();
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
        appBar: AppBar(
          backgroundColor: appColorWhite,
          title: Text(
            "Group Bilgisi",
            style: TextStyle(
                fontFamily: "MontserratBold",
                fontSize: 17,
                color: appColorBlack),
          ),
          centerTitle: true,
          leading: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: Icon(
                Icons.arrow_back_ios,
                color: appColorBlue,
              )),
          actions: [
            Container(
              width: 80,
              child: Padding(
                padding: const EdgeInsets.only(right: 15),
                child: IconButton(
                    padding: EdgeInsets.all(0),
                    onPressed: () {
                      if (nameController.text.isNotEmpty) {
                        updateInfo();
                        Navigator.pop(context);
                      }
                    },
                    icon: Text(
                      "Tamam",
                      style: TextStyle(
                          color: appColorBlue, fontFamily: "MontserratBold"),
                    )),
              ),
            ),
          ],
        ),
        body: Stack(
          children: <Widget>[
            isLoading == true ? Center(child: loader()) : _userInfo(),
          ],
        ));
  }

  Widget _userInfo() {
    return SingleChildScrollView(
      padding: EdgeInsets.symmetric(horizontal: 0),
      child: Column(
        children: <Widget>[
          Container(height: 20),
          Padding(
            padding: const EdgeInsets.only(left: 20, right: 20),
            child: Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(100.0),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(3),
                        child: GestureDetector(
                          onTap: () {
                            getImage();
                          },
                          child: CircleAvatar(
                            backgroundImage: _image != null
                                ? FileImage(_image)
                                : widget.groupImage.length > 3
                                    ? NetworkImage("${widget.groupImage}")
                                    : AssetImage(
                                        "assets/images/${widget.groupImage}.png"),
                            radius: 40,
                          ),
                        ),
                      ),
                    ),
                    Container(width: 15),
                    Expanded(
                        child: Text(
                      "Grup adını girin ve isteğe bağlı bir grup resmi ekleyin",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 13,
                        color: appColorBlack,
                      ),
                    ))
                  ],
                ),
                Container(height: 5),
                Padding(
                  padding: const EdgeInsets.only(left: 15),
                  child: Row(
                    children: [
                      Text(
                        "Düzenle",
                        style: TextStyle(
                            color: appColorBlue,
                            fontWeight: FontWeight.bold,
                            fontSize: 13),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(height: 15),
          Container(
            height: 0.5,
            color: Colors.grey[400],
          ),
          Padding(
            padding: const EdgeInsets.only(left: 15),
            child: CustomtextField3(
                textAlign: TextAlign.start,
                controller: nameController,
                maxLines: 2,
                textInputAction: TextInputAction.next,
                hintText: 'Grup İsmi'),
          ),
          Container(
            height: 0.5,
            color: Colors.grey[400],
          ),
          Container(height: 40),
        ],
      ),
    );
  }

  updateInfo() async {
    setState(() {
      isLoading = true;
    });

    if (_image != null) {
      String fileName = DateTime.now().millisecondsSinceEpoch.toString();

      String imageLocation =
          'User Image/${_auth.currentUser.uid}/${DateTime.now().millisecondsSinceEpoch.toString()}';

      await firebase_storage.FirebaseStorage.instance
          .ref(imageLocation)
          .putFile(_image);
      String downloadUrl = await firebase_storage.FirebaseStorage.instance
          .ref(imageLocation)
          .getDownloadURL();

      var timeKey = new DateTime.now();

      FirebaseFirestore.instance
          .collection("groop")
          .doc(widget.groupKey)
          .update({
        "groupName": nameController.text.trim(),
        "groupImage": downloadUrl.toString(),
      }).then((value) {
        Toast.show("Updated Sucesssfully", context,
            duration: Toast.LENGTH_SHORT, gravity: Toast.BOTTOM);
        setState(() {
          isLoading = false;
        });
      });
    } else {
      FirebaseFirestore.instance
          .collection("groop")
          .doc(widget.groupKey)
          .update({
        "groupName": nameController.text.trim(),
      }).then((value) {
        Toast.show("Updated Sucesssfully", context,
            duration: Toast.LENGTH_SHORT, gravity: Toast.BOTTOM);
        setState(() {
          isLoading = false;
        });
      });
    }
    // getUserData();
  }
}
