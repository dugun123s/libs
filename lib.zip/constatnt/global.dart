import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

const Color appColorGreen = Color(0XFF4354AE);
const Color chatLeftColor = Colors.white;
const Color chatRightColor = Color.fromRGBO(234, 30, 99, 1);
const Color chatReplyRightColor = Colors.white;
const Color appColorBlue = Color.fromRGBO(234, 30, 99, 1);
const Color appColor = Color.fromRGBO(234, 30, 99, 1);
const Color appColorBlack = Colors.black;
const Color appColorWhite = Colors.white;
const Color appColorGrey = Colors.black;
Color chatLeftTextColor = Colors.black;
const Color chatRightTextColor = Colors.white;

String normalStyle = 'Montserrat';

const Color settingColoryellow = Color(0xFFf6cd00);
const Color settingColorGreen = Color(0xFFf00aca6);
const Color settingColorBlue = Color(0xFF007dff);
const Color settingColorRed = Color(0xFFff3429);
const Color settingColorpink = Color(0xFFff2b54);
const Color settingColorChat = Color(0xFF47d86a);

const Color callColor1 = Color(0XFF738464);
const Color callColor2 = Color(0XFF9b7573);

String userID = '';
String mobNo = '';
String cCode = '';
String fullMob = '';
String globalName = '';
String globalImage = '';
String serverKey =
    "AAAA49bf9IQ:APA91bFnbLZOiRzcmUGgeYeAFZLeaYPgKaIcqSSxuJmD4aEe6nKTfKk4J3nsvtJWNgwyV7M58WZ9RH1d6mcwQRIZz6i4oiOIh77U8Wdt7GGZq-w0tfKElc7wVKoIk38E40LqF2Xgz0lS";
String noImage =
    'https://www.searchpng.com/wp-content/uploads/2019/02/Deafult-Profile-Pitcher.png';

String videoImage =
    'https://old.dpsu.gov.ua/templates/scms_default/images/noVideo.jpg';

var mobileContacts = [];

List<String> localImage = [];
var savedContactUserId = [];

class CustomText extends StatelessWidget {
  final String text;
  final Color color;
  final double fontSize;
  final FontWeight fontWeight;
  final Alignment alignment;
  final String fontFamily;

  const CustomText(
      {Key key,
      this.text,
      this.color,
      this.fontSize,
      this.fontWeight,
      this.alignment,
      this.fontFamily})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Align(
        alignment: alignment,
        child: Text(' $text',
            style: TextStyle(
                color: color,
                fontSize: fontSize,
                fontWeight: fontWeight,
                fontFamily: fontFamily)));
  }
}

class CustomButtom extends StatelessWidget {
  final Color color;
  final String title;
  final Function onPressed;
  final double fontSize;
  final FontWeight fontWeight;
  final Color textColor;
  final BorderRadius borderRadius;
  final String fontFamily;
  CustomButtom(
      {this.color,
      this.title,
      this.onPressed,
      this.fontSize,
      this.fontWeight,
      this.textColor,
      this.borderRadius,
      this.fontFamily});
  @override
  Widget build(BuildContext context) {
    // ignore: deprecated_member_use
    return RaisedButton(
      color: color,
      child: Text(
        title,
        style: TextStyle(
            fontSize: fontSize,
            fontWeight: fontWeight,
            color: textColor,
            fontFamily: fontFamily),
      ),
      shape: RoundedRectangleBorder(
        borderRadius: borderRadius,
      ),
      onPressed: onPressed,
    );
  }
}

Widget loader() {
  return Container(
    height: 60,
    width: 60,
    padding: EdgeInsets.all(15.0),
    decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10), color: Colors.transparent),
    child: CircularProgressIndicator(
        valueColor: AlwaysStoppedAnimation<Color>(Colors.blue)),
  );
}

// ignore: must_be_immutable
class CustomtextField extends StatefulWidget {
  final TextInputType keyboardType;
  final Function onTap;
  final FocusNode focusNode;
  final TextInputAction textInputAction;
  final Function onEditingComplate;
  final Function onSubmitted;
  final dynamic controller;
  final int maxLines;
  final dynamic onChange;
  final String errorText;
  final String hintText;
  final String labelText;
  bool obscureText = false;
  bool readOnly = false;
  bool autoFocus = false;
  final Widget suffixIcon;

  final Widget prefixIcon;
  CustomtextField({
    this.keyboardType,
    this.onTap,
    this.focusNode,
    this.textInputAction,
    this.onEditingComplate,
    this.onSubmitted,
    this.controller,
    this.maxLines,
    this.onChange,
    this.errorText,
    this.hintText,
    this.labelText,
    this.obscureText = false,
    this.readOnly = false,
    this.autoFocus = false,
    this.prefixIcon,
    this.suffixIcon,
  });

  @override
  _CustomtextFieldState createState() => _CustomtextFieldState();
}

class _CustomtextFieldState extends State<CustomtextField> {
  @override
  Widget build(BuildContext context) {
    return TextField(
      focusNode: widget.focusNode,
      readOnly: widget.readOnly,
      textInputAction: widget.textInputAction,
      onTap: widget.onTap,
      autofocus: widget.autoFocus,
      maxLines: widget.maxLines,
      onEditingComplete: widget.onEditingComplate,
      onSubmitted: widget.onSubmitted,
      obscureText: widget.obscureText,
      keyboardType: widget.keyboardType,
      controller: widget.controller,
      onChanged: widget.onChange,
      style: TextStyle(
          color: Colors.black, fontFamily: 'Montserrat', fontSize: 14),
      cursorColor: Colors.black,
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.grey[200],
        prefixIcon: widget.prefixIcon,
        suffixIcon: widget.suffixIcon,
        labelText: widget.labelText,
        contentPadding:
            const EdgeInsets.symmetric(vertical: 15.0, horizontal: 20),
        errorStyle: TextStyle(color: Colors.black),
        errorText: widget.errorText,
        focusedErrorBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.black),
          borderRadius: BorderRadius.circular(5),
        ),
        hintText: widget.hintText,
        focusColor: Colors.black,
        labelStyle: TextStyle(color: Colors.black),
        hintStyle: TextStyle(
            color: Colors.grey[600], fontFamily: "Montserrat", fontSize: 13),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: appColorGreen, width: 1.8),
          borderRadius: BorderRadius.circular(5),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.white, width: 0.5),
          borderRadius: BorderRadius.circular(5),
        ),
      ),
    );
  }
}

// ignore: must_be_immutable
class CustomtextField3 extends StatefulWidget {
  final TextInputType keyboardType;
  final Function onTap;
  final FocusNode focusNode;
  final TextInputAction textInputAction;
  final Function onEditingComplate;
  final Function onSubmitted;
  final dynamic controller;
  final int maxLines;
  final dynamic onChange;
  final String errorText;
  final String hintText;
  final String labelText;
  bool obscureText = false;
  bool readOnly = false;
  bool autoFocus = false;
  final Widget suffixIcon;
  final textAlign;

  final Widget prefixIcon;
  CustomtextField3(
      {this.keyboardType,
      this.onTap,
      this.focusNode,
      this.textInputAction,
      this.onEditingComplate,
      this.onSubmitted,
      this.controller,
      this.maxLines,
      this.onChange,
      this.errorText,
      this.hintText,
      this.labelText,
      this.obscureText = false,
      this.readOnly = false,
      this.autoFocus = false,
      this.prefixIcon,
      this.suffixIcon,
      this.textAlign});

  @override
  _CustomtextFieldState3 createState() => _CustomtextFieldState3();
}

class _CustomtextFieldState3 extends State<CustomtextField3> {
  @override
  Widget build(BuildContext context) {
    return TextField(
      textAlign: widget.textAlign,
      focusNode: widget.focusNode,
      readOnly: widget.readOnly,
      textInputAction: widget.textInputAction,
      onTap: widget.onTap,
      autofocus: widget.autoFocus,
      maxLines: widget.maxLines,
      onEditingComplete: widget.onEditingComplate,
      onSubmitted: widget.onSubmitted,
      obscureText: widget.obscureText,
      keyboardType: widget.keyboardType,
      controller: widget.controller,
      onChanged: widget.onChange,
      style: TextStyle(
          color: Colors.black, fontSize: 16, fontWeight: FontWeight.bold),
      cursorColor: Colors.black,
      decoration: InputDecoration(
        filled: false,
        //  fillColor: Colors.black.withOpacity(0.5),
        prefixIcon: widget.prefixIcon,
        suffixIcon: widget.suffixIcon,
        labelText: widget.labelText,
        contentPadding: const EdgeInsets.symmetric(vertical: 10, horizontal: 0),
        errorStyle: TextStyle(color: Colors.white),
        errorText: widget.errorText,

        focusedErrorBorder: UnderlineInputBorder(
          borderSide: BorderSide(color: Colors.red),
        ),
        hintText: widget.hintText,
        labelStyle: TextStyle(color: Colors.white),
        hintStyle: TextStyle(color: Colors.grey[600], fontSize: 13),

        focusedBorder: UnderlineInputBorder(
          borderSide: BorderSide(color: Colors.transparent),
        ),
        enabledBorder: UnderlineInputBorder(
          borderSide: BorderSide(color: Colors.transparent),
        ),
        border: UnderlineInputBorder(
          borderSide: BorderSide(color: Colors.transparent),
        ),
        // focusedBorder: OutlineInputBorder(
        //   borderSide: BorderSide(color: Colors.white, width: 1.8),
        //   borderRadius: BorderRadius.circular(10),
        // ),
        // enabledBorder: OutlineInputBorder(
        //   borderSide: BorderSide(color: Colors.white, width: 0.5),
        //   borderRadius: BorderRadius.circular(10),
        // ),
      ),
    );
  }
}
