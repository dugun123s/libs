import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:diemchat/story/editor.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:diemchat/Screens/chat.dart';
import 'package:diemchat/Screens/contactinfo.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:diemchat/constatnt/Constant.dart';
import 'package:diemchat/story/myStatus.dart';
import 'package:diemchat/story/penStatusScreen.dart';
import 'package:diemchat/constatnt/global.dart';
import 'package:diemchat/helper/sizeconfig.dart';
import 'package:diemchat/story/sendImageStory.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:async';
import 'package:dashed_circle/dashed_circle.dart';
import 'package:diemchat/story/store_page_view.dart';
import 'package:timeago/timeago.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shimmer/shimmer.dart';

class Status extends StatefulWidget {
  @override
  _StatusState createState() => _StatusState();
}

class _StatusState extends State<Status> with SingleTickerProviderStateMixin {
  bool isLoading = true;
  Animation gap;
  Animation base;
  Animation reverse;
  AnimationController controller;
  var scaffoldKey = GlobalKey<ScaffoldState>();
  String userId;
  // ignore: unused_field

  //APP BAR SCROLL
  bool _showAppbar = true;
  ScrollController _scrollBottomBarController = new ScrollController();
  bool isScrollingDown = false;

  List myPostList = [];
  List postList = [];
  var muteUsers = [];
  bool showMute = false;
  List<DocumentSnapshot> stories = [];
  FirebaseAuth _auth = FirebaseAuth.instance;
  Future getUsers() async {
    // });
    await FirebaseFirestore.instance
        .collection("storyUser")
        .orderBy("timestamp", descending: true)
        .where("timestamp",
            isGreaterThan: DateTime.now().subtract(Duration(days: 1)))
        .get()
        .then((value) {
        
      stories.clear();
      value.docs.forEach((element) {
        if (element.id != _auth.currentUser.uid) {
          stories.add(element);
        }
      });
      setState(() {
        stories.shuffle();
        isLoading = false;
      });
    });
  }

  Future getPhoto() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    globalImage = prefs.getString("photo");
    globalName = prefs.getString("nick");
    setState(() {});
  }

  @override
  void initState() {
    getUsers();
    getPhoto();
    // getContactsFromGloble();
    myScroll();

    userId = _auth.currentUser.uid;
    setState(() {
      isLoading = false;
    });

    controller =
        AnimationController(vsync: this, duration: Duration(seconds: 4));
    base = CurvedAnimation(parent: controller, curve: Curves.easeOut);
    reverse = Tween<double>(begin: 0.0, end: -1.0).animate(base);
    gap = Tween<double>(begin: 3.0, end: 0.0).animate(base)
      ..addListener(() {
        setState(() {});
      });
    controller.forward();

    super.initState();
  }

  getMuteUsers() async {
    muteUsers = [];
    SharedPreferences preferences1 = await SharedPreferences.getInstance();
    if (preferences1.containsKey("mute" + userId)) {
      setState(() {
        muteUsers = preferences1.getStringList("mute" + userId);

        print("MUTE USERS:");
        print(muteUsers);
        bodyWidget();
      });
    }
  }

  @override
  void dispose() {
    controller.dispose();
    _scrollBottomBarController.removeListener(() {});

    super.dispose();
  }

  void showBottomBar() {
    setState(() {});
  }

  void hideBottomBar() {
    setState(() {});
  }

  void myScroll() async {
    _scrollBottomBarController.addListener(() {
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        if (!isScrollingDown) {
          isScrollingDown = true;
          _showAppbar = false;
          hideBottomBar();
        }
      }
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.forward) {
        if (isScrollingDown) {
          isScrollingDown = false;
          _showAppbar = true;
          showBottomBar();
        }
      }
    });
  }

  File _image;
  // ignore: missing_return
  Future<void> getimageditor() {
    // ignore: unused_local_variable
  }

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
        backgroundColor: bgcolor,
        // appBar: AppBar(
        //   title: _showAppbar
        //       ? Container()
        //       : Text(
        //           "Status",
        //           style: TextStyle(
        //               fontFamily: "MontserratBold",
        //               fontSize: 17,
        //               color: appColorBlack),
        //         ),
        //   centerTitle: true,
        //   elevation: _showAppbar ? 0 : 1,
        //   backgroundColor: Colors.grey[100],
        //   automaticallyImplyLeading: false,
        // ),
        body: isLoading == true ? Center(child: loader()) : bodyWidget());
  }

  Widget bodyWidget() {
    return SingleChildScrollView(
      controller: _scrollBottomBarController,
      child: Container(
        color: bgcolor,
        child: Column(
          children: <Widget>[
            SizedBox(
              height: MediaQuery.of(context).padding.top,
            ),
            // admobWidget(),
            // Container(
            //   height: 0.5,
            //   color: Colors.grey[400],
            // ),
            myStatusWidget(),
            Container(
              height: 0.5,
              color: Colors.grey[400],
            ),
            Container(
              color: bgcolor,
              child: Row(
                children: [
                  Padding(
                    padding:
                        const EdgeInsets.only(left: 15, top: 10, bottom: 10),
                    child: Text(
                      'SON GÜNCELLEMELER',
                      style: TextStyle(
                          fontSize: SizeConfig.blockSizeHorizontal * 3,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 0.5,
              color: Colors.grey[400],
            ),
            Container(
              height: MediaQuery.of(context).size.height / 1.35,
              child: instaStories(),
            ),
          ],
        ),
      ),
    );
  }

  Widget myStatusWidget() {
    return StreamBuilder(
      stream: FirebaseFirestore.instance
          .collection("storyUser")
          .where(FieldPath.documentId, isEqualTo: userId)
          .snapshots(),
      builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
        return snapshot.hasData && snapshot.data.docs.length > 0
            ? ListView.builder(
                padding: const EdgeInsets.all(0),
                itemCount: snapshot.data.docs.length,
                shrinkWrap: true,
                itemBuilder: (context, int index) {
                  myPostList = snapshot.data.docs;
                  timeInfo(snapshot.data.docs, index,
                      snapshot.data.docs[index]["userId"]);
                  return myPostList[index]["story"].toString() == "[]" &&
                          myPostList[index]["userId"] != userId
                      ? Container()
                      : Container(
                          color: Colors.white,
                          height: SizeConfig.blockSizeVertical * 12,
                          child: Center(
                            child: Row(
                              children: [
                                Expanded(
                                  child: ListTile(
                                    onTap: () {
                                      List listImage = [];
                                      for (var i = 0;
                                          i < myPostList[index]["story"].length;
                                          i++) {
                                        listImage
                                            .add(myPostList[index]["story"][i]);
                                      }

                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => StoryPageView(
                                                context,
                                                images: listImage,
                                                peerId: myPostList[index]
                                                    ["userId"],
                                                userId: userId)),
                                      );
                                    },
                                    leading: Container(
                                      height: 70,
                                      width: 70,
                                      child: new Stack(
                                        children: <Widget>[
                                          CachedNetworkImage(
                                            imageUrl: myPostList[index]["story"]
                                                        [myPostList[index]
                                                                    ["story"]
                                                                .length -
                                                            1]["type"] ==
                                                    "image"
                                                ? myPostList[index]["story"][
                                                    myPostList[index]["story"]
                                                            .length -
                                                        1]["image"]
                                                : videoImage,
                                            imageBuilder:
                                                (context, imageProvider) =>
                                                    CircleAvatar(
                                              radius: 30,
                                              backgroundImage: imageProvider,
                                            ),
                                            placeholder: (context, url) =>
                                                Shimmer.fromColors(
                                                    baseColor:
                                                        Colors.grey.shade300,
                                                    highlightColor:
                                                        Colors.grey.shade100,
                                                    enabled: true,
                                                    child: Container(
                                                      width: 40,
                                                      height: 40,
                                                    )),
                                            errorWidget:
                                                (context, url, error) =>
                                                    Icon(Icons.error),
                                          ),
                                        ],
                                      ),
                                    ),
                                    title: new Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: <Widget>[
                                        new Text(
                                          'Durumum',
                                          style: new TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontFamily: "MontserratBold",
                                          ),
                                        ),
                                      ],
                                    ),
                                    subtitle: new Container(
                                      padding: const EdgeInsets.only(top: 5.0),
                                      child: new Text(
                                        format(
                                          myPostList[index]["timestamp"]
                                              .toDate(),
                                        ),
                                        style: new TextStyle(
                                            color: Colors.grey, fontSize: 14.0),
                                      ),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(right: 20),
                                  child: Row(
                                    children: <Widget>[
                                      // CircleAvatar(
                                      //   radius: 20,
                                      //   backgroundColor: Colors.white,
                                      //   child: IconButton(
                                      //     icon: Icon(
                                      //       Icons.photo_camera,
                                      //       size: 20,
                                      //       color: Colors.green,
                                      //     ),
                                      //     onPressed: () {
                                      //       // getImage(context, globalName,
                                      //       //     globalImage);
                                      //       // openCameraMenu(context);
                                      //     },
                                      //   ),
                                      // ),
                                      // SizedBox(
                                      //   width:
                                      //       SizeConfig.blockSizeHorizontal * 1,
                                      // ),
                                      CircleAvatar(
                                        radius: 20,
                                        backgroundColor: Colors.grey[200],
                                        child: IconButton(
                                          icon: Icon(
                                            Icons.photo_camera,
                                            size: 20,
                                            color: appColorBlue,
                                          ),
                                          onPressed: () {
                                            openDeleteDialog(context);
                                          },
                                        ),
                                      ),
                                      SizedBox(
                                        width:
                                            SizeConfig.blockSizeHorizontal * 1,
                                      ),
                                      CircleAvatar(
                                        radius: 20,
                                        backgroundColor: Colors.grey[200],
                                        child: IconButton(
                                          icon: Icon(
                                            Icons.edit,
                                            size: 20,
                                            color: appColorBlue,
                                          ),
                                          onPressed: () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      PenStatusScreen()),
                                            );
                                          },
                                        ),
                                      ),
                                      SizedBox(
                                        width:
                                            SizeConfig.blockSizeHorizontal * 1,
                                      ),
                                      CircleAvatar(
                                        radius: 20,
                                        backgroundColor: Colors.grey[200],
                                        child: IconButton(
                                          icon: Icon(
                                            Icons.visibility,
                                            size: 20,
                                            color: appColorBlue,
                                          ),
                                          onPressed: () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      MyStatus()),
                                            );
                                          },
                                        ),
                                      ),
                                      SizedBox(
                                        width:
                                            SizeConfig.blockSizeHorizontal * 1,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                },
              )
            : Container(
                color: Colors.white,
                height: SizeConfig.blockSizeVertical * 12,
                child: Center(
                  child: Row(
                    children: [
                      Expanded(
                        child: ListTile(
                          leading: Container(
                            height: 70,
                            width: 70,
                            child: new Stack(
                              children: <Widget>[
                                globalImage.length > 0
                                    ? CachedNetworkImage(
                                        imageUrl: globalImage,
                                        imageBuilder:
                                            (context, imageProvider) =>
                                                CircleAvatar(
                                          radius: 30,
                                          backgroundImage: imageProvider,
                                        ),
                                        placeholder: (context, url) =>
                                            Shimmer.fromColors(
                                                baseColor: Colors.grey.shade300,
                                                highlightColor:
                                                    Colors.grey.shade100,
                                                enabled: true,
                                                child: Container(
                                                  width: 40,
                                                  height: 40,
                                                )),
                                        errorWidget: (context, url, error) =>
                                            Icon(Icons.error),
                                      )
                                    : Container(
                                        height: 65,
                                        width: 65,
                                        decoration: BoxDecoration(
                                            color: Colors.grey[400],
                                            shape: BoxShape.circle),
                                        child: Padding(
                                          padding: const EdgeInsets.all(10.0),
                                          child: Image.asset(
                                            "assets/images/user.png",
                                            height: 10,
                                            color: Colors.white,
                                          ),
                                        )),
                                Positioned(
                                    bottom: 0.9,
                                    right: 10,
                                    child: Container(
                                        height: 20,
                                        width: 20,
                                        decoration: BoxDecoration(
                                            color: appColorBlue,
                                            shape: BoxShape.circle),
                                        child: Icon(
                                          Icons.add,
                                          color: appColorWhite,
                                          size: 18,
                                        ))),
                              ],
                            ),
                          ),
                          title: new Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              new Text(
                                'Durumum',
                                style: new TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontFamily: "MontserratBold",
                                ),
                              ),
                            ],
                          ),
                          subtitle: new Container(
                            padding: const EdgeInsets.only(top: 5.0),
                            child: new Text(
                              'Durum Ekle',
                              style: new TextStyle(
                                  color: Colors.grey, fontSize: 14.0),
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 20),
                        child: Row(
                          children: <Widget>[
                            new CircleAvatar(
                              radius: 20,
                              backgroundColor: Colors.grey[200],
                              child: IconButton(
                                icon: Icon(
                                  Icons.photo_camera,
                                  size: 20,
                                  color: appColorBlue,
                                ),
                                onPressed: () {
                                  openDeleteDialog(context);
                                },
                              ),
                            ),
                            // SizedBox(
                            //   width: SizeConfig.blockSizeHorizontal * 1.5,
                            // ),
                            // SizedBox(
                            //   width: SizeConfig.blockSizeHorizontal * 1,
                            // ),
                            // CircleAvatar(
                            //   radius: 20,
                            //   backgroundColor: Colors.white,
                            //   child: IconButton(
                            //     icon: Icon(
                            //       Icons.image,
                            //       size: 23,
                            //       color: appColorBlue,
                            //     ),
                            //     onPressed: () {
                            //       // getImage(context, globalName,
                            //       //     globalImage);
                            //       // openMenu(context);
                            //     },
                            //   ),
                            // ),
                            SizedBox(
                              width: SizeConfig.blockSizeHorizontal * 1.5,
                            ),
                            CircleAvatar(
                              radius: 20,
                              backgroundColor: Colors.grey[200],
                              child: IconButton(
                                icon: Icon(
                                  Icons.edit,
                                  size: 20,
                                  color: appColorBlue,
                                ),
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            PenStatusScreen()),
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
      },
    );
  }

  void showDialog(BuildContext context, name, image, phone, id) {
    showGeneralDialog(
      barrierDismissible: true,
      barrierLabel: "Barrier",
      barrierColor: Colors.black.withOpacity(0.5),
      transitionDuration: Duration(milliseconds: 700),
      context: context,
      pageBuilder: (_, __, ___) {
        return Align(
          alignment: Alignment.center,
          child: Container(
            height: SizeConfig.safeBlockVertical * 100,
            width: SizeConfig.screenWidth,
            child: Column(
              children: <Widget>[
                Container(
                    decoration: new BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: new BorderRadius.only(
                          topLeft: const Radius.circular(30.0),
                          topRight: const Radius.circular(30.0),
                        )),
                    height: SizeConfig.safeBlockVertical * 30,
                    width: SizeConfig.screenWidth,
                    child: ClipRRect(
                      borderRadius: BorderRadius.only(
                          topRight: Radius.circular(30.0),
                          topLeft: Radius.circular(30.0)),
                      child: image.length > 0
                          ? Image.network(
                              image,
                              fit: BoxFit.cover,
                            )
                          : Icon(
                              Icons.person,
                              color: Colors.black,
                              size: 50,
                            ),
                    )),
                Material(
                  borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(30.0),
                      bottomLeft: Radius.circular(30.0)),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                          bottomRight: Radius.circular(30.0),
                          bottomLeft: Radius.circular(30.0)),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(left: 20, top: 8),
                          child: Text(
                            name,
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: SizeConfig.blockSizeVertical * 2.5,
                                fontFamily: 'Montserrat'),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 20, top: 10),
                          child: Text(
                            phone,
                            style: TextStyle(
                                fontSize: SizeConfig.blockSizeVertical * 2,
                                color: Colors.grey,
                                fontFamily: 'Montserrat'),
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: <Widget>[
                            phone == ""
                                ? Container()
                                : RawMaterialButton(
                                    onPressed: () {
                                      Navigator.of(context, rootNavigator: true)
                                          .pop();

                                      // Navigator.push(
                                      //     context,
                                      //     CupertinoPageRoute(
                                      //         builder: (context) => Chat(
                                      //               peerID: id,
                                      //             )));
                                    },
                                    elevation: 1,
                                    fillColor: Colors.white,
                                    child: Image.asset(
                                      "assets/images/chat.png",
                                      height: 27,
                                      color: appColorBlue,
                                    ),
                                    shape: CircleBorder(),
                                  ),
                            phone == ""
                                ? Container()
                                : RawMaterialButton(
                                    onPressed: () {
                                      Navigator.of(context, rootNavigator: true)
                                          .pop();
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => ContactInfo(
                                                  id: id,
                                                  currentUser: userId,
                                                )),
                                      );
                                    },
                                    elevation: 1,
                                    fillColor: Colors.white,
                                    child: Icon(
                                      Icons.info,
                                      size: 25.0,
                                      color: appColorBlue,
                                    ),
                                    shape: CircleBorder(),
                                  )
                          ],
                        )
                      ],
                    ),
                  ),
                )
              ],
            ),
            margin: EdgeInsets.only(bottom: 45, left: 18, right: 18, top: 200),
          ),
        );
      },
      transitionBuilder: (_, anim, __, child) {
        return SlideTransition(
          position: Tween(begin: Offset(0, 1), end: Offset(0, 0)).animate(anim),
          child: child,
        );
      },
    );
  }

  RefreshController _refreshController =
      RefreshController(initialRefresh: false);
  void _onRefresh() async {
    // monitor network fetch
    await getUsers();

    // if failed,use refreshFailed()

    _refreshController.refreshCompleted();
  }

  void _onLoading() async {
    // monitor network fetch
    await Future.delayed(Duration(milliseconds: 1000));

    // if failed,use loadFailed(),if no data return,use LoadNodata()
    // items.add((items.length+1).toString());

    _refreshController.loadComplete();
  }

  Widget instaStories() {
    return isLoading
        ? Container(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            alignment: Alignment.center,
            child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  CupertinoActivityIndicator(),
                ]),
          )
        : SmartRefresher(
            enablePullDown: true,
            header: WaterDropHeader(
              complete: Container(),
            ),
            footer: CustomFooter(
              builder: (BuildContext context, LoadStatus mode) {
                Widget body;
                if (mode == LoadStatus.idle) {
                  body = Text("pull up load");
                } else if (mode == LoadStatus.loading) {
                  body = CupertinoActivityIndicator();
                } else if (mode == LoadStatus.failed) {
                  body = Text("Load Failed!Click retry!");
                } else if (mode == LoadStatus.canLoading) {
                  body = Text("release to load more");
                } else {
                  body = Text("No more Data");
                }
                return Container(
                  height: 55.0,
                  child: Center(child: body),
                );
              },
            ),
            controller: _refreshController,
            onRefresh: _onRefresh,
            onLoading: _onLoading,
            child: GridView.count(
                primary: false,
                padding: const EdgeInsets.all(20),
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 11 / 13,
                crossAxisCount: 2,
                children: stories.map<Widget>((post) {
                  return postWidget(post);
                }).toList()));
  }

  Widget postWidget(DocumentSnapshot post) {
    return post["story"].toString() == "[]"
        ? Container()
        : InkWell(
            onTap: () {
              List listImage = [];
              for (var i = 0; i < post["story"].length; i++) {
                listImage.add(post["story"][i]);
              }
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => StoryPageView(context,
                        images: listImage,
                        peerId: post["userId"],
                        userId: userId)),
              );
            },
            child: Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(30),
                      topLeft: Radius.circular(5),
                      bottomRight: Radius.circular(5),
                      bottomLeft: Radius.circular(30))),
              child: Stack(
                children: [
                  CachedNetworkImage(
                    imageUrl: post["story"][post["story"].length - 1]["type"] ==
                            "image"
                        ? post["story"][post["story"].length - 1]["image"]
                        : videoImage,
                    imageBuilder: (context, imageProvider) => Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.only(
                                topRight: Radius.circular(30),
                                topLeft: Radius.circular(5),
                                bottomRight: Radius.circular(5),
                                bottomLeft: Radius.circular(30)),
                            image: DecorationImage(
                              fit: BoxFit.cover,
                              image: imageProvider,
                            ))),
                    placeholder: (context, url) => Shimmer.fromColors(
                        baseColor: Colors.grey.shade300,
                        highlightColor: Colors.grey.shade100,
                        enabled: true,
                        child: Container(
                          width: 40,
                          height: 40,
                        )),
                    errorWidget: (context, url, error) => Icon(Icons.error),
                  ),

                  Center(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 100),
                      child: Column(
                        children: [
                          InkWell(
                            onTap: () async {
                              await FirebaseFirestore.instance
                                  .collection("users")
                                  .doc(post["userId"])
                                  .get()
                                  .then((value) {
                                showDialog(
                                  context,
                                  post["userName"],
                                  post["userImage"],
                                  value["bio"],
                                  post.id,
                                );
                              });
                            },
                            child: RotationTransition(
                              turns: base,
                              child: DashedCircle(
                                gapSize: gap.value,
                                dashes: 20,
                                color: appColorBlue,
                                child: RotationTransition(
                                  turns: reverse,
                                  child: CachedNetworkImage(
                                    imageUrl: post["userImage"],
                                    imageBuilder: (context, imageProvider) =>
                                        CircleAvatar(
                                            radius: 30,
                                            foregroundColor:
                                                Theme.of(context).primaryColor,
                                            backgroundColor: Colors.grey,
                                            backgroundImage: imageProvider),
                                    placeholder: (context, url) =>
                                        Shimmer.fromColors(
                                            baseColor: Colors.white,
                                            highlightColor:
                                                Colors.grey.shade100,
                                            enabled: true,
                                            child: Container(
                                              width: 60,
                                              height: 60,
                                            )),
                                    errorWidget: (context, url, error) =>
                                        Icon(Icons.error),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Container(
                            height: 25,
                            width: post["userName"] == null
                                ? 10
                                : post["userName"].length * 10.toDouble(),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              color: Colors.black.withOpacity(0.25),
                            ),
                            child: Center(
                              child: Text(
                                post["userName"] ?? "",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),

                  // Padding(
                  //   padding: const EdgeInsets.only(right: 10),
                  //   child: ListTile(
                  //     onTap: () {
                  //       List listImage = [];
                  //       for (var i = 0; i < postList[index]["story"].length; i++) {
                  //         listImage.add(postList[index]["story"][i]);
                  //       }
                  //       Navigator.push(
                  //         context,
                  //         MaterialPageRoute(
                  //             builder: (context) => StoryPageView(context,
                  //                 images: listImage,
                  //                 peerId: postList[index]["userId"],
                  //                 userId: userId)),
                  //       );
                  //     },
                  //     onLongPress: () {
                  //       // if (muteUsers.contains(postList[index]["userId"])) {
                  //       //   unMuteMenu(context, postList[index]["userId"]);
                  //       // } else {
                  //       //   muteMenu(context, postList[index]["userId"]);
                  //       // }
                  //     },
                  //     leading: new Stack(
                  //       children: <Widget>[
                  //         RotationTransition(
                  //           turns: base,
                  //           child: DashedCircle(
                  //             gapSize: 2,
                  //             dashes: 20,
                  //             color: appColorBlue,
                  //             child: RotationTransition(
                  //               turns: reverse,
                  //               child: Padding(
                  //                 padding: const EdgeInsets.all(5.0),
                  //                 child: CircleAvatar(
                  //                   foregroundColor: Theme.of(context).primaryColor,
                  //                   backgroundColor: Colors.grey,
                  //                   backgroundImage: new NetworkImage(
                  //                     postList[index]["story"][
                  //                                 postList[index]["story"].length -
                  //                                     1]["type"] ==
                  //                             "image"
                  //                         ? postList[index]["story"][
                  //                             postList[index]["story"].length -
                  //                                 1]["image"]
                  //                         : videoImage,
                  //                   ),
                  //                 ),
                  //               ),
                  //             ),
                  //           ),
                  //         ),
                  //       ],
                  //     ),
                  //     title: new Row(
                  //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //       children: <Widget>[
                  //         new Text(
                  //           postList[index]["userName"],
                  //           style: new TextStyle(
                  //               fontWeight: FontWeight.bold,
                  //               fontFamily: "MontserratBold"),
                  //         ),
                  //       ],
                  //     ),
                  //     subtitle: new Container(
                  //       padding: const EdgeInsets.only(top: 5.0),
                  //       child: new Text(
                  //         format(
                  //           DateTime.fromMillisecondsSinceEpoch(int.parse(
                  //             postList[index]["timestamp"],
                  //           )),
                  //         ),
                  //         style: new TextStyle(color: Colors.grey, fontSize: 14.0),
                  //       ),
                  //     ),
                  //   ),
                  // ),
                ],
              ),
            ),
          );
  }

  timeInfo(orderId, int index, uid) async {
    for (var i = 0; i < orderId[index]["story"].length; i++) {
      // print(orderId[index]["story"][i]["time"]);
      var startTime = orderId[index]["story"][i]["time"].toDate();
      var currentTime = DateTime.now();
      int diff = currentTime.difference(startTime).inDays;

      if (diff >= 1) {
        print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + diff.toString());

        await FirebaseFirestore.instance
            .collection("storyUser")
            .doc(uid)
            .update({
          "story": FieldValue.arrayRemove([orderId[index]["story"][i]])
        }).then((value) {
          print("REMOVE");

          var doc1 =
              FirebaseFirestore.instance.collection("storyUser").doc(uid);
          doc1.get().then((value) async {
            if (value["story"].toString() == "[]") {
              await FirebaseFirestore.instance
                  .collection("storyUser")
                  .doc(uid)
                  .delete();
            }
          }).then((value) {});
        });
      } else {
        // FirebaseFirestore.instance.collection("storyUser").doc(uid).update({
        //   "story": FieldValue.arrayUnion([orderId[index]["story"][i]])
        // }).then((value) {
        //   print("UPDATE");
        // });
      }
    }
  }

  openDeleteDialog(BuildContext context) {
    containerForSheet<String>(
      context: context,
      child: CupertinoActionSheet(
        actions: <Widget>[
          CupertinoActionSheetAction(
            child: Text(
              "Camera",
              style: TextStyle(
                  color: appColorBlack,
                  fontSize: 16,
                  fontFamily: "MontserratBold"),
            ),
            onPressed: () async {
              Navigator.of(context, rootNavigator: true).pop("Discard");

              File _image;
              final picker = ImagePicker();
              final imageFile =
                  await picker.getImage(source: ImageSource.camera);

              if (imageFile != null) {
                setState(() {
                  if (imageFile != null) {
                    _image = File(imageFile.path);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => SendStory(imageFile: _image)),
                    );
                  } else {
                    print('No image selected.');
                  }
                });
              }
            },
          ),
          CupertinoActionSheetAction(
            child: Text(
              "Gallery",
              style: TextStyle(
                  color: appColorBlack,
                  fontSize: 16,
                  fontFamily: "MontserratBold"),
            ),
            onPressed: () async {
              Navigator.of(context, rootNavigator: true).pop("Discard");

              File _image;
              final picker = ImagePicker();
              final imageFile =
                  await picker.getImage(source: ImageSource.gallery);

              if (imageFile != null) {
                setState(() {
                  if (imageFile != null) {
                    _image = File(imageFile.path);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => SendStory(imageFile: _image)),
                    );
                  } else {
                    print('No image selected.');
                  }
                });
              }
            },
          ),
        ],
        cancelButton: CupertinoActionSheetAction(
          child: Text(
            "Cancel",
            style: TextStyle(color: Colors.black, fontFamily: "MontserratBold"),
          ),
          isDefaultAction: true,
          onPressed: () {
            // Navigator.pop(context, 'Cancel');
            Navigator.of(context, rootNavigator: true).pop("Discard");
          },
        ),
      ),
    );
  }

  void containerForSheet<T>({BuildContext context, Widget child}) {
    showCupertinoModalPopup<T>(
      context: context,
      builder: (BuildContext context) => child,
    ).then<void>((T value) {});
  }
}
