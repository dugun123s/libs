import 'package:diemchat/constatnt/global.dart';
import 'package:flutter/material.dart';

class RadioItem extends StatelessWidget {
  final RadioModel _item;
  RadioItem(this._item);
  @override
  Widget build(BuildContext context) {
    return new Container(
      margin: new EdgeInsets.symmetric(vertical: 5, horizontal: 3),
      child: new Row(
        mainAxisSize: MainAxisSize.max,
        children: <Widget>[
          new AnimatedContainer(
            duration: Duration(milliseconds: 300),
            height: 45.0,
            width: _item.isSelected
                ? _item.toString().split('').length * 7.5.toDouble()
                : 50,
            child: !_item.isSelected
                ? Padding(
                  padding: const EdgeInsets.all(6.0),
                  child: Image.asset(
                      'assets/images/${_item.iconData}.png',
                      width: 20,
                      height: 20,
                    ),
                )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Image.asset(
                        'assets/images/${_item.iconData}.png',
                        width: 30,
                        height: 30,
                      ),
                      Text(_item.buttonText,
                          style: new TextStyle(
                              color: _item.isSelected ? appColor : Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 15.0))
                    ],
                  ),
            decoration: new BoxDecoration(
              border: new Border.all(
                  width: 1.0,
                  color: _item.isSelected ? appColor : Colors.grey.shade300),
              borderRadius: const BorderRadius.all(const Radius.circular(12.0)),
            ),
          ),
        ],
      ),
    );
  }
}

class RadioModel {
  bool isSelected;
  final String buttonText;
  final String iconData;
  final String text;

  RadioModel(this.iconData, this.isSelected, this.buttonText, this.text);
}
