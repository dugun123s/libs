// ignore: non_constant_identifier_names
import 'package:flutter/material.dart';

String LOGIN_SCREEN = '/Login',
// ignore: non_constant_identifier_names
    SIGN_UP_SCREEN = '/SignUp',
    // ignore: non_constant_identifier_names
    ANIMATED_SPLASH = '/SplashScreen',
    // ignore: non_constant_identifier_names
    HOME_SCREEN = '/Createprofile',
    // ignore: non_constant_identifier_names
    APP_SCREEN = '/App',

    // ignore: non_constant_identifier_names
    INTOR_SCREEN = '/Intro';

const String CALL_COLLECTION = 'call';
const String USERS_COLLECTION = "users";
//const String APP_ID = "dd195259c4854653be03750ca761a698";
const String APP_ID = "41f50621707047748b968906debf6d46";
const Color appcolor = Color.fromRGBO(234, 30, 99, 1);
const Color bgcolor = Color.fromRGBO(239, 243, 255, 1);
