import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:diemchat/Screens/user_gifts.dart';
import 'package:diemchat/Screens/utils/colors.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:diemchat/Screens/accountoptions.dart';
import 'package:diemchat/Screens/chatoptions.dart';
import 'package:diemchat/Screens/editProfile.dart';
import 'package:diemchat/Screens/staredMsg.dart';
import 'package:diemchat/constatnt/Constant.dart';
import 'package:diemchat/constatnt/global.dart';
import 'package:diemchat/helper/sizeconfig.dart';
import 'package:diemchat/share_preference/preferencesKey.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:share/share.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../app.dart';
import 'admin/admin.dart';
import 'intro.dart';

class SettingOptions extends StatefulWidget {
  @override
  SettingOptionsState createState() {
    return new SettingOptionsState();
  }
}

class SettingOptionsState extends State<SettingOptions> {
  //APP BAR SCROLL
  bool _showAppbar = true;
  ScrollController _scrollBottomBarController = new ScrollController();
  bool isScrollingDown = false;
  // ignore: unused_field
  bool _show = true;
  final FirebaseDatabase _database = FirebaseDatabase.instance;
  Future getPhoto() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    globalImage = prefs.getString("photo");
    globalName = prefs.getString("nick");
    setState(() {});
  }

  @override
  void initState() {
    getPhoto();
    myScroll();

    super.initState();
  }

  @override
  void dispose() {
    _scrollBottomBarController.removeListener(() {});
    super.dispose();
  }

  void showBottomBar() {
    setState(() {
      _show = true;
    });
  }

  void hideBottomBar() {
    setState(() {
      _show = false;
    });
  }

  FirebaseAuth _auth = FirebaseAuth.instance;
  void myScroll() async {
    _scrollBottomBarController.addListener(() {
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        if (!isScrollingDown) {
          isScrollingDown = true;
          _showAppbar = false;
          hideBottomBar();
        }
      }
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.forward) {
        if (isScrollingDown) {
          isScrollingDown = false;
          _showAppbar = true;
          showBottomBar();
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: _showAppbar
            ? Container()
            : Text(
                "Ayarlar",
                style: TextStyle(
                    fontFamily: "MontserratBold",
                    fontSize: 17,
                    color: appColorBlack),
              ),
        centerTitle: true,
        elevation: _showAppbar ? 0 : 1,
        backgroundColor: bgcolor,
        automaticallyImplyLeading: false,
      ),
      body: Container(
        color: bgcolor,
        child: SingleChildScrollView(
          controller: _scrollBottomBarController,
          child: Column(
            children: <Widget>[
              Container(
                color: bgcolor,
                child: Padding(
                  padding: const EdgeInsets.only(left: 20, top: 20, bottom: 10),
                  child: Row(
                    children: <Widget>[
                      Text(
                        'Ayarlar',
                        style: TextStyle(
                            fontSize: SizeConfig.blockSizeHorizontal * 7,
                            fontFamily: "MontserratBold",
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                child: Center(
                  child: Column(
                    children: [
                      Container(
                        height: 0.5,
                        color: Colors.grey[400],
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => EditProfile()),
                          );
                        },
                        child: Padding(
                          padding: const EdgeInsets.only(top: 8, bottom: 8),
                          child: Row(
                            children: [
                              Expanded(
                                child: ListTile(
                                  leading: Container(
                                    height: 70,
                                    width: 70,
                                    child: new Stack(
                                      children: <Widget>[
                                        globalImage.length > 0
                                            ? CircleAvatar(
                                                radius: 30,
                                                backgroundImage:
                                                    NetworkImage(globalImage),
                                              )
                                            : Container(
                                                height: 65,
                                                width: 65,
                                                decoration: BoxDecoration(
                                                    color: Colors.grey[400],
                                                    shape: BoxShape.circle),
                                                child: Padding(
                                                  padding: const EdgeInsets.all(
                                                      10.0),
                                                  child: Image.asset(
                                                    "assets/images/user.png",
                                                    height: 10,
                                                    color: Colors.white,
                                                  ),
                                                )),
                                      ],
                                    ),
                                  ),
                                  title: new Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: <Widget>[
                                      new Text(
                                        globalName ?? "",
                                        style: new TextStyle(
                                            fontFamily: "MontserratBold",
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ],
                                  ),
                                  // subtitle: new Container(
                                  //   padding: const EdgeInsets.only(top: 3),
                                  //   child: new Text(
                                  //     'my status',
                                  //     style: new TextStyle(
                                  //         color: Colors.grey, fontSize: 14),
                                  //   ),
                                  // ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        height: 0.5,
                        color: Colors.grey[400],
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: Column(
                  children: <Widget>[
                    Container(
                      height: 0.5,
                      color: Colors.grey[400],
                    ),
                    Container(
                      height: SizeConfig.blockSizeVertical * 6.4,
                      child: Row(
                        children: [
                          Expanded(
                            child: InkWell(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => AccountOptions()),
                                );
                              },
                              child: ListTile(
                                leading: Container(
                                  decoration: BoxDecoration(
                                      color: settingColorBlue,
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(8))),
                                  child: Padding(
                                    padding: const EdgeInsets.all(4),
                                    child: Icon(
                                      Icons.vpn_key,
                                      size: 23,
                                      color: appColorWhite,
                                    ),
                                  ),
                                ),
                                title: new Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: <Widget>[
                                    new Text(
                                      'Hesap',
                                      style: new TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 0),
                            child: Icon(
                              Icons.arrow_forward_ios,
                              color: appColorGrey,
                              size: 20,
                            ),
                          ),
                          Container(width: 10)
                        ],
                      ),
                    ),
                    Container(
                      height: 0.5,
                      color: Colors.grey[400],
                    ),
                    Container(
                      height: SizeConfig.blockSizeVertical * 6.4,
                      child: Row(
                        children: [
                          Expanded(
                            child: InkWell(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => ChatOptions()),
                                );
                              },
                              child: ListTile(
                                leading: Container(
                                  decoration: BoxDecoration(
                                      color: settingColorChat,
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(8))),
                                  child: Padding(
                                      padding: const EdgeInsets.all(5),
                                      child: Image.asset(
                                        "assets/images/chat2.png",
                                        height: 20,
                                        color: Colors.white,
                                      )),
                                ),
                                title: new Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: <Widget>[
                                    new Text(
                                      'Mesajlar',
                                      style: new TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 0),
                            child: Icon(
                              Icons.arrow_forward_ios,
                              color: appColorGrey,
                              size: 20,
                            ),
                          ),
                          Container(width: 10)
                        ],
                      ),
                    ),
                    // Container(
                    //   height: 0.5,
                    //   color: Colors.grey[400],
                    // ),
                    // Container(
                    //   height: SizeConfig.blockSizeVertical * 6.4,
                    //   child: Row(
                    //     children: [
                    //       Expanded(
                    //         child: InkWell(
                    //           onTap: () {
                    //             Navigator.push(
                    //               context,
                    //               MaterialPageRoute(
                    //                   builder: (context) =>
                    //                       NotificationOptions()),
                    //             );
                    //           },
                    //           child: ListTile(
                    //             leading: Container(
                    //               decoration: BoxDecoration(
                    //                   color: settingColorRed,
                    //                   borderRadius:
                    //                       BorderRadius.all(Radius.circular(8))),
                    //               child: Padding(
                    //                 padding: const EdgeInsets.all(4),
                    //                 child: Icon(
                    //                   Icons.notifications_none,
                    //                   size: 23,
                    //                   color: appColorWhite,
                    //                 ),
                    //               ),
                    //             ),
                    //             title: new Row(
                    //               mainAxisAlignment:
                    //                   MainAxisAlignment.spaceBetween,
                    //               children: <Widget>[
                    //                 new Text(
                    //                   'Notification',
                    //                   style: new TextStyle(
                    //                       fontSize: 16,
                    //                       fontWeight: FontWeight.bold,
                    //                       color: Colors.black),
                    //                 ),
                    //               ],
                    //             ),
                    //           ),
                    //         ),
                    //       ),
                    //       Padding(
                    //         padding: const EdgeInsets.only(top: 0),
                    //         child: Icon(
                    //           Icons.arrow_forward_ios,
                    //           color: appColorGrey,
                    //           size: 20,
                    //         ),
                    //       ),
                    //       Container(width: 10)
                    //     ],
                    //   ),
                    // ),
                    // Container(
                    //   height: 0.5,
                    //   color: Colors.grey[400],
                    // ),
                    // Container(
                    //   height: SizeConfig.blockSizeVertical * 6.4,
                    //   child: Row(
                    //     children: [
                    //       Expanded(
                    //         child: InkWell(
                    //           onTap: () {},
                    //           child: ListTile(
                    //             leading: Container(
                    //               decoration: BoxDecoration(
                    //                   color: settingColorChat,
                    //                   borderRadius:
                    //                       BorderRadius.all(Radius.circular(8))),
                    //               child: Padding(
                    //                   padding: const EdgeInsets.all(5),
                    //                   child: Image.asset(
                    //                     "assets/images/data.png",
                    //                     height: 20,
                    //                     color: Colors.white,
                    //                   )),
                    //             ),
                    //             title: new Row(
                    //               mainAxisAlignment:
                    //                   MainAxisAlignment.spaceBetween,
                    //               children: <Widget>[
                    //                 new Text(
                    //                   'Storage and Data',
                    //                   style: new TextStyle(
                    //                       fontSize: 16,
                    //                       fontWeight: FontWeight.bold,
                    //                       color: Colors.black),
                    //                 ),
                    //               ],
                    //             ),
                    //           ),
                    //         ),
                    //       ),
                    //       Padding(
                    //         padding: const EdgeInsets.only(top: 0),
                    //         child: Icon(
                    //           Icons.arrow_forward_ios,
                    //           color: appColorGrey,
                    //           size: 20,
                    //         ),
                    //       ),
                    //       Container(width: 10)
                    //     ],
                    //   ),
                    // ),
                    // Container(
                    //   height: 0.5,
                    //   color: Colors.grey[400],
                    // ),
                    // Container(
                    //   height: SizeConfig.blockSizeVertical * 6.4,
                    //   child: Row(
                    //     children: [
                    //       Expanded(
                    //         child: InkWell(
                    //           onTap: () {
                    //             Navigator.push(
                    //               context,
                    //               MaterialPageRoute(
                    //                   builder: (context) => HelpOptions()),
                    //             );
                    //           },
                    //           child: ListTile(
                    //             leading: Container(
                    //               decoration: BoxDecoration(
                    //                   color: settingColorBlue,
                    //                   borderRadius:
                    //                       BorderRadius.all(Radius.circular(8))),
                    //               child: Padding(
                    //                   padding: const EdgeInsets.all(8),
                    //                   child: Image.asset(
                    //                     "assets/images/info.png",
                    //                     height: 15,
                    //                     color: Colors.white,
                    //                   )),
                    //             ),
                    //             title: new Row(
                    //               mainAxisAlignment:
                    //                   MainAxisAlignment.spaceBetween,
                    //               children: <Widget>[
                    //                 new Text(
                    //                   'Help',
                    //                   style: new TextStyle(
                    //                       fontSize: 16,
                    //                       fontWeight: FontWeight.bold,
                    //                       color: Colors.black),
                    //                 ),
                    //               ],
                    //             ),
                    //           ),
                    //         ),
                    //       ),
                    //       Padding(
                    //         padding: const EdgeInsets.only(top: 0),
                    //         child: Icon(
                    //           Icons.arrow_forward_ios,
                    //           color: appColorGrey,
                    //           size: 20,
                    //         ),
                    //       ),
                    //       Container(width: 10)
                    //     ],
                    //   ),
                    // ),
                    Container(
                      height: 0.5,
                      color: Colors.grey[400],
                    ),
                    Container(
                      height: SizeConfig.blockSizeVertical * 6.4,
                      child: Row(
                        children: [
                          Expanded(
                            child: InkWell(
                              onTap: () async {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => Admin(
                                   
                                          )),
                                );
                              },
                              child: ListTile(
                                leading: Container(
                                  decoration: BoxDecoration(
                                      color: secondaryDark,
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(8))),
                                  child: Padding(
                                      padding: const EdgeInsets.all(6),
                                      child: Icon(
                                        Icons.settings,
                                        size: 20,
                                        color: Colors.white,
                                      )),
                                ),
                                title: new Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: <Widget>[
                                    new Text(
                                      'Admin',
                                      style: new TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 0),
                            child: Icon(
                              Icons.arrow_forward_ios,
                              color: appColorGrey,
                              size: 20,
                            ),
                          ),
                          Container(width: 10)
                        ],
                      ),
                    ),
                    Container(
                      height: 0.5,
                      color: Colors.grey[400],
                    ),
                    Container(
                      height: SizeConfig.blockSizeVertical * 6.4,
                      child: Row(
                        children: [
                          Expanded(
                            child: InkWell(
                              onTap: () async {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => UserGifts(
                                            userId: _auth.currentUser.uid,
                                          )),
                                );
                              },
                              child: ListTile(
                                leading: Container(
                                  decoration: BoxDecoration(
                                      color: settingColorpink,
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(8))),
                                  child: Padding(
                                      padding: const EdgeInsets.all(6),
                                      child: Image.asset(
                                        "assets/images/like.png",
                                        height: 18,
                                        color: Colors.white,
                                      )),
                                ),
                                title: new Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: <Widget>[
                                    new Text(
                                      'Aldığım Hediyeler',
                                      style: new TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 0),
                            child: Icon(
                              Icons.arrow_forward_ios,
                              color: appColorGrey,
                              size: 20,
                            ),
                          ),
                          Container(width: 10)
                        ],
                      ),
                    ),
                    Container(
                      height: 0.5,
                      color: Colors.grey[400],
                    ),
                    Container(
                      height: SizeConfig.blockSizeVertical * 6.4,
                      child: Row(
                        children: [
                          Expanded(
                            child: InkWell(
                              onTap: () async {
                                Share.share(
                                    "Diem'de sohbet edelim! Birbirimize ücretsiz olarak mesaj atmak ve aramak için kullanabileceğimiz hızlı, basit ve güvenli bir uygulama. Hemen İndir\n https://play.google.com/store/apps/details?id=com.diem.chat");
                              },
                              child: ListTile(
                                leading: Container(
                                  decoration: BoxDecoration(
                                      color: settingColorGreen,
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(8))),
                                  child: Padding(
                                      padding: const EdgeInsets.all(6),
                                      child: Icon(
                                        Icons.share,
                                        color: Colors.white,
                                        size: 18,
                                      )),
                                ),
                                title: new Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: <Widget>[
                                    new Text(
                                      'Arkadaşlarını Davet Et',
                                      style: new TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 0),
                            child: Icon(
                              Icons.arrow_forward_ios,
                              color: appColorGrey,
                              size: 20,
                            ),
                          ),
                          Container(width: 10)
                        ],
                      ),
                    ),
                    Container(
                      height: 0.5,
                      color: Colors.grey[400],
                    ),
                    Container(
                      height: SizeConfig.blockSizeVertical * 6.4,
                      child: Row(
                        children: [
                          Expanded(
                            child: InkWell(
                              onTap: () async {
                                Alert(
                                  context: context,
                                  title: "Çıkış Yap",
                                  desc: "Çıkış yapmak istediğinden emin misin?",
                                  style: AlertStyle(
                                      isCloseButton: false,
                                      descStyle: TextStyle(
                                          fontFamily: "Montserrat",
                                          fontSize: 15),
                                      titleStyle: TextStyle(
                                          fontFamily: "MontserratBold")),
                                  buttons: [
                                    DialogButton(
                                      child: Text(
                                        "Evet",
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 16,
                                            fontFamily: "MontserratBold"),
                                      ),
                                      onPressed: () async {
                                        FirebaseFirestore.instance
                                            .collection("users")
                                            .doc(_auth.currentUser.uid)
                                            .update({
                                          "status":
                                              FieldValue.serverTimestamp(),
                                          "inChat": ""
                                        });

                                        FirebaseAuth.instance.signOut();
                                        SharedPreferences preferences =
                                            await SharedPreferences
                                                .getInstance();
                                        preferences.setString("nick", "");
                                        preferences.setString(
                                          "email",
                                          "",
                                        );
                                        preferences.setString("photo", "");
                                        preferences.setString("nick", "");
                                        preferences
                                            .remove(SharedPreferencesKey
                                                .LOGGED_IN_USERRDATA)
                                            .then((_) {
                                          Navigator.of(context)
                                              .pushAndRemoveUntil(
                                            MaterialPageRoute(
                                              builder: (context) => Intro(),
                                            ),
                                            (Route<dynamic> route) => false,
                                          );
                                        });
                                        Navigator.of(context,
                                                rootNavigator: true)
                                            .pop();
                                      },
                                      color: Color.fromRGBO(0, 179, 134, 1.0),
                                    ),
                                    DialogButton(
                                      child: Text(
                                        "İptal",
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 16,
                                            fontFamily: "MontserratBold"),
                                      ),
                                      onPressed: () {
                                        Navigator.of(context,
                                                rootNavigator: true)
                                            .pop();
                                      },
                                      gradient: LinearGradient(colors: [
                                        Color.fromRGBO(116, 116, 191, 1.0),
                                        Color.fromRGBO(52, 138, 199, 1.0)
                                      ]),
                                    ),
                                  ],
                                ).show();
                              },
                              child: ListTile(
                                leading: Container(
                                  decoration: BoxDecoration(
                                      color: settingColorChat,
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(8))),
                                  child: Padding(
                                    padding: const EdgeInsets.all(6),
                                    child: Icon(
                                      Icons.logout,
                                      size: 18,
                                      color: appColorWhite,
                                    ),
                                  ),
                                ),
                                title: new Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: <Widget>[
                                    new Text(
                                      'Çıkış Yap',
                                      style: new TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black,
                                          fontFamily: "Montserrat"),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 0),
                            child: Icon(
                              Icons.arrow_forward_ios,
                              color: appColorGrey,
                              size: 20,
                            ),
                          ),
                          Container(width: 10)
                        ],
                      ),
                    ),
                    Container(
                      height: 0.5,
                      color: Colors.grey[400],
                    ),
                  ],
                ),
              ),
              // admobWidget(),
              Container(height: 500)
            ],
          ),
        ),
      ),
    );
  }
}
