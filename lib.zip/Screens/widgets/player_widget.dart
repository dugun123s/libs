import 'dart:async';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

enum PlayerState { stopped, playing, paused }
enum PlayingRouteState { speakers, earpiece }

class PlayerWidget extends StatefulWidget {
  final String url;
  final PlayerMode mode;

  PlayerWidget(
      {Key key, @required this.url, this.mode = PlayerMode.MEDIA_PLAYER})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return _PlayerWidgetState(url, mode);
  }
}

class _PlayerWidgetState extends State<PlayerWidget> {
  String url;
  PlayerMode mode;

  _PlayerWidgetState(this.url, this.mode);

  String newUrl = '';

  AudioPlayer _audioPlayer;
  // ignore: unused_field
  PlayerState _audioPlayerState;
  Duration _duration;
  Duration _position;

  PlayerState _playerState = PlayerState.stopped;
  PlayingRouteState _playingRouteState = PlayingRouteState.speakers;
  StreamSubscription _durationSubscription;
  StreamSubscription _positionSubscription;
  StreamSubscription _playerCompleteSubscription;
  StreamSubscription _playerErrorSubscription;
  StreamSubscription _playerStateSubscription;
  StreamSubscription _playerControlCommandSubscription;

  get _isPlaying => _playerState == PlayerState.playing;
  // ignore: unused_element
  get _isPaused => _playerState == PlayerState.paused;
  // ignore: unused_element
  get _durationText => _duration?.toString()?.split('.')?.first ?? '';
  // ignore: unused_element
  get _positionText => _position?.toString()?.split('.')?.first ?? '';

  // ignore: unused_element
  get _isPlayingThroughEarpiece =>
      _playingRouteState == PlayingRouteState.earpiece;

  bool startPlay = false;

  @override
  void initState() {
    super.initState();
    newUrl = url;
    _initAudioPlayer();
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    _durationSubscription?.cancel();
    _positionSubscription?.cancel();
    _playerCompleteSubscription?.cancel();
    _playerErrorSubscription?.cancel();
    _playerStateSubscription?.cancel();
    _playerControlCommandSubscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 30,
      child: Row(
        children: [
          startPlay == false
              ? Container(
                  height: 30,
                  child: IconButton(
                    key: Key('play_button'),
                    onPressed: () {
                      setState(() {
                        startPlay = true;
                      });
                      if (_isPlaying != null) {
                        _play();
                      }
                    },
                    iconSize: 30.0,
                    icon: Icon(Icons.play_arrow),
                    color: Colors.grey,
                  ),
                )
              : Container(
                  height: 30,
                  child: IconButton(
                    key: Key('pause_button'),
                    onPressed: () {
                      setState(() {
                        startPlay = false;
                      });
                      _pause();
                    },
                    iconSize: 30.0,
                    icon: Icon(Icons.pause),
                    color: Colors.grey,
                  ),
                ),
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Slider(
              activeColor: Colors.grey,
              inactiveColor: Colors.grey[200],
              onChanged: (v) {
                // ignore: non_constant_identifier_names
                final Position = v * _duration.inMilliseconds;
                _audioPlayer.seek(Duration(milliseconds: Position.round()));
              },
              value: (_position != null &&
                      _duration != null &&
                      _position.inMilliseconds > 0 &&
                      _position.inMilliseconds < _duration.inMilliseconds)
                  ? _position.inMilliseconds / _duration.inMilliseconds
                  : 0.0,
            ),
          ),
        ],
      ),
    );
  }

  void _initAudioPlayer() {
    _audioPlayer = AudioPlayer(mode: mode);

    _durationSubscription = _audioPlayer.onDurationChanged.listen((duration) {
      setState(() => _duration = duration);

      // if (Theme.of(context).platform == TargetPlatform.iOS) {
      //   _audioPlayer.startHeadlessService();

      //   // _audioPlayer. setNotification(
      //   //   title: 'App Name',
      //   //   artist: 'Artist or blank',
      //   //   albumTitle: 'Name or blank',
      //   //   imageUrl: 'url or blank',
      //   //   // forwardSkipInterval: const Duration(seconds: 30), // default is 30s
      //   //   // backwardSkipInterval: const Duration(seconds: 30), // default is 30s
      //   //   duration: duration,
      //   //   elapsedTime: Duration(seconds: 0),
      //   //   hasNextTrack: true,
      //   //   hasPreviousTrack: false,
      //   // );
      // }
    });

    _positionSubscription =
        _audioPlayer.onAudioPositionChanged.listen((p) => setState(() {
              _position = p;
            }));

    _playerCompleteSubscription =
        _audioPlayer.onPlayerCompletion.listen((event) {
      _onComplete();
      setState(() {
        _position = _duration;
      });
    });

    _playerErrorSubscription = _audioPlayer.onPlayerError.listen((msg) {
      print('audioPlayer error : $msg');
      setState(() {
        _playerState = PlayerState.stopped;
        _duration = Duration(seconds: 0);
        _position = Duration(seconds: 0);
      });
    });

    // _playerControlCommandSubscription =
    //     _audioPlayer.onPlayerCommand.listen((command) {
    //   print('command');
    // });

    // _audioPlayer.onPlayerStateChanged.listen((state) {
    //   if (!mounted) return;
    //   setState(() {
    //     _audioPlayerState = state;
    //   });
    // });

    // _audioPlayer.onNotificationPlayerStateChanged.listen((state) {
    //   if (!mounted) return;
    //   setState(() => _audioPlayerState = state);
    // });

    _playingRouteState = PlayingRouteState.speakers;
  }

  Future<int> _play() async {
    final playPosition = (_position != null &&
            _duration != null &&
            _position.inMilliseconds > 0 &&
            _position.inMilliseconds < _duration.inMilliseconds)
        ? _position
        : null;
    final result = await _audioPlayer.play(newUrl, position: playPosition);
    if (result == 1) setState(() => _playerState = PlayerState.playing);

    // default playback rate is 1.0
    // this should be called after _audioPlayer.play() or _audioPlayer.resume()
    // this can also be called everytime the user wants to change playback rate in the UI
    _audioPlayer.setPlaybackRate(1.0);

    return result;
  }

  Future<int> _pause() async {
    final result = await _audioPlayer.pause();
    if (result == 1) setState(() => _playerState = PlayerState.paused);
    return result;
  }

  // ignore: unused_element
  Future<int> _earpieceOrSpeakersToggle() async {
    final result = await _audioPlayer.earpieceOrSpeakersToggle();
    if (result == 1)
      setState(() => _playingRouteState =
          _playingRouteState == PlayingRouteState.speakers
              ? PlayingRouteState.earpiece
              : PlayingRouteState.speakers);
    return result;
  }

  // ignore: unused_element
  Future<int> _stop() async {
    final result = await _audioPlayer.stop();
    if (result == 1) {
      setState(() {
        _playerState = PlayerState.stopped;
        _position = Duration();
      });
    }
    return result;
  }

  void _onComplete() {
    setState(() {
      startPlay = false;
      _playerState = PlayerState.stopped;
    });
  }
}
