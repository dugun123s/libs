import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:diemchat/constatnt/global.dart';
import 'package:diemchat/helper/sizeconfig.dart';
import 'package:toast/toast.dart';

class ProfilePicture extends StatefulWidget {
  @override
  ProfilePictureState createState() {
    return new ProfilePictureState();
  }
}

class ProfilePictureState extends State<ProfilePicture> {
  String userId = '';
  String profileseen = '';
  final FirebaseDatabase database = new FirebaseDatabase();
  bool isLoading = true;
  FirebaseAuth _auth = FirebaseAuth.instance;
  @override
  void initState() {
    setState(() {
      userId = _auth.currentUser.uid;

      getprofileseen();
    });

    super.initState();
  }

  getprofileseen() async {
    await FirebaseFirestore.instance
        .collection("users")
        .doc(userId)
        .get()
        .then((value) {
      setState(() {
        profileseen = value["profileseen"];
      });
    });

    setState(() {
      _body();
      isLoading = false;
    });
  }

  updateprofileseen() async {
    await FirebaseFirestore.instance.collection("users").doc(userId).update({
      "profileseen": profileseen,
    }).then((_) {
      setState(() {
        _body();
        Toast.show("Güncellendi", context,
            duration: Toast.LENGTH_SHORT, gravity: Toast.BOTTOM);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: appColorWhite,
          title: Text(
            'Profile Resmi',
            style: TextStyle(
                fontFamily: "MontserratBold",
                fontSize: 17,
                color: appColorBlack),
          ),
          centerTitle: true,
          leading: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: Icon(
                Icons.arrow_back_ios,
                color: appColorBlue,
              )),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 15),
              child: IconButton(
                  padding: EdgeInsets.all(0),
                  onPressed: () {
                    updateprofileseen();
                  },
                  icon: Text(
                    "Tamam",
                    style: TextStyle(
                        fontSize: 11,
                        color: appColorBlue,
                        fontFamily: "MontserratBold"),
                  )),
            ),
          ],
        ),
        body: isLoading == true
            ? Center(
                child: loader(),
              )
            : _body());
  }

  Widget _body() {
    return SingleChildScrollView(
      child: Container(
        color: Colors.white,
        child: Column(
          children: <Widget>[
            InkWell(
              onTap: () {
                setState(() {
                  profileseen = 'everyone';
                });
              },
              child: Container(
                height: SizeConfig.blockSizeVertical * 6,
                child: Center(
                  child: ListTile(
                    title: new Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Expanded(
                          child: new Text(
                            'Herkes',
                            style: new TextStyle(
                                fontSize: SizeConfig.blockSizeHorizontal * 3.7,
                                fontWeight: FontWeight.bold,
                                color: Colors.black),
                          ),
                        ),
                        profileseen == "everyone"
                            ? Icon(
                                Icons.check,
                                color: appColorBlue,
                                size: 20,
                              )
                            : Container(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Container(height: 0.5, color: Colors.grey),
            Container(height: 0.5, color: Colors.grey),
            InkWell(
              onTap: () {
                setState(() {
                  profileseen = 'nobody';
                });
              },
              child: Container(
                height: SizeConfig.blockSizeVertical * 6,
                child: Center(
                  child: ListTile(
                    title: new Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Expanded(
                          child: new Text(
                            'Nobody',
                            style: new TextStyle(
                                fontSize: SizeConfig.blockSizeHorizontal * 3.7,
                                fontWeight: FontWeight.bold,
                                color: Colors.black),
                          ),
                        ),
                        profileseen == "nobody"
                            ? Icon(
                                Icons.check,
                                color: appColorBlue,
                                size: 20,
                              )
                            : Container(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Container(height: 0.5, color: Colors.grey),
          ],
        ),
      ),
    );
  }
}
