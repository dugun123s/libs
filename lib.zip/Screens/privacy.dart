import 'package:diemchat/constatnt/Constant.dart';
import 'package:flutter/material.dart';
import 'package:diemchat/Screens/block.dart';
import 'package:diemchat/Screens/dpPrivacy.dart';
import 'package:diemchat/Screens/lastseen.dart';
import 'package:diemchat/constatnt/global.dart';
import 'package:diemchat/helper/sizeconfig.dart';

class PrivacyOptions extends StatefulWidget {
  @override
  PrivacyOptionsState createState() {
    return new PrivacyOptionsState();
  }
}

class PrivacyOptionsState extends State<PrivacyOptions> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgcolor,
      appBar: AppBar(
        backgroundColor: appColorWhite,
        title: Text(
          "Gizlilik",
          style: TextStyle(
              fontFamily: "MontserratBold", fontSize: 17, color: appColorBlack),
        ),
        centerTitle: true,
        leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(
              Icons.arrow_back_ios,
              color: appColorBlue,
            )),
      ),
      body: SingleChildScrollView(
        child: Container(
          color: Colors.white,
          child: Column(
            children: <Widget>[
              Container(height: 0.5, color: Colors.grey),
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => BlockContacts()),
                  );
                },
                child: Container(
                  height: SizeConfig.blockSizeVertical * 6,
                  child: Center(
                    child: ListTile(
                      title: new Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Expanded(
                            child: new Text(
                              'Engellenen',
                              style: new TextStyle(
                                  fontSize:
                                      SizeConfig.blockSizeHorizontal * 3.7,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black),
                            ),
                          ),
                          Icon(
                            Icons.arrow_forward_ios,
                            color: Colors.grey,
                            size: 20,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Container(height: 0.5, color: Colors.grey),
            ],
          ),
        ),
      ),
    );
  }
}
