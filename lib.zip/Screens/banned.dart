import 'package:diemchat/constatnt/global.dart';
import 'package:flutter/material.dart';

class Banned extends StatefulWidget {
  String name;
  Banned({@required this.name});
  @override
  State<Banned> createState() => _BannedState();
}

class _BannedState extends State<Banned> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            'Merhaba ${widget.name}',
            style: TextStyle(
                color: appColor, fontSize: 27, fontWeight: FontWeight.bold),
          ),
          SizedBox(
            height: 40,
          ),
          Center(
            child: Image.asset(
              'assets/images/applogo.png',
              width: MediaQuery.of(context).size.width / 1.5,
              height: 200,
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Text(
            'Hesabınız feshedildi',
            style: TextStyle(
                color: appColor, fontSize: 27, fontWeight: FontWeight.bold),
          ),
          SizedBox(
            height: 20,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Text(
              'Eğer hata yaptığımızı düşünüyorsan destek@diemchat adresinden bizimle iletişime geçebilirsin',
              textAlign: TextAlign.center,
              style: TextStyle(
                  letterSpacing: 0.2,
                  color: appColor,
                  fontSize: 13,
                  fontWeight: FontWeight.normal),
            ),
          )
        ],
      )),
    );
  }
}
