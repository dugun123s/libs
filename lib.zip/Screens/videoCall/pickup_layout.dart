import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:diemchat/Screens/videoCall/call.dart';
import 'package:diemchat/Screens/videoCall/call_method.dart';
import 'package:diemchat/Screens/videoCall/pickup_screen.dart';

// ignore: must_be_immutable
class PickupLayout extends StatefulWidget {
  final Widget scaffold;

  PickupLayout({
    @required this.scaffold,
  });

  @override
  _PickupLayoutState createState() => _PickupLayoutState();
}

class _PickupLayoutState extends State<PickupLayout> {
  String userId;
  final CallMethods callMethods = CallMethods();
  FirebaseAuth _auth = FirebaseAuth.instance;
  @override
  void initState() {
    setState(() {
      userId = _auth.currentUser.uid;
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // if (userProvider == null) {
    //   closeNotification();
    // }

    return Stack(
      children: [
        widget.scaffold,
        userId != null
            ? StreamBuilder<DocumentSnapshot>(
                stream: callMethods.callStream(uid: _auth.currentUser.uid),
                builder: (context, snapshot) {
                  if (snapshot.hasData && snapshot.data.data == null) {
                    closeNotification();
                  }
                  if (snapshot.hasData && snapshot.data.exists) {
                    Call call = Call.fromMap(snapshot.data);

                    if (!call.hasDialled) {
                      return PickupScreen(call: call);
                    }
                  }
                  return Container();
                },
              )
            : Scaffold(
                body: Center(
                  child: CircularProgressIndicator(),
                ),
              ),
      ],
    );
  }

  closeNotification() async {
    FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
        FlutterLocalNotificationsPlugin();
    await flutterLocalNotificationsPlugin.cancel(0);
    //

    await flutterLocalNotificationsPlugin.cancelAll();
  }
}
