import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'package:image_cropper/image_cropper.dart';
import 'package:diemchat/Screens/bottombar/newTabber.dart';
import 'package:diemchat/constatnt/global.dart';
import 'package:diemchat/helper/sizeconfig.dart';
import 'package:diemchat/services/auth_service.dart';
import 'package:image_picker/image_picker.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SignUp extends StatefulWidget {
  @override
  SignUpState createState() => SignUpState();
}

class SignUpState extends State<SignUp> with SingleTickerProviderStateMixin {
  Animation<double> _progressAnimation;
  AnimationController _progressAnimcontroller;

  @override
  void initState() {
    super.initState();

    _progressAnimcontroller = AnimationController(
      duration: Duration(milliseconds: 200),
      vsync: this,
    );

    _progressAnimation = Tween<double>(begin: beginWidth, end: endWidth)
        .animate(_progressAnimcontroller);

    _setProgressAnimForward(0, 0);
  }

  double growStepWidth, beginWidth, endWidth = 0.0;
  int totalPages = 4;
  int currPage = 0;
  _setProgressAnimForward(double maxWidth, int curPageIndex) {
    setState(() {
      growStepWidth = maxWidth / totalPages;
      beginWidth = growStepWidth * (curPageIndex - 1);
      endWidth = growStepWidth * curPageIndex;

      _progressAnimation = Tween<double>(begin: beginWidth, end: endWidth)
          .animate(_progressAnimcontroller);
    });

    _progressAnimcontroller.forward();
  }

  _setProgressAnimReverse(double maxWidth, int curPageIndex) {
    setState(() {
      growStepWidth = maxWidth / totalPages;
      beginWidth = growStepWidth * (curPageIndex - 1);
      endWidth = growStepWidth * curPageIndex;

      _progressAnimation = Tween<double>(begin: beginWidth, end: endWidth)
          .animate(_progressAnimcontroller);
    });

    _progressAnimcontroller.reverse();
  }

  FirebaseAuth _auth = FirebaseAuth.instance;
  PageController pageController = PageController();
  final _formKey1 = GlobalKey<FormState>();
  final _formKey2 = GlobalKey<FormState>();
  final _formKey3 = GlobalKey<FormState>();
  TextEditingController emailController = TextEditingController();
  TextEditingController nickController = TextEditingController();
  TextEditingController passController = TextEditingController();
  TextEditingController repassController = TextEditingController();
  TextEditingController bioController = TextEditingController();
  bool nickLoading = false;
  bool nickSuccess = false;
  bool nickError = false;
  bool emailLoading = false;
  bool emailSuccess = false;
  bool emailError = false;
  bool imagePicked = false;
  File _image;
  final FirebaseDatabase _database = FirebaseDatabase.instance;
  Future getImage() async {
    final picker = ImagePicker();
    final imageFile = await picker.getImage(
        source: ImageSource.gallery,
        imageQuality: 50,
        maxHeight: 1000,
        maxWidth: 1000);
    _image = File(imageFile.path);
    File croppedFile = await ImageCropper().cropImage(
        sourcePath: imageFile.path,
        compressQuality: 50,
        cropStyle: CropStyle.circle,
        aspectRatioPresets: [
          CropAspectRatioPreset.square,
        ],
        androidUiSettings: AndroidUiSettings(
            toolbarTitle: 'Düzelt',
            toolbarColor: Colors.black,
            toolbarWidgetColor: Colors.white,
            statusBarColor: Colors.grey,
            initAspectRatio: CropAspectRatioPreset.square,
            lockAspectRatio: false),
        iosUiSettings: IOSUiSettings(
          title: 'Düzelt',
        ));
    if (croppedFile != null) {
      _image = croppedFile;
      setState(() {
        // state = AppState.cropped;
      });
    }

    setState(() {
      imagePicked = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    var mediaQD = MediaQuery.of(context);
    var maxWidth = mediaQD.size.width;
    AuthService authService = AuthService();
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            flex: 8,
            child: PageView(
              controller: pageController,
              physics: NeverScrollableScrollPhysics(),
              onPageChanged: (i) {
                //index i starts from 0!
                // if (currPage < i) {

                _setProgressAnimForward(maxWidth, i);
                // } else {
                //   _setProgressAnimReverse(maxWidth, i);
                // }
                currPage = i;
              },
              children: <Widget>[
                Container(
                  color: appColorBlue,
                  child: Center(
                    child: Form(
                      key: _formKey1,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text("E-Postanı ve Şifreni Gir".toUpperCase(),
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: SizeConfig.blockSizeHorizontal * 4,
                                  fontFamily: "MontserratBold")),
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 20, vertical: 8),
                            child: TextFormField(
                              validator: (value) {
                                bool emailValid = RegExp(
                                        r'^.+@[a-zA-Z]+\.{1}[a-zA-Z]+(\.{0,1}[a-zA-Z]+)$')
                                    .hasMatch(value);

                                if (value.isEmpty || value == null) {
                                  return "Lütfen E-postanızı yazınız";
                                } else if (!emailValid) {
                                  return "Lütfen geçerli bir e-postanı giriniz";
                                }
                                return null;
                              },
                              onChanged: (query) async {
                                bool emailValid = RegExp(
                                        r'^.+@[a-zA-Z]+\.{1}[a-zA-Z]+(\.{0,1}[a-zA-Z]+)$')
                                    .hasMatch(query);
                                if (!emailValid || query.toString() == "") {
                                  setState(() {
                                    emailSuccess = false;
                                    emailError = true;
                                    emailLoading = false;
                                  });
                                } else {
                                  setState(() {
                                    emailLoading = true;
                                  });
                                  await FirebaseFirestore.instance
                                      .collection("users")
                                      .where("email", isEqualTo: query)
                                      .get()
                                      .then((value) {
                                    if (value.docs.length > 0) {
                                      setState(() {
                                        emailSuccess = false;
                                        emailError = true;
                                        emailLoading = false;
                                      });
                                    } else {
                                      setState(() {
                                        emailLoading = false;
                                        emailSuccess = true;
                                        emailError = false;
                                      });
                                    }
                                  });
                                }
                              },
                              controller: emailController,
                              decoration: InputDecoration(
                                fillColor: Colors.white,
                                filled: true,
                                errorStyle: TextStyle(color: Colors.white),
                                suffix: Container(
                                  width: 22,
                                  height: 22,
                                  child: emailLoading
                                      ? Center(
                                          child: CircularProgressIndicator(
                                              valueColor:
                                                  AlwaysStoppedAnimation<Color>(
                                                      appColorBlue)),
                                        )
                                      : emailSuccess
                                          ? Center(
                                              child: Icon(
                                                Icons.check,
                                                size: 22,
                                                color: Colors.green,
                                              ),
                                            )
                                          : Center(
                                              child: Icon(
                                                Icons.error,
                                                size: 22,
                                                color: Colors.red,
                                              ),
                                            ),
                                ),
                                prefixIcon: Icon(
                                  Icons.mail,
                                  color: appColorBlue,
                                ),
                                hintText: 'E-Postan',
                                focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white),
                                    borderRadius: BorderRadius.circular(20)),
                                enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white),
                                    borderRadius: BorderRadius.circular(20)),
                                border: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white),
                                    borderRadius: BorderRadius.circular(20)),
                              ),
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 20, vertical: 8),
                            child: TextFormField(
                              obscureText: true,
                              validator: (value) {
                                if (value.isEmpty || value == null) {
                                  return "Lütfen şifrenizi yazınız";
                                } else if (value.length < 6) {
                                  return "Şifreniz en az 6 haneli olmalıdır";
                                } else if (value != repassController.text) {
                                  return "Şifreler uyuşmuyor";
                                }
                                return null;
                              },
                              controller: passController,
                              decoration: InputDecoration(
                                fillColor: Colors.white,
                                filled: true,
                                errorStyle: TextStyle(color: Colors.white),
                                prefixIcon: Icon(
                                  Icons.lock,
                                  color: appColorBlue,
                                ),
                                hintText: 'Şifre',
                                focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white),
                                    borderRadius: BorderRadius.circular(20)),
                                enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white),
                                    borderRadius: BorderRadius.circular(20)),
                                border: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white),
                                    borderRadius: BorderRadius.circular(20)),
                              ),
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 20, vertical: 8),
                            child: TextFormField(
                              validator: (value) {
                                if (value != passController.text) {
                                  return "Şifreler uyuşmuyor";
                                }
                                return null;
                              },
                              obscureText: true,
                              controller: repassController,
                              decoration: InputDecoration(
                                fillColor: Colors.white,
                                filled: true,
                                errorStyle: TextStyle(color: Colors.white),
                                prefixIcon: Icon(
                                  Icons.lock,
                                  color: appColorBlue,
                                ),
                                hintText: 'Doğrula',
                                focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white),
                                    borderRadius: BorderRadius.circular(20)),
                                enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white),
                                    borderRadius: BorderRadius.circular(20)),
                                border: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white),
                                    borderRadius: BorderRadius.circular(20)),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Container(
                  color: appColorBlue,
                  child: Form(
                    key: _formKey2,
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text("Kullanıcı Adını Yaz".toUpperCase(),
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: SizeConfig.blockSizeHorizontal * 4,
                                  fontFamily: "MontserratBold")),
                          Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 20, vertical: 15),
                            child: TextFormField(
                              controller: nickController,
                              validator: (value) {
                                if (value.isEmpty || value == null) {
                                  return "Lütfen kullanıcı adınızı giriniz";
                                } else if (value.contains(" ")) {
                                  return "Lütfen geçerli bir kullanıcı adı giriniz";
                                } else if (value.length > 30 ||
                                    value.length < 6) {
                                  return "Lütfen en az 6 en fazla 30 karakter içeren bir kullanıcı adı giriniz";
                                } else if (nickError) {
                                  return "Lütfen farklı bir kullanıcı adı giriniz";
                                }
                                return null;
                              },
                              onChanged: (query) async {
                                if (query.isEmpty || query == null) {
                                  return setState(() {
                                    nickSuccess = false;
                                    nickError = true;
                                    nickLoading = false;
                                  });
                                } else if (query.contains(" ")) {
                                  return setState(() {
                                    nickSuccess = false;
                                    nickError = true;
                                    nickLoading = false;
                                  });
                                } else if (query.length > 30 ||
                                    query.length < 6) {
                                  return setState(() {
                                    nickSuccess = false;
                                    nickError = true;
                                    nickLoading = false;
                                  });
                                }
                                setState(() {
                                  nickLoading = true;
                                });
                                await FirebaseFirestore.instance
                                    .collection("users")
                                    .where("nick", isEqualTo: query)
                                    .get()
                                    .then((value) {
                                  if (value.docs.length > 0) {
                                    setState(() {
                                      nickSuccess = false;
                                      nickError = true;
                                      nickLoading = false;
                                    });
                                  } else {
                                    setState(() {
                                      nickLoading = false;
                                      nickSuccess = true;
                                      nickError = false;
                                    });
                                  }
                                });
                              },
                              decoration: InputDecoration(
                                fillColor: Colors.white,
                                filled: true,
                                errorStyle: TextStyle(color: Colors.white),
                                prefixIcon: Icon(
                                  Icons.person,
                                  color: appColorBlue,
                                ),
                                suffix: Container(
                                  width: 22,
                                  height: 22,
                                  child: nickLoading
                                      ? Center(
                                          child: CircularProgressIndicator(
                                              valueColor:
                                                  AlwaysStoppedAnimation<Color>(
                                                      appColorBlue)),
                                        )
                                      : nickSuccess
                                          ? Center(
                                              child: Icon(
                                                Icons.check,
                                                size: 22,
                                                color: Colors.green,
                                              ),
                                            )
                                          : Center(
                                              child: Icon(
                                                Icons.error,
                                                size: 22,
                                                color: Colors.red,
                                              ),
                                            ),
                                ),
                                hintText: 'Kullanıcı Adın',
                                focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white),
                                    borderRadius: BorderRadius.circular(20)),
                                enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white),
                                    borderRadius: BorderRadius.circular(20)),
                                border: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white),
                                    borderRadius: BorderRadius.circular(20)),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Container(
                  color: appColorBlue,
                  child: Form(
                    key: _formKey3,
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text("Fotoğrafını Seç".toUpperCase(),
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: SizeConfig.blockSizeHorizontal * 4,
                                  fontFamily: "MontserratBold")),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20, vertical: 10),
                            child: Text(
                                "Kendine ait en beğendiğin fotoğrafını yüklersen profilin daha çok öne çıkar ve ilgi görürsün.",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize:
                                        SizeConfig.blockSizeHorizontal * 3,
                                    fontFamily: "MontserratBold")),
                          ),
                          SizedBox(
                            height: 25,
                          ),
                          imagePicked
                              ? InkWell(
                                  onTap: () {
                                    getImage();
                                  },
                                  child: CircleAvatar(
                                    radius: 50,
                                    backgroundColor: appColorBlue,
                                    backgroundImage: FileImage(_image),
                                  ),
                                )
                              : CircleAvatar(
                                  backgroundColor: Colors.white,
                                  radius: 50,
                                  child: IconButton(
                                    icon: Icon(Icons.photo_camera),
                                    onPressed: () async {
                                      getImage();
                                    },
                                    iconSize: 50,
                                  ),
                                ),
                          SizedBox(
                            height: 25,
                          ),
                          Text("Kendinden Bahset".toUpperCase(),
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: SizeConfig.blockSizeHorizontal * 4,
                                  fontFamily: "MontserratBold")),
                          Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 20, vertical: 15),
                            child: TextFormField(
                              maxLines: 4,
                              validator: (value) {
                                if (value.isEmpty || value == null) {
                                  return "Lütfen biyografinizi giriniz";
                                }
                                return null;
                              },
                              controller: bioController,
                              maxLength: 300,
                              textAlign: TextAlign.center,
                              decoration: InputDecoration(
                                counterText: "",
                                fillColor: Colors.white,
                                filled: true,
                                errorStyle: TextStyle(color: Colors.white),
                                hintStyle: TextStyle(color: Colors.grey),
                                hintText:
                                    'Kendini diğer kullanıcılara kısaca anlat ve daha fazla dikkat çek!',
                                focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white),
                                    borderRadius: BorderRadius.circular(20)),
                                enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white),
                                    borderRadius: BorderRadius.circular(20)),
                                border: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white),
                                    borderRadius: BorderRadius.circular(20)),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Container(
                  color: appColorBlue,
                  child: Center(
                    child: Text("Başarıyla Kayıt Oldunuz".toUpperCase(),
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: SizeConfig.blockSizeHorizontal * 5,
                            fontFamily: "MontserratBold")),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 15),
              color: appColorBlue,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  currPage == 0
                      ? Container()
                      : Container(
                          decoration: BoxDecoration(
                              shape: BoxShape.circle, color: Colors.white),
                          child: IconButton(
                              onPressed: () {
                                pageController.previousPage(
                                    duration: Duration(milliseconds: 400),
                                    curve: Curves.decelerate);
                              },
                              icon: Icon(Icons.keyboard_arrow_left_outlined,
                                  size: 30, color: appColorBlue)),
                        ),
                  SizedBox(
                    width: 15,
                  ),
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: AnimatedProgressBar(
                      animation: _progressAnimation,
                    ),
                  ),
                  Expanded(
                    child: Container(
                      height: 6.0,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: Colors.white54,
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 15,
                  ),
                  Container(
                    decoration: BoxDecoration(
                        shape: BoxShape.circle, color: Colors.white),
                    child: IconButton(
                        onPressed: () async {
                          if (currPage == 0 &&
                              _formKey1.currentState.validate() &&
                              emailLoading == false &&
                              emailError == false &&
                              emailSuccess == true) {
                            pageController.nextPage(
                                duration: Duration(milliseconds: 400),
                                curve: Curves.decelerate);
                          } else if (currPage == 1 &&
                              _formKey2.currentState.validate() &&
                              nickLoading == false &&
                              nickError == false &&
                              nickSuccess == true) {
                            pageController.nextPage(
                                duration: Duration(milliseconds: 400),
                                curve: Curves.decelerate);
                          } else if (currPage == 2 &&
                              imagePicked == true &&
                              _formKey3.currentState.validate()) {
                            try {
                              progressDialogue(context);

                              await authService
                                  .createUserWithEmailAndPassword(
                                emailController.text.trim(),
                                passController.text,
                              )
                                  .then((value) async {
                                FirebaseAuth _auth = FirebaseAuth.instance;
                                String imageLocation =
                                    'Users/${_auth.currentUser.uid}/${DateTime.now()}.jpg';

                                await firebase_storage.FirebaseStorage.instance
                                    .ref(imageLocation)
                                    .putFile(_image);
                                String downloadUrl = await firebase_storage
                                    .FirebaseStorage.instance
                                    .ref(imageLocation)
                                    .getDownloadURL();
                                await _auth.currentUser
                                    .updatePhotoURL(downloadUrl);

                                SharedPreferences pref =
                                    await SharedPreferences.getInstance();
                                pref.setString("nick", nickController.text);
                                pref.setString("bio", bioController.text);
                                pref.setString(
                                  "email",
                                  emailController.text.trim(),
                                );
                                pref.setString("photo", downloadUrl);

                                FirebaseMessaging.instance
                                    .getToken()
                                    .then((token) async {
                                  await FirebaseFirestore.instance
                                      .collection("users")
                                      .doc(_auth.currentUser.uid)
                                      .set({
                                    "email": emailController.text.trim(),
                                    "nick": nickController.text,
                                    "photo": downloadUrl,
                                    "status": "Online",
                                    "bio": bioController.text,
                                    "inChat": '',
                                    "privacy": false,
                                    "blocks": [],
                                    "token": token,
                                  });
                                  Navigator.of(context, rootNavigator: true)
                                      .pop();
                                  pageController.nextPage(
                                      duration: Duration(milliseconds: 400),
                                      curve: Curves.decelerate);
                                  Future.delayed(Duration(seconds: 2))
                                      .then((value) {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => TabbarScreen()),
                                    );
                                  });
                                });

                                // user.updateProfile(UserUpdateInfo());
                              });
                            } catch (e) {
                              Navigator.of(context, rootNavigator: true).pop();
                              Alert(
                                context: context,
                                type: AlertType.error,
                                title: "HATA",
                                desc: e.toString(),
                                buttons: [
                                  DialogButton(
                                    child: Text(
                                      "TAMAM",
                                      style: TextStyle(
                                          color: Colors.white, fontSize: 20),
                                    ),
                                    onPressed: () => Navigator.pop(context),
                                    width: 120,
                                  )
                                ],
                              ).show();
                            }
                          }
                        },
                        icon: Icon(Icons.keyboard_arrow_right,
                            size: 30, color: appColorBlue)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class AnimatedProgressBar extends AnimatedWidget {
  AnimatedProgressBar({Key key, Animation<double> animation})
      : super(key: key, listenable: animation);

  Widget build(BuildContext context) {
    final Animation<double> animation = listenable;
    return Container(
      height: 6.0,
      width: animation.value < 0 ? 0 : animation.value / 1.25,
      decoration: BoxDecoration(color: Colors.white),
    );
  }
}

progressDialogue(BuildContext context) {
  //set up the AlertDialog
  AlertDialog alert = AlertDialog(
    backgroundColor: Colors.transparent,
    elevation: 0,
    content: Container(
      child: Center(
        child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(Colors.white)),
      ),
    ),
  );
  showDialog(
    //prevent outside touch
    barrierDismissible: false,
    context: context,
    builder: (BuildContext context) {
      //prevent Back button press
      return WillPopScope(onWillPop: () {}, child: alert);
    },
  );
}
