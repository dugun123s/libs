import 'package:firebase_auth/firebase_auth.dart';

class FireBase {
  static FirebaseAuth auth = FirebaseAuth.instance;

  static instantiate(){

  }
}
