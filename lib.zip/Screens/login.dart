import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:diemchat/Screens/bottombar/newTabber.dart';
import 'package:diemchat/constatnt/global.dart';
import 'package:diemchat/helper/sizeconfig.dart';
import 'package:diemchat/services/auth_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:toast/toast.dart';

class Login extends StatefulWidget {
  @override
  LoginState createState() => LoginState();
}

class LoginState extends State<Login> {
  final _formKey1 = GlobalKey<FormState>();

  TextEditingController nickController = TextEditingController();
  TextEditingController passController = TextEditingController();

  bool nickLoading = false;
  bool nickSuccess = false;
  bool nickError = false;
  bool imagePicked = false;
  File _image;

  FirebaseAuth _auth = FirebaseAuth.instance;
  AuthService authService = AuthService();
  bool loading = false;
  bool success = false;
  @override
  Widget build(BuildContext context) {
    var mediaQD = MediaQuery.of(context);
    var maxWidth = mediaQD.size.width;
    AuthService authService = AuthService();
    return Scaffold(
      backgroundColor: appColorBlue,
      body: Form(
        key: _formKey1,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Tekrar Hoşgeldin".toUpperCase(),
                style: TextStyle(
                    color: Colors.white,
                    fontSize: SizeConfig.blockSizeHorizontal * 4,
                    fontFamily: "MontserratBold")),
            SizedBox(
              height: SizeConfig.blockSizeVertical * 5,
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
              child: TextFormField(
                controller: nickController,
                validator: (value) {
                  if (value.isEmpty || value == null) {
                    return "Lütfen kullanıcı adınızı giriniz";
                  } else if (nickError) {
                    return "Lütfen farklı bir kullanıcı adı giriniz";
                  }
                  return null;
                },
                decoration: InputDecoration(
                  fillColor: Colors.white,
                  filled: true,
                  errorStyle: TextStyle(color: Colors.white),
                  prefixIcon: Icon(
                    Icons.person,
                    color: appColorBlue,
                  ),
                  hintText: 'Kullanıcı Adın',
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white),
                      borderRadius: BorderRadius.circular(20)),
                  enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white),
                      borderRadius: BorderRadius.circular(20)),
                  border: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white),
                      borderRadius: BorderRadius.circular(20)),
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              child: TextFormField(
                obscureText: true,
                validator: (value) {
                  if (value.isEmpty || value == null) {
                    return "Lütfen şifrenizi yazınız";
                  } else if (value.length < 6) {
                    return "Şifreniz en az 6 haneli olmalıdır";
                  }
                  return null;
                },
                controller: passController,
                decoration: InputDecoration(
                  fillColor: Colors.white,
                  filled: true,
                  errorStyle: TextStyle(color: Colors.white),
                  prefixIcon: Icon(
                    Icons.lock,
                    color: appColorBlue,
                  ),
                  hintText: 'Şifre',
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white),
                      borderRadius: BorderRadius.circular(20)),
                  enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white),
                      borderRadius: BorderRadius.circular(20)),
                  border: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white),
                      borderRadius: BorderRadius.circular(20)),
                ),
              ),
            ),
            SizedBox(
              height: SizeConfig.blockSizeVertical * 5,
            ),
            AnimatedContainer(
              height: SizeConfig.blockSizeVertical * 6,
              width: loading || success
                  ? SizeConfig.blockSizeHorizontal * 25
                  : SizeConfig.blockSizeHorizontal * 50,
              // ignore: deprecated_member_use
              duration: Duration(milliseconds: 400),
              child: RaisedButton(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                onPressed: () async {
                  if (_formKey1.currentState.validate()) {
                    setState(() {
                      loading = true;
                    });
                    await FirebaseFirestore.instance
                        .collection("users")
                        .where("email", isEqualTo: nickController.text)
                        .get()
                        .then((value) {
                      print(nickController.text);
                      print(value.docs.length);
                      if (value.docs.length > 0) {
                        try {
                          authService
                              .signInWithEmailAndPassword(
                                  value.docs[0]["email"], passController.text)
                              .then((user) async {
                            if (user != null) {
                              setState(() {
                                loading = false;
                                success = true;
                              });
                              await FirebaseMessaging.instance
                                  .getToken()
                                  .then((token) {
                                value.docs[0].reference
                                    .update({"token": token});
                              });

                              SharedPreferences pref =
                                  await SharedPreferences.getInstance();

                              pref.setString("nick", nickController.text);
                              pref.setString(
                                "bio",
                                value.docs[0]["bio"],
                              );
                              pref.setString(
                                "email",
                                value.docs[0]["email"],
                              );
                              pref.setString(
                                "photo",
                                value.docs[0]["photo"],
                              );
                              Future.delayed(Duration(seconds: 1))
                                  .then((value) => Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => TabbarScreen(),
                                        ),
                                      ));
                            }
                          });
                        } catch (e) {
                          setState(() {
                            loading = false;
                          });
                          Toast.show(e.toString(), context,
                              duration: Toast.LENGTH_SHORT,
                              backgroundColor: Colors.red,
                              textColor: Colors.white,
                              gravity: Toast.TOP);
                        }
                      } else {
                        setState(() {
                          loading = false;
                        });
                        Toast.show("Böyle bir kullanıcı yok", context,
                            duration: Toast.LENGTH_SHORT,
                            backgroundColor: Colors.red,
                            textColor: Colors.white,
                            gravity: Toast.TOP);
                      }
                    });
                  }
                },
                color: Colors.white,
                textColor: Colors.white,
                child: loading || success
                    ? success
                        ? Icon(
                            Icons.check_circle,
                            color: appColorBlue,
                          )
                        : Container(
                            width: 15,
                            height: 15,
                            child: Center(
                              child: CircularProgressIndicator(
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                      appColorBlue)),
                            ),
                          )
                    : Text("Giriş Yap".toUpperCase(),
                        style: TextStyle(
                            color: appColorBlue,
                            fontSize: SizeConfig.blockSizeHorizontal * 3,
                            fontFamily: "MontserratBold")),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
