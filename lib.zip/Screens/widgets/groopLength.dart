import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dashed_circle/dashed_circle.dart';
import 'package:flutter/material.dart';
import 'dart:math' as math;

class GroopLength extends StatefulWidget {
  int type;
  String userId;
  GroopLength({@required this.type, @required this.userId});

  @override
  State<GroopLength> createState() => _GroopLengthState();
}

class _GroopLengthState extends State<GroopLength> {
  @override
  void initState() {
    document = FirebaseFirestore.instance
        .collection("users")
        .doc(widget.userId)
        .snapshots();
    super.initState();
  }

  getRandomColor() {
    return Color.fromRGBO(math.Random().nextInt(200),
        math.Random().nextInt(200), math.Random().nextInt(200), 1);
  }

  Stream<DocumentSnapshot> document;
  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
        stream: document,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return Container(
              margin: EdgeInsets.only(right: 6),
              width: 42,
              height: 42,
              child: DashedCircle(
                gapSize: 20,
                dashes: 20,
                color: getRandomColor(),
                child: Padding(
                  padding: EdgeInsets.all(0.8),
                  child: CircleAvatar(
                    radius: 20,
                    foregroundColor: Theme.of(context).primaryColor,
                    backgroundColor: Colors.grey,
                    backgroundImage: new NetworkImage(
                      snapshot.data["photo"],
                    ),
                  ),
                ),
              ),
            );
          }
          return Container(
            margin: EdgeInsets.only(right: 86),
            child: DashedCircle(
              gapSize: 20,
              dashes: 20,
              color: getRandomColor(),
              child: Padding(
                padding: const EdgeInsets.all(0.75),
                child: CircleAvatar(
                  //radius: 60,
                  foregroundColor: Theme.of(context).primaryColor,
                  backgroundColor: Colors.grey,
                ),
              ),
            ),
          );
        });
  }
}
