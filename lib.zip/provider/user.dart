import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';

class UserProvider extends ChangeNotifier {
  bool _banned = false;

  bool get banned => _banned;
  String _userName = '';

  String get userName => _userName;
  UserProvider() {
    getUserInfo();
  }
  FirebaseAuth _auth = FirebaseAuth.instance;
  getUserInfo() async {
    await FirebaseFirestore.instance
        .collection('users')
        .doc(_auth.currentUser.uid)
        .get()
        .then((value) {
      if (value.data().containsKey('banned')) {
        _banned = value['banned'];
        _userName = value['nick'];
      } else {}
    });
  }

  changeBanned(bool newBannned) {
    _banned = newBannned;
    notifyListeners();
  }
}
