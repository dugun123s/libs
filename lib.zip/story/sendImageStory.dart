import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:diemchat/constatnt/global.dart';
import 'package:diemchat/helper/sizeconfig.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;

// ignore: must_be_immutable
class SendStory extends StatefulWidget {
  File imageFile;
  SendStory({this.imageFile});
  @override
  ChatBgState createState() {
    return new ChatBgState();
  }
}

class ChatBgState extends State<SendStory> {
  String userId = '';
  bool isLoading = false;
  final TextEditingController textEditingController = TextEditingController();
  FirebaseAuth _auth = FirebaseAuth.instance;
  @override
  void initState() {
    //_cropImage();

    getPhoto();
    userId = _auth.currentUser.uid;
    //getData();

    super.initState();
  }

  // ignore: missing_return
  Future getPhoto() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    globalImage = prefs.getString("photo");
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          "Preview",
          style: TextStyle(
              fontFamily: "MontserratBold", fontSize: 17, color: Colors.black),
        ),
        centerTitle: true,
        leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(
              Icons.arrow_back_ios,
              color: Colors.black,
            )),
        actions: [
          // IconButton(
          //     padding: const EdgeInsets.all(0),
          //     onPressed: () {
          //       _cropImage();
          //     },
          //     icon: Icon(
          //       Icons.crop,
          //       color: Colors.black,
          //     )),
          // Padding(
          //   padding: const EdgeInsets.only(right: 10),
          //   child: IconButton(
          //       padding: const EdgeInsets.all(0),
          //       onPressed: () {
          //         getimageditor();
          //       },
          //       icon: Icon(
          //         Icons.edit,
          //         color: Colors.black,
          //       )),
          // )
        ],
      ),
      body: Container(
        color: Colors.black,
        child: Stack(
          children: [
            Column(
              children: <Widget>[
                Expanded(
                  child: widget.imageFile != null
                      ? SizedBox(
                          child: Image.file(
                          widget.imageFile,
                          fit: BoxFit.contain,
                        ))
                      : Center(
                          child: Text(
                            "Select photo",
                            style: TextStyle(
                              color: Colors.grey,
                              fontFamily: "Poppins-Medium",
                            ),
                          ),
                        ),
                ),
                buildInput()
              ],
            ),
            Center(child: isLoading == true ? loader() : Container())
          ],
        ),
      ),
    );
  }

  Widget buildInput() {
    SizeConfig().init(context);
    final deviceHeight = MediaQuery.of(context).size.height;
    final deviceWidth = MediaQuery.of(context).size.width;
    return Padding(
      padding: const EdgeInsets.only(left: 0, bottom: 10, top: 10),
      child: Container(
        width: deviceHeight,
        decoration: BoxDecoration(color: Colors.black),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Container(width: 15),
            Expanded(
              child: Container(
                padding: EdgeInsets.only(
                  left: 20.0,
                ),
                height: 47.0,
                width: deviceWidth * 0.6,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(25.0),
                  color: Colors.grey[300],
                ),
                child: TextField(
                  controller: textEditingController,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: 'Type something about story..',
                    hintStyle: TextStyle(
                        color: Colors.grey.withOpacity(0.6),
                        fontWeight: FontWeight.w600,
                        fontSize: 13),
                  ),
                ),
              ),
            ),
            IconButton(
              onPressed: () async {
                SharedPreferences pref = await SharedPreferences.getInstance();
                getImage(context, pref.getString("nick"),
                    pref.getString("photo"), mobNo);
              },
              icon: Icon(
                Icons.send,
                color: Colors.white,
              ),
              iconSize: 32.0,
            ),
            Container(width: 15),
          ],
        ),
      ),
    );
  }

  getImage(
      BuildContext context, String name, String image, String mobile) async {
    //File imageFile = await ImagePicker.pickImage(source: ImageSource.gallery);

    if (widget.imageFile != null) {
      setState(() {
        isLoading = true;
      });

      // var timeKey = new DateTime.now();

      // final StorageReference postImageRef =
      //     FirebaseStorage.instance.ref().child("Post Image");
      // final StorageUploadTask uploadTask = postImageRef
      //     .child(timeKey.toString() + ".jpg")
      //     .putFile(widget.imageFile);
      // // ignore: non_constant_identifier_names
      // var ImageUrl = await (await uploadTask.onComplete).ref.getDownloadURL();

      final dir = await getTemporaryDirectory();
      final targetPath = dir.absolute.path +
          "/${DateTime.now().millisecondsSinceEpoch.toString()}.jpg";

      await FlutterImageCompress.compressAndGetFile(
        widget.imageFile.absolute.path,
        targetPath,
        quality: 20,
      ).then((value) async {
        print("Compressed");
        String fileName = DateTime.now().millisecondsSinceEpoch.toString();
        String imageLocation =
            'StoryUser/${_auth.currentUser.uid}/${DateTime.now()}.jpg';

        await firebase_storage.FirebaseStorage.instance
            .ref(imageLocation)
            .putFile(value);
        String downloadUrl = await firebase_storage.FirebaseStorage.instance
            .ref(imageLocation)
            .getDownloadURL();
        await FirebaseFirestore.instance
            .collection("storyUser")
            .doc(userId)
            .get()
            .then((value) async {
          if (value.exists) {
            await FirebaseFirestore.instance
                .collection('storyUser')
                .doc(userId)
                .update(
              {
                "userId": userId,
                "userName": name,
                "userImage": image,
                "image": downloadUrl,
                "timestamp": FieldValue.serverTimestamp(),
                "mobile": mobile,
                "story": FieldValue.arrayUnion([
                  {
                    "image": downloadUrl,
                    "time": FieldValue.serverTimestamp(),
                    "type": "image",
                    "text": textEditingController.text.isEmpty
                        ? ""
                        : textEditingController.text
                  }
                ])
              },
            ).then((value) {
              setState(() {
                isLoading = false;
                Navigator.pop(context);
              });
            });
          } else {
            await FirebaseFirestore.instance
                .collection('storyUser')
                .doc(userId)
                .set(
              {
                "userId": userId,
                "userName": name,
                "userImage": image,
                "image": downloadUrl,
                "timestamp": FieldValue.serverTimestamp(),
                "mobile": mobile,
                "story": FieldValue.arrayUnion([
                  {
                    "image": downloadUrl,
                    "time": FieldValue.serverTimestamp(),
                    "type": "image",
                    "text": textEditingController.text.isEmpty
                        ? ""
                        : textEditingController.text
                  }
                ])
              },
            ).then((value) {
              setState(() {
                isLoading = false;
                Navigator.pop(context);
              });
            });
          }
        });
      });
    }
  }

  // ignore: unused_element
  Future<Null> _cropImage() async {
    File croppedFile = await ImageCropper().cropImage(
        sourcePath: widget.imageFile.path,
        aspectRatioPresets: Platform.isAndroid
            ? [
                CropAspectRatioPreset.square,
                CropAspectRatioPreset.ratio3x2,
                CropAspectRatioPreset.original,
                CropAspectRatioPreset.ratio4x3,
                CropAspectRatioPreset.ratio16x9
              ]
            : [
                CropAspectRatioPreset.original,
                CropAspectRatioPreset.square,
                CropAspectRatioPreset.ratio3x2,
                CropAspectRatioPreset.ratio4x3,
                CropAspectRatioPreset.ratio5x3,
                CropAspectRatioPreset.ratio5x4,
                CropAspectRatioPreset.ratio7x5,
                CropAspectRatioPreset.ratio16x9
              ],
        androidUiSettings: AndroidUiSettings(
            toolbarTitle: '',
            toolbarColor: Colors.black,
            toolbarWidgetColor: Colors.white,
            statusBarColor: Colors.grey,
            initAspectRatio: CropAspectRatioPreset.original,
            lockAspectRatio: false),
        iosUiSettings: IOSUiSettings(
          title: '',
        ));
    if (croppedFile != null) {
      widget.imageFile = croppedFile;
      setState(() {
        // state = AppState.cropped;
      });
    }
  }
}
