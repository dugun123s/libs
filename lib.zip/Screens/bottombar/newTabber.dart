import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:diemchat/Screens/banned.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:diemchat/Screens/chat_list.dart';
import 'package:diemchat/Screens/getKredi.dart';
import 'package:diemchat/Screens/listUsers.dart';
import 'package:diemchat/Screens/setting.dart';
import 'package:diemchat/Screens/videoCall/pickup_layout.dart';
import 'package:diemchat/story/status.dart';
import 'package:diemchat/constatnt/global.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';

import '../../provider/user.dart';

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // If you're going to use other Firebase services in the background, such as Firestore,
  // make sure you call `initializeApp` before using other Firebase services.
  await Firebase.initializeApp();
  print('Handling a background message ${message.messageId}');
}

class TabbarScreen extends StatefulWidget {
  final String userID;
  TabbarScreen({this.userID});
  @override
  _TabbarScreenState createState() => _TabbarScreenState();
}

class _TabbarScreenState extends State<TabbarScreen> {
  int _currentIndex = 0;

  List<dynamic> _handlePages = [
    ChatList(),
    Status(),
    ListUsers(),
    // CallHistory(),
    GetKredi(),
    SettingOptions()
    //ReadContacts()
  ];

  FirebaseAuth _auth = FirebaseAuth.instance;

  @override
  void initState() {
    FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
        FlutterLocalNotificationsPlugin();
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    final IOSInitializationSettings initializationSettingsIOS =
        IOSInitializationSettings();
    final InitializationSettings initializationSettings =
        InitializationSettings(
            android: initializationSettingsAndroid,
            iOS: initializationSettingsIOS);
    flutterLocalNotificationsPlugin.initialize(initializationSettings);
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
    permissionAcessPhone();
    super.initState();
  }

  permissionAcessPhone() async {
    Map<Permission, PermissionStatus> statuses = await [
      Permission.notification,
      Permission.storage,
      Permission.camera,
      Permission.microphone,
      Permission.mediaLibrary,
    ].request();

    if (await Permission.contacts.request().isGranted) {}
  }

  Stream<DocumentSnapshot> userStream;
  @override
  Widget build(BuildContext context) {
    bool banned = Provider.of<UserProvider>(
      context,
    ).banned;
    String userName = Provider.of<UserProvider>(
      context,
    ).userName;
    if (banned) {
      return Banned(
        name: userName,
      );
    } else {
      return mainBody();
    }
   
  }

  Widget mainBody() {
    return PickupLayout(
      scaffold: WillPopScope(
        onWillPop: () async {
          if (_currentIndex == 0) {
            SystemNavigator.pop();
          } else {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => TabbarScreen()),
            );
          }

          return false;
        },
        child: Scaffold(
          body: _handlePages[_currentIndex],
          bottomNavigationBar: BottomNavigationBar(
            backgroundColor: Colors.white,
            type: BottomNavigationBarType.fixed,
            currentIndex: _currentIndex,
            onTap: (index) {
              setState(() {
                _currentIndex = index;
              });
            },
            items: <BottomNavigationBarItem>[
              _currentIndex == 0
                  ? BottomNavigationBarItem(
                      icon: Image.asset(
                        "assets/images/chat.png",
                        height: 22,
                        color: appColorBlue,
                      ),
                      label: "",
                    )
                  : BottomNavigationBarItem(
                      icon: Image.asset(
                        "assets/images/chat.png",
                        height: 22,
                        color: appColorGrey,
                      ),
                      label: "",
                    ),
              _currentIndex == 1
                  ? BottomNavigationBarItem(
                      icon: Image.asset(
                        "assets/images/story.png",
                        height: 22,
                        color: appColorBlue,
                      ),
                      label: "",
                    )
                  : BottomNavigationBarItem(
                      icon: Image.asset(
                        "assets/images/story.png",
                        height: 22,
                        color: appColorGrey,
                      ),
                      label: "",
                    ),
              _currentIndex == 2
                  ? BottomNavigationBarItem(
                      icon: Image.asset(
                        "assets/images/home.png",
                        height: 22,
                        color: appColorBlue,
                      ),
                      label: "",
                    )
                  : BottomNavigationBarItem(
                      icon: Image.asset(
                        "assets/images/home.png",
                        height: 22,
                        color: appColorGrey,
                      ),
                      label: "",
                    ),
              // _currentIndex == 3
              //     ? BottomNavigationBarItem(
              //         icon: Image.asset(
              //           "assets/images/call_blue.png",
              //           height: 22,
              //           color: appColorBlue,
              //         ),
              //         label: "",
              //       )
              //     : BottomNavigationBarItem(
              //         icon: Image.asset(
              //           "assets/images/call_blue.png",
              //           height: 22,
              //           color: appColorGrey,
              //         ),
              //         label: "",
              //       ),
              _currentIndex == 3
                  ? BottomNavigationBarItem(
                      icon: Icon(
                        Icons.trending_up,
                        size: 25,
                        color: appColorBlue,
                      ),
                      label: "",
                    )
                  : BottomNavigationBarItem(
                      icon: Icon(
                        Icons.trending_up,
                        size: 25,
                        color: appColorGrey,
                      ),
                      label: "",
                    ),
              _currentIndex == 4
                  ? BottomNavigationBarItem(
                      icon: Image.asset(
                        "assets/images/settings.png",
                        height: 22,
                        color: appColorBlue,
                      ),
                      label: "",
                    )
                  : BottomNavigationBarItem(
                      icon: Image.asset(
                        "assets/images/settings.png",
                        height: 22,
                        color: appColorGrey,
                      ),
                      label: "",
                    ),
            ],
          ),
        ),
      ),
    );
  }
}
