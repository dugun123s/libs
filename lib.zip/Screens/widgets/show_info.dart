import 'dart:convert';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:diemchat/constatnt/Constant.dart';
import 'package:diemchat/constatnt/global.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:toast/toast.dart';

showInfoDialog(context, String title, [Function ontap]) {
  return showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          child: Container(
              child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.info,
                size: 100,
                color: appColor,
              ),
              SizedBox(
                height: 10,
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                child: Text(
                  title,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: appColor, fontSize: 15),
                ),
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                child: Row(
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: ButtonStyle(
                        overlayColor: MaterialStateProperty.resolveWith(
                          (states) {
                            return states.contains(MaterialState.pressed)
                                ? Colors.red
                                : Colors.grey;
                          },
                        ),
                        backgroundColor: MaterialStateProperty.all(Colors.grey),
                        padding: MaterialStateProperty.all(
                            EdgeInsets.symmetric(horizontal: 30)),
                      ),
                      child: const Text(
                        'Hayır',
                        style: TextStyle(fontSize: 20),
                      ),
                    ),
                    Spacer(),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        ontap();
                      },
                      style: ButtonStyle(
                        overlayColor: MaterialStateProperty.resolveWith(
                          (states) {
                            return states.contains(MaterialState.pressed)
                                ? Colors.blue
                                : Colors.grey;
                          },
                        ),
                        backgroundColor:
                            MaterialStateProperty.all(Colors.green),
                        padding: MaterialStateProperty.all(
                            EdgeInsets.symmetric(horizontal: 30)),
                      ),
                      child: const Text(
                        'Evet',
                        style: TextStyle(fontSize: 20),
                      ),
                    ),
                  ],
                ),
              )
            ],
          )),
        );
      });
}

class ShowReportDialog extends StatefulWidget {
  String userId;

  ShowReportDialog({
    @required this.userId,
  });

  @override
  State<ShowReportDialog> createState() => _ShowReportDialogState();
}

class _ShowReportDialogState extends State<ShowReportDialog> {
  bool checkBox1 = false;
  bool checkBox2 = false;
  bool checkBox3 = false;
  FirebaseAuth _auth = FirebaseAuth.instance;
  List reasonsList = [];
  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Container(
          child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(vertical: 20),
            decoration: BoxDecoration(
                color: appColor,
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(15),
                    topRight: Radius.circular(15))),
            child: Image.asset(
              'assets/images/report.png',
              width: 75,
              height: 75,
              color: Colors.white,
            ),
          ),
          CheckboxListTile(
            contentPadding: EdgeInsets.symmetric(horizontal: 20),
            title: Text(
              "Rahatsız Edici Söylem",
              style:
                  TextStyle(color: Colors.black, fontWeight: FontWeight.normal),
            ),
            value: checkBox1, checkColor: appcolor,
            activeColor: Colors.white,
            onChanged: (newValue) {
              setState(() {
                if (!checkBox1) {
                  reasonsList.add('Rahatsız Edici Söylem');
                } else {
                  reasonsList.remove('Rahatsız Edici Söylem');
                }
                checkBox1 = newValue;
              });
            },
            controlAffinity:
                ListTileControlAffinity.leading, //  <-- leading Checkbox
          ),
          CheckboxListTile(
            contentPadding: EdgeInsets.symmetric(horizontal: 20),
            title: Text(
              "Uygunsuz İçerik",
              style:
                  TextStyle(color: Colors.black, fontWeight: FontWeight.normal),
            ),
            value: checkBox2,
            checkColor: appcolor,
            activeColor: Colors.white,
            onChanged: (newValue) {
              setState(() {
                if (!checkBox2) {
                  reasonsList.add('Uygunsuz İçerik');
                } else {
                  reasonsList.remove('Uygunsuz İçerik');
                }
                checkBox2 = newValue;
              });
            },
            controlAffinity:
                ListTileControlAffinity.leading, //  <-- leading Checkbox
          ),
          CheckboxListTile(
            contentPadding: EdgeInsets.symmetric(horizontal: 20),
            title: Text(
              "Şiddet Çıplaklık",
              style:
                  TextStyle(color: Colors.black, fontWeight: FontWeight.normal),
            ),
            value: checkBox3, checkColor: appcolor,
            activeColor: Colors.white,
            onChanged: (newValue) {
              setState(() {
                if (!checkBox3) {
                  reasonsList.add('Şiddet Çıplaklık');
                } else {
                  reasonsList.remove('Şiddet Çıplaklık');
                }
                checkBox3 = newValue;
              });
            },
            controlAffinity:
                ListTileControlAffinity.leading, //  <-- leading Checkbox
          ),

          Divider(),
          // Padding(
          //   padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          //   child: Text(
          //    ,
          //     textAlign: TextAlign.center,
          //     style: TextStyle(color: appColor, fontSize: 15),
          //   ),
          // ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // ElevatedButton(
                //   onPressed: () {
                //     Navigator.pop(context);
                //   },
                //   style: ButtonStyle(
                //     overlayColor: MaterialStateProperty.resolveWith(
                //       (states) {
                //         return states.contains(MaterialState.pressed)
                //             ? Colors.red
                //             : Colors.grey;
                //       },
                //     ),
                //     backgroundColor: MaterialStateProperty.all(Colors.grey),
                //     padding: MaterialStateProperty.all(
                //         EdgeInsets.symmetric(horizontal: 30)),
                //   ),
                //   child: const Text(
                //     'İptal',
                //     style: TextStyle(fontSize: 20),
                //   ),
                // ),
                // Spacer(),
                ElevatedButton(
                  onPressed: () async {
                    await FirebaseFirestore.instance
                        .collection('users')
                        .doc(widget.userId)
                        .get()
                        .then((value) {
                      bool gonder = true;
                      if (value.data().containsKey('complains') &&
                          value['complains'].length > 0) {
                        value['complains'].forEach((element) {
                          if (element['userId'] == _auth.currentUser.uid) {
                            gonder = false;
                            Navigator.pop(context);
                            Toast.show("Şikayetiniz Gönderildi", context,
                                duration: Toast.LENGTH_SHORT,
                                gravity: Toast.BOTTOM);
                          }
                        });
                        if (gonder) {
                          value.reference.update({
                            'complains': FieldValue.arrayUnion([
                              {
                                'userId': _auth.currentUser.uid,
                                "reasons": jsonEncode(reasonsList)
                              }
                            ])
                          });
                          Navigator.pop(context);
                          if (value['complains'].length > 3) {
                            value.reference.update({'banned': true});
                            Future.delayed(Duration(seconds: 2)).then((value) {
                              Toast.show("Şikayetiniz Gönderildi", context,
                                  duration: Toast.LENGTH_SHORT,
                                  gravity: Toast.BOTTOM);
                            });
                          }
                          Toast.show("Şikayetiniz Gönderildi", context,
                              duration: Toast.LENGTH_SHORT,
                              gravity: Toast.BOTTOM);
                        }
                      } else {
                        value.reference.update({
                          'complains': FieldValue.arrayUnion([
                            {
                              'userId': _auth.currentUser.uid,
                              "reasons": jsonEncode(reasonsList)
                            }
                          ])
                        });
                        Navigator.pop(context);
                        Toast.show("Şikayetiniz Gönderildi", context,
                            duration: Toast.LENGTH_SHORT,
                            gravity: Toast.BOTTOM);
                      }
                    });
                  },
                  style: ButtonStyle(
                    overlayColor: MaterialStateProperty.resolveWith(
                      (states) {
                        return states.contains(MaterialState.pressed)
                            ? Colors.green
                            : Colors.grey;
                      },
                    ),
                    backgroundColor: MaterialStateProperty.all(appColor),
                    padding: MaterialStateProperty.all(
                        EdgeInsets.symmetric(horizontal: 30)),
                  ),
                  child: const Text(
                    'Şikayet Et',
                    style: TextStyle(fontSize: 20),
                  ),
                ),
              ],
            ),
          )
        ],
      )),
    );
  }
}
