import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dashed_circle/dashed_circle.dart';
import 'package:diemchat/constatnt/Constant.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:diemchat/Screens/privacy.dart';
import 'package:diemchat/constatnt/global.dart';
import 'dart:math' as math;

import '../helper/sizeconfig.dart';
import 'contactinfo.dart';

class UserGifts extends StatefulWidget {
  String userId;
  String userName;
  UserGifts({@required this.userId, this.userName});
  @override
  UserGiftsState createState() {
    return new UserGiftsState();
  }
}

class UserGiftsState extends State<UserGifts> {
  List<Color> colors = [];
  getRandomColor() {
    for (var i = 0; i < 100; i++) {
      colors.add(Color.fromRGBO(math.Random().nextInt(200),
          math.Random().nextInt(200), math.Random().nextInt(200), 1));
    }
  }

  @override
  void initState() {
    getRandomColor();
    super.initState();
  }

  FirebaseAuth _auth = FirebaseAuth.instance;
  Widget noGift() {
    if (widget.userId == _auth.currentUser.uid) {
      return Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: EdgeInsets.only(bottom: 15),
              child: CustomText(
                text: "Hediye Listen Boş",
                alignment: Alignment.center,
                fontSize: SizeConfig.blockSizeHorizontal * 5,
                fontWeight: FontWeight.bold,
                fontFamily: "MontserratBold",
                color: appcolor,
              ),
            ),
            Image.asset(
              "assets/images/no-gift.png",
              width: 250,
            ),
            SizedBox(
              height: 15,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Text(
                "Hediye almak ve hediye göndermek için shuffle listesine göz at",
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      );
    } else {
      return Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              "assets/images/no-gift.png",
              width: 250,
            ),
            SizedBox(
              height: 5,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "${widget.userName}",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontFamily: "MontserratBold",
                    ),
                  ),
                  Text(
                    "'nin hiç hediyesi yok",
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 15,
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
              decoration: BoxDecoration(
                  color: appColor, borderRadius: BorderRadius.circular(8)),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image.asset(
                    'assets/stickers/gift.png',
                    width: 35,
                    height: 35,
                    color: Colors.white,
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  Text(
                    "İlk Hediyesini Sen Gönder",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 13),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgcolor,
      appBar: AppBar(
        backgroundColor: appColorWhite,
        title: Text(
          "Hediyeler",
          style: TextStyle(
              fontFamily: "MontserratBold", fontSize: 17, color: appColorBlack),
        ),
        centerTitle: true,
        leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(
              Icons.arrow_back_ios,
              color: appColorBlue,
            )),
      ),
      body: Container(
          child: StreamBuilder<DocumentSnapshot>(
              stream: FirebaseFirestore.instance
                  .collection("users")
                  .doc(widget.userId)
                  .snapshots(),
              builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot2) {
                if (snapshot2.hasData) {
                  if (snapshot2.data.data().containsKey('gifts')) {
                    if (snapshot2.data["gifts"].length == 0) {
                      noGift();
                    }
                    return ListView.builder(
                        itemCount: snapshot2.data["gifts"].length,
                        itemBuilder: (BuildContext context, int index) {
                          return UserPreview(
                            color: colors[index],
                            giftId: snapshot2.data["gifts"][index]['giftId'],
                            userId: snapshot2.data["gifts"][index]['userId'],
                          );
                        });
                  } else {
                    return noGift();
                  }
                }
                return Row(
                  children: [
                    Container(
                      height: 35,
                      width: 35,
                      child: CircleAvatar(
                        //radius: 60,
                        foregroundColor: Theme.of(context).primaryColor,
                        backgroundColor: Colors.grey,
                      ),
                    ),
                  ],
                );
              })),
    );
  }
}

class UserPreview extends StatefulWidget {
  String userId;
  String giftId;
  Color color;
  UserPreview(
      {@required this.userId, @required this.giftId, @required this.color});

  @override
  State<UserPreview> createState() => _UserPreviewState();
}

class _UserPreviewState extends State<UserPreview> {
  String userPhoto = '';
  String userName = '';
  Future getUserInfo() async {
    print(widget.userId);
    await FirebaseFirestore.instance
        .collection('users')
        .doc(widget.userId)
        .get()
        .then((value) {
      if (value.exists) {
        setState(() {
          userName = value['nick'];
          userPhoto = value['photo'];
        });
      }
    });
  }

  @override
  void initState() {
    getUserInfo();
    super.initState();
  }
  FirebaseAuth _auth = FirebaseAuth.instance;
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => ContactInfo(
                    id: widget.userId,
                    currentUser: _auth.currentUser.uid,
                  )),
        );
      },
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
        color: Colors.white,
        child: Row(
          children: [
            Container(
              height: 50,
              width: 50,
              margin: EdgeInsets.only(right: 10),
              child: DashedCircle(
                gapSize: 20,
                dashes: 20,
                color: widget.color,
                child: Padding(
                  padding: EdgeInsets.all(0.8),
                  child: userPhoto == ''
                      ? CircleAvatar(
                          radius: 20,
                          foregroundColor: Theme.of(context).primaryColor,
                          backgroundColor: Colors.grey,
                        )
                      : CircleAvatar(
                          radius: 20,
                          foregroundColor: Theme.of(context).primaryColor,
                          backgroundColor: Colors.grey,
                          backgroundImage: new NetworkImage(
                            userPhoto,
                          ),
                        ),
                ),
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                userName == ''
                    ? Container()
                    : Container(
                        child: Text(
                          userName,
                          style: new TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              color: appColorBlack),
                        ),
                      ),
                SizedBox(
                  height: 5,
                ),
                Text(
                  widget.giftId.split('_')[0] + ' Kredi',
                  style: TextStyle(
                      fontSize: 13,
                      letterSpacing: 0.2,
                      color: appColor,
                      fontWeight: FontWeight.bold),
                )
              ],
            ),
            Spacer(),
            Row(
              children: [
                Image.asset(
                  'assets/stickers/${widget.giftId.split('_')[1]}.png',
                  width: 60,
                  height: 60,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
