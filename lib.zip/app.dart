import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:diemchat/main.dart';
import 'package:diemchat/provider/user.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:diemchat/Screens/bottombar/newTabber.dart';
import 'package:diemchat/Screens/intro.dart';
import 'package:diemchat/provider/countries.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:provider/provider.dart';

class App extends StatefulWidget {
  @override
  _AppState createState() => _AppState();
}

class _AppState extends State<App> with WidgetsBindingObserver {
  bool logged = false;
  FirebaseAuth _auth = FirebaseAuth.instance;
  @override
  void initState() {
    if (_auth.currentUser != null) {
      FirebaseFirestore.instance
          .collection("users")
          .doc(_auth.currentUser.uid)
          .update({"status": FieldValue.serverTimestamp(), "inChat": ""});
      FirebaseDatabase.instance
          .reference()
          .child('users')
          .child(_auth.currentUser.uid)
          .update({"status": "Online", "inChat": ""});
    }

    FirebaseMessaging.instance
        .getInitialMessage()
        .then((RemoteMessage message) {});
    final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
        FlutterLocalNotificationsPlugin();
    FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
      print(message);
      RemoteNotification notification = message.notification;
      AndroidNotification android = message.notification?.android;
      if (notification != null && android != null) {
        flutterLocalNotificationsPlugin.show(
            notification.hashCode,
            notification.title,
            notification.body,
            NotificationDetails(
              android: AndroidNotificationDetails(
                channel.id,
                channel.name,
                channel.description,
                // TODO add a proper drawable resource to android, for now using
                //      one that already exists in example app.
                icon: '@mipmap/ic_launcher',
              ),
            ));
      }
    });
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      if (_auth.currentUser != null) {
        FirebaseDatabase.instance
            .reference()
            .child('users')
            .child(_auth.currentUser.uid)
            .update({"status": "Online", "inChat": ""});
        FirebaseDatabase.instance
            .reference()
            .child('users')
            .child(_auth.currentUser.uid)
            .onDisconnect()
            .update({"status": DateTime.now().toIso8601String(), "inChat": ""});
      }
    } else {
      if (_auth.currentUser != null)
        FirebaseDatabase.instance
            .reference()
            .child('users')
            .child(_auth.currentUser.uid)
            .update({"status": DateTime.now().toIso8601String(), "inChat": ""});
    }
  }

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
        providers: [
          ChangeNotifierProvider(
            create: (context) => CountryProvider(),
          ),
          ChangeNotifierProvider(
            create: (context) => UserProvider(),
          ),
        ],
        child: MaterialApp(
          title: "Diem",
          theme: ThemeData(
            fontFamily: 'Montserrat',
          ),

          debugShowCheckedModeBanner: false,
          home: _handleCurrentScreen(),
          // home: PhoneAuthGetPhone(),
        ));
  }

  Widget _handleCurrentScreen() {
    if (_auth.currentUser != null) {
      return TabbarScreen();
    } else {
      return Intro();
    }

    // }
  }
}
