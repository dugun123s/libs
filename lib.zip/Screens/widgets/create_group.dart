import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:diemchat/Screens/widgets/radio_item.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:toast/toast.dart';
import 'dart:math' as math;
import '../../constatnt/global.dart';
import '../../helper/sizeconfig.dart';

class CreateGroup extends StatefulWidget {
  @override
  State<CreateGroup> createState() => _CreateGroupState();
}

class _CreateGroupState extends State<CreateGroup> {
  File _image;
  bool loading = false;
  TextEditingController titleController = TextEditingController();
  FirebaseAuth _auth = FirebaseAuth.instance;
  getRandomNumberForImage() {
    return math.Random().nextInt(21) + 1;
  }

  List<RadioModel> sampleData = new List<RadioModel>();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    sampleData.add(new RadioModel('chats', true, 'Yazılı Sohbet', 'April 16'));
    sampleData
        .add(new RadioModel('voiceChat', false, 'Sesli Sohbet', 'April 17'));
    sampleData.add(
        new RadioModel('videoChat', false, 'Görüntülü Sohbet', 'April 18'));
  }

  int type = 0;
  @override
  Widget build(BuildContext context) {
    return Dialog(
      insetPadding: EdgeInsets.symmetric(
        horizontal: 15,
      ),
      child: Container(
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
            color: Colors.white, borderRadius: BorderRadius.circular(10)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Material(
              child: Container(
                height: 60,
                width: 60,
                child: _image != null
                    ? CircleAvatar(
                        radius: 30,
                        foregroundColor: Theme.of(context).primaryColor,
                        backgroundColor: Colors.grey,
                        backgroundImage: FileImage(_image),
                      )
                    : CircleAvatar(
                        radius: 30,
                        foregroundColor: Theme.of(context).primaryColor,
                        backgroundColor: Colors.grey,
                        child: IconButton(
                          icon: Icon(Icons.photo),
                          color: Colors.white,
                          onPressed: () async {
                            setState(() {
                              loading = true;
                            });
                            final picker = ImagePicker();
                            final imageFile = await picker.getImage(
                                source: ImageSource.gallery,
                                imageQuality: 50,
                                maxHeight: 1000,
                                maxWidth: 1000);

                            File croppedFile = await ImageCropper().cropImage(
                                sourcePath: imageFile.path,
                                aspectRatioPresets: Platform.isAndroid
                                    ? [
                                        CropAspectRatioPreset.square,
                                        CropAspectRatioPreset.ratio3x2,
                                        CropAspectRatioPreset.original,
                                        CropAspectRatioPreset.ratio4x3,
                                        CropAspectRatioPreset.ratio16x9
                                      ]
                                    : [
                                        CropAspectRatioPreset.original,
                                        CropAspectRatioPreset.square,
                                        CropAspectRatioPreset.ratio3x2,
                                        CropAspectRatioPreset.ratio4x3,
                                        CropAspectRatioPreset.ratio5x3,
                                        CropAspectRatioPreset.ratio5x4,
                                        CropAspectRatioPreset.ratio7x5,
                                        CropAspectRatioPreset.ratio16x9
                                      ],
                                androidUiSettings: AndroidUiSettings(
                                    toolbarTitle: '',
                                    toolbarColor: Colors.black,
                                    toolbarWidgetColor: Colors.white,
                                    statusBarColor: Colors.grey,
                                    initAspectRatio:
                                        CropAspectRatioPreset.square,
                                    lockAspectRatio: false),
                                iosUiSettings: IOSUiSettings(
                                  title: '',
                                ));
                            if (croppedFile != null) {
                              setState(() {
                                _image = croppedFile;
                              });
                            }
                          },
                        ),
                      ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
                margin: EdgeInsets.symmetric(vertical: 5),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    new InkWell(
                      //highlightColor: Colors.red,
                      splashColor: Colors.blueAccent,
                      onTap: () {
                        setState(() {
                          type = 0;
                          sampleData
                              .forEach((element) => element.isSelected = false);
                          sampleData[0].isSelected = true;
                        });
                      },
                      child: new RadioItem(sampleData[0]),
                    ),
                    new InkWell(
                      //highlightColor: Colors.red,
                      splashColor: Colors.blueAccent,
                      onTap: () {
                        setState(() {
                          type = 1;
                          sampleData
                              .forEach((element) => element.isSelected = false);
                          sampleData[1].isSelected = true;
                        });
                      },
                      child: new RadioItem(sampleData[1]),
                    ),
                    new InkWell(
                      //highlightColor: Colors.red,
                      splashColor: Colors.blueAccent,
                      onTap: () {
                        setState(() {
                          type = 2;
                          sampleData
                              .forEach((element) => element.isSelected = false);
                          sampleData[2].isSelected = true;
                        });
                      },
                      child: new RadioItem(sampleData[2]),
                    )
                  ],
                )),
            Material(
              child: CustomtextField(
                controller: titleController,
                maxLines: 1,
                textInputAction: TextInputAction.next,
                hintText: 'Group ismi belirle',
                prefixIcon: Container(
                  margin: EdgeInsets.all(10.0),
                  child: Icon(
                    Icons.campaign,
                    color: Colors.black,
                    size: 20.0,
                  ),
                ),
              ),
            ),
            SizedBox(height: 10),
            SizedBox(
              height: SizeConfig.blockSizeVertical * 5,
              width: SizeConfig.screenWidth,
              // ignore: deprecated_member_use
              child: FlatButton(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5.0),
                ),
                color: appColorGreen,
                textColor: Colors.white,
                padding: EdgeInsets.all(8.0),
                onPressed: () async {
                  if (titleController.text.length > 0 && loading == false) {
                    String date =
                        DateTime.now().millisecondsSinceEpoch.toString();
                    if (_image != null) {
                      String fileName =
                          DateTime.now().millisecondsSinceEpoch.toString();

                      String imageLocation =
                          'GroopPic/${_auth.currentUser.uid}/${DateTime.now()}.jpg';

                      await firebase_storage.FirebaseStorage.instance
                          .ref(imageLocation)
                          .putFile(_image);
                      String downloadUrl = await firebase_storage
                          .FirebaseStorage.instance
                          .ref(imageLocation)
                          .getDownloadURL();
                      await _auth.currentUser.updatePhotoURL(downloadUrl);

                      FirebaseFirestore.instance
                          .collection("groop")
                          .doc(date)
                          .set({
                        "groupImage": downloadUrl,
                        "groupName": titleController.text,
                        "joins": [_auth.currentUser.uid],
                        "created": FieldValue.serverTimestamp(),
                        "type": type,
                        "content": "Grup Oluşturuldu",
                        "createrId": [_auth.currentUser.uid],
                        "pins": [],
                        "muteds": [],
                      });
                    } else {
                      FirebaseFirestore.instance
                          .collection("groop")
                          .doc(date)
                          .set({
                        "groupImage": getRandomNumberForImage().toString(),
                        "groupName": titleController.text.trim(),
                        "joins": [_auth.currentUser.uid],
                        "created": FieldValue.serverTimestamp(),
                        "type": type,
                        "content": "Grup Oluşturuldu",
                        "createrId": [_auth.currentUser.uid],
                        "pins": [],
                        "muteds": [],
                      });
                    }

                    FirebaseFirestore.instance
                        .collection("chatList")
                        .doc(_auth.currentUser.uid)
                        .collection(_auth.currentUser.uid)
                        .doc(date)
                        .set({
                      'timestamp': FieldValue.serverTimestamp(),
                      'chatType': "group",
                      "name": titleController.text.trim(),
                    });
                    Navigator.pop(context);
                  } else {
                    Toast.show("Enter group name", context,
                        duration: Toast.LENGTH_SHORT, gravity: Toast.BOTTOM);
                  }
                },
                child: loading
                    ? Container(
                        width: 15,
                        height: 15,
                        child: CircularProgressIndicator(
                            valueColor:
                                AlwaysStoppedAnimation<Color>(Colors.white)),
                      )
                    : Text(
                        "OLUŞTUR",
                        style: TextStyle(
                            fontSize: 14.0, fontFamily: "MontserratBold"),
                      ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
