import 'dart:io';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:diemchat/constatnt/Constant.dart';
import 'package:diemchat/constatnt/global.dart';
import 'package:diemchat/helper/sizeconfig.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:toast/toast.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;

class EditProfile extends StatefulWidget {
  @override
  _EditProfileState createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  String userId;
  bool isLoading = true;
  final TextEditingController nameController = TextEditingController();
  final TextEditingController bioController = TextEditingController();
  final FirebaseDatabase _database = FirebaseDatabase.instance;

  File _image;
  Future getImage() async {
    final picker = ImagePicker();
    final imageFile =
        await picker.getImage(source: ImageSource.gallery, imageQuality: 50);

    if (imageFile != null) {
      setState(() {
        if (imageFile != null) {
          _image = File(imageFile.path);
        } else {
          print('No image selected.');
        }
      });
    }
  }

  String bio;
  Future getBio() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    setState(() {
      print(pref.getString("bio"));
      bioController.text = pref.getString("bio");
      nameController.text = pref.getString("nick");
    });
  }

  FirebaseAuth _auth = FirebaseAuth.instance;
  @override
  void initState() {
    getBio();
    setState(() {
      userId = _auth.currentUser.uid;
      isLoading = false;
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
        appBar: AppBar(
          backgroundColor: appColorWhite,
          title: Text(
            "Profili Düzenle",
            style: TextStyle(
                fontFamily: "MontserratBold",
                fontSize: 17,
                color: appColorBlack),
          ),
          centerTitle: true,
          leading: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: Icon(
                Icons.arrow_back_ios,
                color: appColorBlue,
              )),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 12),
              child: IconButton(
                  padding: EdgeInsets.all(0),
                  onPressed: () {
                    if (nameController.text.isNotEmpty) {
                      updateInfo();
                    }
                  },
                  icon: AutoSizeText(
                    "Tamam",
                    minFontSize: 8,
                    maxLines: 1,
                    style: TextStyle(
                        fontSize: 13,
                        color: appColorBlue,
                        fontFamily: "MontserratBold"),
                  )),
            ),
          ],
        ),
        body: Stack(
          children: <Widget>[
            isLoading == true ? Center(child: loader()) : _userInfo(),
          ],
        ));
  }

  Widget _userInfo() {
    return SingleChildScrollView(
      padding: EdgeInsets.symmetric(horizontal: 0),
      child: Container(
        color: bgcolor,
        child: Column(
          children: <Widget>[
            Container(height: 20),
            Padding(
              padding: const EdgeInsets.only(left: 20, right: 20),
              child: Column(
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(100.0),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(3),
                          child: GestureDetector(
                            onTap: () {
                              getImage();
                            },
                            child: CircleAvatar(
                              backgroundColor: Colors.white,
                              backgroundImage: _image != null
                                  ? FileImage(_image)
                                  : globalImage.length > 0
                                      ? NetworkImage(globalImage)
                                      : NetworkImage(noImage),
                              radius: 40,
                            ),
                          ),
                        ),
                      ),
                      Container(width: 15),
                      Expanded(
                          child: Text(
                        "Adınızı girin ve isteğe bağlı bir profil resmi ekleyin",
                        textAlign: TextAlign.center,
                        style: TextStyle(color: appColorBlack, fontSize: 13),
                      ))
                    ],
                  ),
                  Container(height: 5),
                  Padding(
                    padding: const EdgeInsets.only(left: 28),
                    child: Row(
                      children: [
                        Text(
                          "Düzenle",
                          style: TextStyle(
                              color: appColorBlue,
                              fontWeight: FontWeight.bold,
                              fontSize: 13),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(height: 15),

            Container(
              height: 30,
              color: Colors.white,
              child: Column(
                children: [
                  Container(
                    height: 0.5,
                    color: Colors.grey[400],
                  ),
                  Expanded(child: Container()),
                  Padding(
                    padding: const EdgeInsets.only(left: 15, bottom: 5),
                    child: CustomText(
                      text: "Kullanıcı Adı",
                      alignment: Alignment.centerLeft,
                      fontSize: 13,
                      color: appColorBlack,
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 18),
              child: CustomtextField3(
                  textAlign: TextAlign.start,
                  controller: nameController,
                  maxLines: 1,
                  readOnly: true,
                  textInputAction: TextInputAction.next,
                  hintText: 'Kullanıcı Adını Gir'),
            ),

            Container(
              height: 30,
              color: Colors.white,
              child: Column(
                children: [
                  Expanded(child: Container()),
                  Padding(
                    padding: const EdgeInsets.only(left: 15, bottom: 5),
                    child: CustomText(
                      text: "Biografi",
                      alignment: Alignment.centerLeft,
                      fontSize: 13,
                      color: appColorBlack,
                    ),
                  ),
                ],
              ),
            ),
            Padding(
                padding: const EdgeInsets.only(left: 17),
                child: TextField(
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 16,
                      fontWeight: FontWeight.bold),
                  maxLines: 4,
                  controller: bioController,
                  decoration: InputDecoration(
                      hintText: 'Biografini yaz', border: InputBorder.none),
                )),

            Container(
              height: 0.5,
              color: Colors.grey[400],
            ),

            // Container(
            //   height: 60,
            //   color: Colors.grey[100],
            //   child: Column(
            //     children: [
            //       Expanded(child: Container()),
            //       Padding(
            //         padding: const EdgeInsets.only(left: 15, bottom: 5),
            //         child: CustomText(
            //           text: "ABOUT",
            //           alignment: Alignment.centerLeft,
            //           fontSize: 13,
            //           color: appColorBlack,
            //         ),
            //       ),
            //       Container(
            //         height: 0.5,
            //         color: Colors.grey[400],
            //       ),
            //     ],
            //   ),
            // ),
            // Container(
            //   height: 0.5,
            //   color: Colors.grey[400],
            // ),
            // Padding(
            //   padding: const EdgeInsets.only(left: 15),
            //   child: CustomtextField3(
            //       textAlign: TextAlign.start,
            //       controller: bioController,
            //       maxLines: 1,
            //       textInputAction: TextInputAction.next,
            //       hintText: 'Enter Bio'),
            // ),
            // Container(
            //   height: 0.5,
            //   color: Colors.grey[400],
            // ),
          ],
        ),
      ),
    );
  }

  updateInfo() async {
    if (_image != null) {
      setState(() {
        isLoading = true;
      });
      final dir = await getTemporaryDirectory();
      final targetPath = dir.absolute.path +
          "/${DateTime.now().millisecondsSinceEpoch.toString()}.jpg";
      await FirebaseFirestore.instance
          .collection("users")
          .doc(userId)
          .update({"bio": bioController.text});
      await FlutterImageCompress.compressAndGetFile(
        _image.absolute.path,
        targetPath,
        quality: 20,
      ).then((value) async {
        print("Compressed");
        String fileName = DateTime.now().millisecondsSinceEpoch.toString();

        String imageLocation =
            'Back Image/${_auth.currentUser.uid}/${DateTime.now().millisecondsSinceEpoch.toString()}';

        await firebase_storage.FirebaseStorage.instance
            .ref(imageLocation)
            .putFile(value);
        String downloadUrl = await firebase_storage.FirebaseStorage.instance
            .ref(imageLocation)
            .getDownloadURL();

        await FirebaseFirestore.instance.collection("users").doc(userId).update(
            {"bio": bioController.text, "photo": downloadUrl.toString()});
        SharedPreferences pref = await SharedPreferences.getInstance();
        pref.setString("bio", bioController.text);
        Toast.show("Profil Başarıyla Güncellendi", context,
            duration: Toast.LENGTH_SHORT, gravity: Toast.BOTTOM);
        setState(() {
          isLoading = false;
        });
      });
    } else {
      await FirebaseFirestore.instance
          .collection("users")
          .doc(userId)
          .update({"bio": bioController.text});
      SharedPreferences pref = await SharedPreferences.getInstance();
      pref.setString("bio", bioController.text);
      Toast.show("Profil Başarıyla Güncellendi", context,
          duration: Toast.LENGTH_SHORT, gravity: Toast.BOTTOM);
    }
  }
}
