import 'package:firebase_database/firebase_database.dart';

class GroupModel {
  String groupId;
  List joins;
  String createrId;
  String groupName;
  String groupImage;

  GroupModel(this.joins, this.groupId, this.createrId, this.groupName,
      this.groupImage);

  // GroupModel.fromSnapshot(DataSnapshot snapshot)
  //     : key = snapshot.key,
  //       userId = snapshot.value["userId"],
  //       createrId = snapshot.value["createrId"],
  //       castName = snapshot.value["castName"],
  //       castDesc = snapshot.value["castDesc"],
  //       castImage = snapshot.value["castImage"];

  // toJson() {
  //   return {
  //     "userId": userId,
  //     "createrId": createrId,
  //     "castName": castName,
  //     "castDesc": castDesc,
  //     "castImage": castImage
  //   };
  // }
}
