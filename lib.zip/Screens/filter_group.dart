import 'package:badges/badges.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dashed_circle/dashed_circle.dart';
import 'package:diemchat/Screens/groupChat/voiceCall.dart';
import 'package:diemchat/constatnt/global.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'dart:math' as math;
import '../helper/sizeconfig.dart';
import 'groupChat/groupChat.dart';
import 'groupChat/videoCall.dart';

class FilterGroup extends StatefulWidget {
  int type;
  FilterGroup({@required this.type});

  @override
  State<FilterGroup> createState() => _FilterGroupState();
}

class _FilterGroupState extends State<FilterGroup> {
  FirebaseAuth _auth = FirebaseAuth.instance;
  List<DocumentSnapshot> groopList = [];

  getRandomColor() {
    return Color.fromRGBO(math.Random().nextInt(200),
        math.Random().nextInt(200), math.Random().nextInt(200), 1);
  }

  getAppBar(image, title) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
          'assets/images/$image.png',
          height: 40,
          width: 40,
        ),
        SizedBox(
          height: 8,
        ),
        Text(
          title,
          style: TextStyle(
              letterSpacing: 0.56,
              color: appColor,
              fontSize: 20,
              fontWeight: FontWeight.bold),
        )
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(100),
          child: Padding(
              padding: EdgeInsets.only(
                  top: MediaQuery.of(context).padding.top, bottom: 10),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Align(
                    alignment: Alignment.topLeft,
                    child: IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: Icon(
                          Icons.arrow_back_ios,
                          color: appColor,
                        )),
                  ),
                  widget.type == 0
                      ? getAppBar('chats', "Yazılı Sohbet")
                      : widget.type == 2
                          ? getAppBar('videoChat', "Video Sohbet")
                          : getAppBar('voiceChat', "Sesli Sohbet"),
                ],
              )),
        ),
        body: StreamBuilder(
          stream: FirebaseFirestore.instance
              .collection("groop")
              .where("created",
                  isGreaterThan: DateTime.now().subtract(Duration(days: 1)))
              .where('type', isEqualTo: widget.type)
              .orderBy("created", descending: true)
              .snapshots(),
          builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (snapshot.hasData) {
              return Container(
                width: MediaQuery.of(context).size.width,
                child: snapshot.data.docs.length > 0
                    ? ListView.builder(
                        itemCount: snapshot.data.docs.length,
                        shrinkWrap: true,
                        itemBuilder: (context, int index) {
                          DocumentSnapshot doc = snapshot.data.docs[index];
                          return Container(
                            child: InkWell(
                              onTap: () {
                                if (widget.type == 0) {
                                  Navigator.push(
                                      context,
                                      CupertinoPageRoute(
                                          builder: (context) => GroupChat(
                                                joins: doc['joins'],
                                                joined: doc["joins"].contains(
                                                    _auth.currentUser.uid),
                                                currentuser:
                                                    _auth.currentUser.uid,
                                                currentusername: globalName,
                                                currentuserimage: globalImage,
                                                peerID: doc.id,
                                                peerUrl: doc['groupImage'],
                                                peerName: doc['groupName'],
                                                archive: false,
                                                mute: false,
                                                muteds: doc['muteds'],
                                                pins: doc['pins'],
                                              )));
                                } else if (widget.type == 2) {
                                  Navigator.push(
                                      context,
                                      CupertinoPageRoute(
                                          builder: (context) => GroupVideoCall(
                                              groupImage: doc['groupImage'],
                                              groupName: doc['groupName'],
                                              kisiler: doc['joins'],
                                              joined: doc['joins'].contains(
                                                  _auth.currentUser.uid),
                                              documentId: doc.id)));
                                } else if (widget.type == 1) {
                                  Navigator.push(
                                      context,
                                      CupertinoPageRoute(
                                          builder: (context) => GroupVoiceCall(
                                              groupImage: doc['groupImage'],
                                              groupName: doc['groupName'],
                                              kisiler: doc['joins'],
                                              joined: doc['joins'].contains(
                                                  _auth.currentUser.uid),
                                              documentId: doc.id)));
                                }
                              },
                              child: Column(
                                children: [
                                  Divider(height: 1, color: Colors.black12),
                                  Container(
                                    padding: EdgeInsets.symmetric(
                                        vertical: 5, horizontal: 15),
                                    color: Colors.white,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          children: [
                                            SizedBox(
                                              width: 5,
                                            ),
                                            Container(
                                                margin:
                                                    EdgeInsets.only(top: 10),
                                                height: 50,
                                                width: 50,
                                                child: doc["groupImage"]
                                                            .toString()
                                                            .length >
                                                        3
                                                    ? Container(
                                                        height: 50,
                                                        width: 50,
                                                        child: DashedCircle(
                                                          gapSize: 20,
                                                          dashes: 20,
                                                          color:
                                                              getRandomColor(),
                                                          child: Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(0.75),
                                                            child: CircleAvatar(
                                                              //radius: 60,
                                                              foregroundColor:
                                                                  Theme.of(
                                                                          context)
                                                                      .primaryColor,
                                                              backgroundColor:
                                                                  Colors.grey,
                                                              backgroundImage:
                                                                  new NetworkImage(
                                                                      doc['groupImage']),
                                                            ),
                                                          ),
                                                        ),
                                                      )
                                                    : Container(
                                                        height: 50,
                                                        width: 50,
                                                        decoration:
                                                            BoxDecoration(
                                                                color: Colors
                                                                    .grey[400],
                                                                shape: BoxShape
                                                                    .circle),
                                                        child: DashedCircle(
                                                          gapSize: 20,
                                                          dashes: 20,
                                                          color:
                                                              getRandomColor(),
                                                          child: Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(0.75),
                                                            child: Image.asset(
                                                              "assets/images/${doc['groupImage']}.png",
                                                              fit: BoxFit.cover,
                                                            ),
                                                          ),
                                                        ))),
                                            SizedBox(
                                              width: 8,
                                            ),
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                SizedBox(
                                                  height: 8,
                                                ),
                                                Container(
                                                  width: MediaQuery.of(context)
                                                          .size
                                                          .width /
                                                      1.5,
                                                  child: Text(
                                                    doc["groupName"] ?? "",
                                                    style: new TextStyle(
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: 14,
                                                        color: appColorBlack),
                                                  ),
                                                ),
                                                SizedBox(
                                                  height: 8,
                                                ),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 0),
                                                  child: msgTypeWidget(
                                                      doc['type'],
                                                      doc['content']),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Row(children: [
                                          doc['type'] < 1
                                              ? Container()
                                              : Container(
                                                  width: 50,
                                                  margin: EdgeInsets.only(
                                                      top: 12, right: 15),
                                                  child: StreamBuilder<Event>(
                                                      stream: FirebaseDatabase
                                                          .instance
                                                          .reference()
                                                          .child('groopCall')
                                                          .child(doc.id)
                                                          .onValue,
                                                      builder:
                                                          (context, snapshot) {
                                                        if (snapshot.hasError) {
                                                          return Text(
                                                            '',
                                                            style: TextStyle(
                                                                color: Colors
                                                                    .green),
                                                          );
                                                        }
                                                        if (snapshot.hasData) {
                                                          return snapshot
                                                                  .data
                                                                  .snapshot
                                                                  .exists
                                                              ? Badge(
                                                                  shape:
                                                                      BadgeShape
                                                                          .square,
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              5),
                                                                  badgeColor:
                                                                      appColor,
                                                                  position: BadgePosition
                                                                      .topEnd(
                                                                          top:
                                                                              -12,
                                                                          end:
                                                                              -4),
                                                                  padding: EdgeInsets
                                                                      .symmetric(
                                                                          horizontal:
                                                                              5,
                                                                          vertical:
                                                                              3),
                                                                  badgeContent:
                                                                      Text(
                                                                    snapshot
                                                                        .data
                                                                        .snapshot
                                                                        .value
                                                                        .length
                                                                        .toString(),
                                                                    style: TextStyle(
                                                                        color: Colors
                                                                            .white,
                                                                        fontSize:
                                                                            12,
                                                                        fontWeight:
                                                                            FontWeight.bold),
                                                                  ),
                                                                  child: Icon(
                                                                    Icons.group,
                                                                    size: 30,
                                                                    color:
                                                                        appColor,
                                                                  ),
                                                                )
                                                              : Container();
                                                        }
                                                        return Container();
                                                      }),
                                                ),
                                          doc["joins"].length == 0
                                              ? Container()
                                              : Container(
                                                  height: 40,
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 0),
                                                  child: ListView.builder(
                                                      itemCount:
                                                          doc["joins"].length,
                                                      scrollDirection:
                                                          Axis.horizontal,
                                                      shrinkWrap: true,
                                                      itemBuilder:
                                                          (context, int index) {
                                                        return StreamBuilder(
                                                            stream: FirebaseFirestore
                                                                .instance
                                                                .collection(
                                                                    "users")
                                                                .doc(
                                                                    doc["joins"]
                                                                        [index])
                                                                .snapshots(),
                                                            builder: (context,
                                                                snapshot) {
                                                              if (snapshot
                                                                  .hasData) {
                                                                return Container(
                                                                  height: 40,
                                                                  width: 40,
                                                                  margin: EdgeInsets
                                                                      .only(
                                                                          right:
                                                                              10),
                                                                  child:
                                                                      DashedCircle(
                                                                    gapSize: 20,
                                                                    dashes: 20,
                                                                    color:
                                                                        getRandomColor(),
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          EdgeInsets.all(
                                                                              0.8),
                                                                      child:
                                                                          CircleAvatar(
                                                                        radius:
                                                                            20,
                                                                        foregroundColor:
                                                                            Theme.of(context).primaryColor,
                                                                        backgroundColor:
                                                                            Colors.grey,
                                                                        backgroundImage:
                                                                            new NetworkImage(
                                                                          snapshot
                                                                              .data["photo"],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                );
                                                              }
                                                              return Container(
                                                                margin: EdgeInsets
                                                                    .only(
                                                                        right:
                                                                            10),
                                                                height: 40,
                                                                width: 40,
                                                                child:
                                                                    DashedCircle(
                                                                  gapSize: 20,
                                                                  dashes: 20,
                                                                  color:
                                                                      getRandomColor(),
                                                                  child:
                                                                      Padding(
                                                                    padding: const EdgeInsets
                                                                            .all(
                                                                        0.75),
                                                                    child:
                                                                        CircleAvatar(
                                                                      //radius: 60,
                                                                      foregroundColor:
                                                                          Theme.of(context)
                                                                              .primaryColor,
                                                                      backgroundColor:
                                                                          Colors
                                                                              .grey,
                                                                    ),
                                                                  ),
                                                                ),
                                                              );
                                                            });
                                                      }),
                                                ),
                                        ]),
                                        SizedBox(
                                          height: 5,
                                        )
                                      ],
                                    ),
                                  ),
                                  Divider(height: 1, color: Colors.black45),
                                ],
                              ),
                            ),
                          );
                        },
                      )
                    : Center(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Padding(
                              padding: EdgeInsets.only(bottom: 15),
                              child: CustomText(
                                text: "Sohbet Listen Boş",
                                alignment: Alignment.center,
                                fontSize: SizeConfig.blockSizeHorizontal * 5,
                                fontWeight: FontWeight.bold,
                                fontFamily: "MontserratBold",
                                color: appColorBlack,
                              ),
                            ),
                            Image.asset(
                              "assets/images/noimage.jpeg",
                              width: 200,
                            ),
                            SizedBox(
                              height: 15,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 40),
                              child: Text(
                                "Sohbet listende kimse yok mesajlaşman için shuffle listesine göz at",
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ],
                        ),
                      ),
              );
            }
            return Container(
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              alignment: Alignment.center,
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.max,
                  children: <Widget>[
                    CupertinoActivityIndicator(),
                  ]),
            );
          },
        ));
  }

  Widget msgTypeWidget(int type, String content) {
    return new Container(
      padding: const EdgeInsets.only(top: 0),
      width: MediaQuery.of(context).size.width / 1.4,
      child: type == 1
          ? Row(
              children: [
                Icon(
                  Icons.camera_alt,
                  color: Colors.grey,
                  size: 17,
                ),
                Text(
                  "  Photo",
                  maxLines: 2,
                  style: new TextStyle(
                      color: Colors.deepPurple.shade900,
                      fontSize: 12.0,
                      fontWeight: FontWeight.w700),
                ),
              ],
            )
          : type == 4
              ? Row(
                  children: [
                    Icon(
                      Icons.video_call,
                      color: Colors.grey,
                      size: 17,
                    ),
                    Text(
                      "  Video",
                      maxLines: 2,
                      style: new TextStyle(
                          color: Colors.deepPurple.shade900,
                          fontSize: 12.0,
                          fontWeight: FontWeight.w700),
                    ),
                  ],
                )
              : type == 5
                  ? Row(
                      children: [
                        Icon(
                          Icons.note,
                          color: Colors.grey,
                          size: 17,
                        ),
                        Text(
                          "  File",
                          maxLines: 2,
                          style: new TextStyle(
                              color: Colors.deepPurple.shade900,
                              fontSize: 12.0,
                              fontWeight: FontWeight.w700),
                        ),
                      ],
                    )
                  : type == 6
                      ? Row(
                          children: [
                            Icon(
                              Icons.audiotrack,
                              color: Colors.grey,
                              size: 17,
                            ),
                            Text(
                              "  Audio",
                              maxLines: 2,
                              style: new TextStyle(
                                  color: Colors.deepPurple.shade900,
                                  fontSize: 12.0,
                                  fontWeight: FontWeight.w700),
                            ),
                          ],
                        )
                      : Text(
                          content,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: new TextStyle(
                              color: Colors.deepPurple.shade900,
                              fontSize: 12.0,
                              fontWeight: FontWeight.w700),
                        ),
    );
  }
}
