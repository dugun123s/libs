import 'dart:async';
import 'dart:io';
import 'package:agora_rtc_engine/rtc_engine.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:diemchat/Screens/videoCall/cached_image.dart';
import 'package:diemchat/Screens/videoCall/call.dart';
import 'package:diemchat/Screens/videoCall/call_method.dart';
import 'package:diemchat/constatnt/Constant.dart';
import 'package:diemchat/constatnt/global.dart';
import 'package:diemchat/models/callModal.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';

// ignore: must_be_immutable
class VoiceCallScreen extends StatefulWidget {
  final Call call;
  String recName;
  String recImage;

  VoiceCallScreen({@required this.call, this.recName, this.recImage});

  @override
  _CallScreenState createState() => _CallScreenState();
}

class _CallScreenState extends State<VoiceCallScreen> {
  final CallMethods callMethods = CallMethods();

  StreamSubscription callStreamSubscription;
  RtcEngine _engine;
  List<int> _users = <int>[];
  final _infoStrings = <String>[];
  bool isJoined = false, switchCamera = true, switchRender = true;
  bool muted = false;
  bool peerUser = false;
  bool currentUser = true;
  bool speaker = true;
  bool mini = false;
  String totalDuration = '0';
  String totalUser = '';

  AudioPlayer player = AudioPlayer();

  permissionAcessPhone() async {
    Map<Permission, PermissionStatus> statuses = await [
      Permission.notification,
      Permission.storage,
      Permission.camera,
      Permission.microphone,
      Permission.mediaLibrary,
    ].request();

    if (await Permission.contacts.request().isGranted) {}
  }

  @override
  void initState() {
    if (widget.call.callerId == userID) {
      _loadsound();
    }
    permissionAcessPhone();
    super.initState();
    this._initEngine();

    addPostFrameCallback();
  }

  void _loadsound() async {
    final ByteData data = await rootBundle.load("assets/audio/calling.mp3");
    Directory tempDir = await getTemporaryDirectory();
    File tempFile = File('${tempDir.path}/calling.mp3');
    await tempFile.writeAsBytes(data.buffer.asUint8List(), flush: true);
    String mp3Uri = tempFile.uri.toString();
    _playsound(mp3Uri);
  }

  _playsound(mp3Uri) {
    player.earpieceOrSpeakersToggle();
    player.play(mp3Uri);
  }

  _initEngine() async {
    // ignore: deprecated_member_use
    _engine = await RtcEngine.createWithContext(RtcEngineContext(APP_ID));
    this._addListeners();

    await _engine.enableVideo();
    await _engine.startPreview();
    await _engine.setChannelProfile(ChannelProfile.LiveBroadcasting);
    await _engine.setClientRole(ClientRole.Broadcaster);
    initializeAgora();
  }

  _addListeners() {
    _engine?.setEventHandler(RtcEngineEventHandler(
      joinChannelSuccess: (channel, uid, elapsed) {
        // ignore: unnecessary_brace_in_string_interps
        // print('joinChannelSuccess ${channel} ${uid} ${elapsed}');
        callData(channel.toString());
        final info = 'onJoinChannel: $channel, uid: $uid';
        setState(() {
          _infoStrings.add(info);
          totalDuration = '0';
          totalUser = '';
          isJoined = true;
        });
      },
      userJoined: (uid, elapsed) {
        // ignore: unnecessary_brace_in_string_interps
        // print('userJoined  ${uid} ${elapsed}'
        //     "👍 ");
        //print('userJoined  ${uid} ${elapsed}');

        setState(() {
          final info = 'onUserJoined: $uid';
          _infoStrings.add(info);
          print("👍 " + info.toString());
          _users.add(uid);
          // remoteUid.add(uid);
        });
        if (_users.length > 1) {
          player.stop();
        }
      },
      userOffline: (uid, reason) {
        // if call was picked
        setState(() {
          _users.removeWhere((element) => element == uid);
          final info = 'userOffline: $uid';
          print("👍 " + info.toString());
          _infoStrings.add(info);
        });
      },
      leaveChannel: (stats) async {
        // print('leaveChannel ${stats.toJson()}');
        setState(() {
          player.stop();
          _infoStrings.add('onLeaveChannel');
          _users.clear();
          isJoined = false;
          _engine.destroy();
        });
      },
      firstRemoteVideoFrame: (
        int uid,
        int width,
        int height,
        int elapsed,
      ) {
        setState(() {
          final info = 'firstRemoteVideo: $uid ${width}x $height';
          _infoStrings.add(info);
        });
      },
      rtcStats: (value) {
        setState(() {
          totalDuration = durationToString(value.duration);
          totalUser = value.userCount.toString();
          print("👍👍👍👍👍👍👍👍👍👍👍👍👍👍 " + value.userCount.toString());
          if (value.userCount == 2 || value.userCount == null) {
            player.stop();
          }
          player.onPlayerCompletion.listen((event) {
            callMethods.endCall(
              call: widget.call,
            );
            setState(() {
              player.stop();
            });
          });
          print(value.userCount);
        });
      },
      connectionLost: () {
        setState(() {
          player.stop();
          final info = 'onConnectionLost';
          _infoStrings.add(info);
        });
      },
    ));
  }

  String durationToString(int minutes) {
    var d = Duration(minutes: minutes);
    List<String> parts = d.toString().split(':');
    return '${parts[0].padLeft(2, '0')}:${parts[1].padLeft(2, '0')}';
  }

  Future<void> initializeAgora() async {
    // await widget._engine.enableWebSdkInteroperability(true);
    if (defaultTargetPlatform == TargetPlatform.android) {
      await [Permission.microphone, Permission.camera].request();
    }
    await _engine
        .joinChannel(null, widget.call.channelId, null,
            DateTime.now().millisecondsSinceEpoch)
        .then((value) {
      setState(() {
        _onSpeaker();
      });
    });
  }

  FirebaseAuth _auth = FirebaseAuth.instance;
  addPostFrameCallback() {
    callStreamSubscription = callMethods
        .callStream(uid: _auth.currentUser.uid)
        .listen((DocumentSnapshot ds) {
      // defining the logic
      if (!ds.exists && closed == false) {
        player.stop();
        // snapshot is null which means that call is hanged and documents are deleted
        Navigator.pop(context);
      }
    });
  }

  bool closed = false;
  void _onSpeaker() {
    setState(() {
      speaker = !speaker;
    });
    _engine.setEnableSpeakerphone(speaker);
  }

  void _onToggleMute() {
    setState(() {
      muted = !muted;
    });
    _engine.muteLocalAudioStream(muted);
  }

  // void _onSwitchCamera() {
  //   widget._engine.switchCamera();
  // }

  Widget _toolbar() {
    return Container(
      alignment: Alignment.bottomCenter,
      padding: const EdgeInsets.symmetric(vertical: 48),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          RawMaterialButton(
            onPressed: _onToggleMute,
            child: Icon(
              muted ? Icons.mic_off : Icons.mic,
              color: muted ? Colors.black : Colors.black,
              size: 20.0,
            ),
            shape: CircleBorder(),
            elevation: 2.0,
            fillColor: muted ? Colors.white : Colors.white,
            padding: const EdgeInsets.all(12.0),
          ),
          RawMaterialButton(
              onPressed: () {
                closed = true;
                callMethods.endCall(
                  call: widget.call,
                );
                setState(() {
                  player.stop();
                });
                Navigator.pop(context);
              },
              child: Image.asset(
                "assets/images/end.png",
                height: 120,
              )),
          RawMaterialButton(
            onPressed: () {
              player.earpieceOrSpeakersToggle();
              _onSpeaker();
            },
            child: Icon(
              speaker ? Icons.volume_up : Icons.volume_off_sharp,
              color: muted ? Colors.black : Colors.black,
              size: 20.0,
            ),
            shape: CircleBorder(),
            elevation: 2.0,
            fillColor: muted ? Colors.white : Colors.white,
            padding: const EdgeInsets.all(12.0),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    // clear users

    // rtcStats.
    _users.clear();
    // destroy sdk
    _engine.leaveChannel();
    //AgoraRtcEngine.destroy();
    _engine?.destroy();
    callStreamSubscription.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        mini == false
            ? Scaffold(
                backgroundColor: Colors.white,
                body: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          callColor1.withOpacity(0.1),
                          callColor2,
                        ]),
                  ),
                  child: Stack(
                    alignment: Alignment.center,
                    children: <Widget>[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text(
                                "Wootsapp Voice Call",
                                style: TextStyle(
                                  fontSize: 20,
                                ),
                              ),
                              SizedBox(height: 60),
                              Text(
                                widget.recName != null
                                    ? widget.recName
                                    : widget.call.callerName,
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                              SizedBox(height: 20),
                              CachedImage(
                                widget.recImage != null
                                    ? widget.recImage
                                    : widget.call.callerPic,
                                isRound: true,
                                radius: 180,
                              ),
                              SizedBox(height: 20),
                              Text(
                                totalDuration,
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                              // Text(
                              //   totalUser,
                              //   style: TextStyle(
                              //     fontWeight: FontWeight.bold,
                              //     fontSize: 20,
                              //   ),
                              // ),
                              _toolbar()
                            ],
                          ),
                        ],
                      ),
                      // Padding(
                      //   padding: const EdgeInsets.only(top: 40, left: 20),
                      //   child: Align(
                      //     alignment: Alignment.topLeft,
                      //     child: IconButton(
                      //         icon: Icon(Icons.arrow_back_ios, size: 25),
                      //         onPressed: () {
                      //           setState(() {
                      //             mini = true;
                      //           });
                      //         }),
                      //   ),
                      // )
                    ],
                  ),
                ),
              )
            : Container(
                height: 50,
                child: Scaffold(
                  backgroundColor: Colors.white,
                  body: InkWell(
                    onTap: () {
                      setState(() {
                        mini = false;
                      });
                    },
                    child: Container(
                      color: appColorGreen,
                    ),
                  ),
                ),
              ),
      ],
    );
  }

  FirebaseDatabase database = new FirebaseDatabase();

  callData(channelId) {
    CallModal model = new CallModal(
      widget.call.receiverName,
      widget.call.receiverPic,
      "voice",
      "Outgoing",
      widget.call.callerId,
      widget.call.receiverId,
      widget.call.callerId,
      DateTime.now().millisecondsSinceEpoch.toString(),
      channelId,
    );

    database
        .reference()
        .child("call_history")
        .child(widget.call.callerId + channelId)
        .set(model.toJson());

    CallModal model2 = new CallModal(
      widget.call.callerName,
      widget.call.callerPic,
      "voice",
      _auth.currentUser.uid.toString() == widget.call.callerId
          ? "Missed"
          : "Incoming",
      widget.call.callerId,
      widget.call.receiverId,
      widget.call.receiverId,
      DateTime.now().millisecondsSinceEpoch.toString(),
      channelId,
    );

    database
        .reference()
        .child("call_history")
        .child(widget.call.receiverId + channelId)
        .set(model2.toJson());
  }
}
