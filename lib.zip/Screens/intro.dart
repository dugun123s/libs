import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:diemchat/Screens/signUp.dart';
import 'package:diemchat/constatnt/global.dart';
import 'package:diemchat/helper/sizeconfig.dart';
import 'package:url_launcher/url_launcher.dart';

import 'login.dart';

class Intro extends StatefulWidget {
  @override
  _IntroState createState() => _IntroState();
}

class _IntroState extends State<Intro> {
  var scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
      ),
      child: Container(
        //  decoration: BoxDecoration(
        //     image: DecorationImage(
        //       image: AssetImage('assets/images/back.jpg'),
        //       fit: BoxFit.cover,
        //     ),
        //   ),
        child: Scaffold(
            backgroundColor: Colors.transparent,
            body: LayoutBuilder(builder: (context, constraint) {
              return SingleChildScrollView(
                child: ConstrainedBox(
                    constraints:
                        BoxConstraints(minHeight: constraint.maxHeight),
                    child: IntrinsicHeight(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          SizedBox(
                            height: SizeConfig.safeBlockVertical * 7,
                          ),
                          Container(
                            height: SizeConfig.safeBlockVertical * 20,
                            width: SizeConfig.screenWidth,
                            // height: 130,
                            // width: 130,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                  image:
                                      AssetImage('assets/images/applogo.png'),
                                  scale: 20),
                            ),
                          ),
                          Text("diemchat".toUpperCase(),
                              style: TextStyle(
                                  color: appColorBlue,
                                  fontSize: SizeConfig.blockSizeHorizontal * 7,
                                  fontFamily: "MontserratBold")),
                          SizedBox(
                            height: SizeConfig.safeBlockVertical * 4,
                          ),
                          Text("BAĞLAN - SOSYALLEŞ - SOHBET ET".toUpperCase(),
                              style: TextStyle(
                                  color: appColorBlue,
                                  fontSize:
                                      SizeConfig.blockSizeHorizontal * 3.8,
                                  fontFamily: "MontserratBold")),
                          Expanded(
                            child: Container(
                              height: SizeConfig.safeBlockVertical * 15,
                              width: SizeConfig.screenWidth,
                              // height: 130,
                              // width: 130,
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  image: AssetImage(
                                      'assets/images/messagesConcept.png'),
                                  fit: BoxFit.contain,
                                ),
                              ),
                            ),
                          ),
                          Container(
                            height: SizeConfig.blockSizeVertical * 6,
                            width: SizeConfig.blockSizeHorizontal * 70,
                            // ignore: deprecated_member_use
                            child: RaisedButton(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              onPressed: () {
                                // Navigator.push(
                                //   context,
                                //   MaterialPageRoute(
                                //       builder: (context) => PhoneVerify()),
                                // );
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => SignUp(),
                                  ),
                                );
                                // Navigator.pushAndRemoveUntil(
                                //   context,
                                //   MaterialPageRoute(
                                //       builder: (_) => PhoneAuthGetPhone()),
                                //   (Route<dynamic> route) => false,
                                // );
                              },
                              color: appColorBlue,
                              textColor: Colors.white,
                              child: Text("Hesap Oluştur".toUpperCase(),
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize:
                                          SizeConfig.blockSizeHorizontal * 3,
                                      fontFamily: "MontserratBold")),
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.safeBlockVertical * 2,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text("Hesabın var mı? ",
                                  style: TextStyle(
                                      color: Colors.grey,
                                      fontSize:
                                          SizeConfig.blockSizeHorizontal * 3,
                                      fontFamily: "MontserratBold")),
                              InkWell(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => Login(),
                                    ),
                                  );
                                },
                                child: Text("Giriş Yap",
                                    style: TextStyle(
                                        color: appColorBlue,
                                        fontSize:
                                            SizeConfig.blockSizeHorizontal * 3,
                                        fontFamily: "MontserratBold")),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: SizeConfig.safeBlockVertical * 7,
                          ),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                InkWell(
                                  onTap: () {
                                    launch(
                                        "https://diemsosyal.blogspot.com/2021/09/politikas-gizlilik-politikas-web.html");
                                  },
                                  child: Text("Gizlilik Politikası",
                                      style: TextStyle(
                                          color: Colors.grey,
                                          fontSize:
                                              SizeConfig.blockSizeHorizontal *
                                                  3,
                                          fontFamily: "MontserratBold")),
                                ),
                                InkWell(
                                  onTap: () {
                                    launch(
                                        "https://diemsosyal.blogspot.com/2021/09/diem-karsdaki-kullanclarn-kimligini-siz.html");
                                  },
                                  child: Text("Kullanıcı Sözleşmesi",
                                      style: TextStyle(
                                          color: Colors.grey,
                                          fontSize:
                                              SizeConfig.blockSizeHorizontal *
                                                  3,
                                          fontFamily: "MontserratBold")),
                                )
                              ]),
                          SizedBox(
                            height: SizeConfig.safeBlockVertical * 3,
                          ),
                        ],
                      ),
                    )),
              );
            })),
      ),
    );
  }
}
