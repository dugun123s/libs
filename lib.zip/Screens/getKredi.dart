import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:diemchat/constatnt/Constant.dart';
import 'package:diemchat/constatnt/global.dart';
import 'package:diemchat/helper/sizeconfig.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:toast/toast.dart';

class GetKredi extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return GetKrediState();
  }
}

class GetKrediState extends State<GetKredi> {
  final InAppPurchase _inAppPurchase = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>> _subscription;

  @override
  void initState() {
    final Stream purchaseUpdated = InAppPurchase.instance.purchaseStream;
    _subscription = purchaseUpdated.listen((purchaseDetailsList) {
      _listenToPurchaseUpdated(purchaseDetailsList);
    }, onDone: () {
      _subscription.cancel();
    }, onError: (error) {
      // handle error here.
    });
    initStoreInfo();
    super.initState();
  }

  String token;
  Set<String> productsID = <String>{"30_minute", "60_minute", "90_minute"};

  @override
  void dispose() {
    _subscription.cancel();
    super.dispose();
  }

  FirebaseAuth _auth = FirebaseAuth.instance;
  void _listenToPurchaseUpdated(List<PurchaseDetails> purchaseDetailsList) {
    purchaseDetailsList.forEach((PurchaseDetails purchaseDetails) async {
      if (purchaseDetails.status == PurchaseStatus.pending) {
        // _showPendingUI();
      } else {
        if (purchaseDetails.status == PurchaseStatus.error) {
          print("*********************** ERROR*************************");
          // _handleError(purchaseDetails.error!);
        } else if (purchaseDetails.status == PurchaseStatus.purchased) {
          print(
              "*********************** PURCHASED OR RESTORED*************************");
          if (purchaseDetails.productID.split("_")[0] == "GPA") {
            await FirebaseFirestore.instance
                .collection("purchasedUsers")
                .doc(_auth.currentUser.uid)
                .set({
              "boostDate": DateTime.now().add(Duration(
                  minutes: int.parse(purchaseDetails.productID.split("_")[0])))
            });
            Toast.show(
                "Profilin ${purchaseDetails.productID.split("_")[0]} boyunca öne çıkarılacak",
                context,
                duration: 5,
                backgroundColor: Colors.green,
                textColor: Colors.white);
          }
        }
        if (purchaseDetails.pendingCompletePurchase) {
          await InAppPurchase.instance.completePurchase(purchaseDetails);
          print(
              "*********************** Satın ALMA TAMAMLANDI*************************");
        }
      }
    });
  }

  bool loaded = false;
  List<ProductDetails> products = [];
  Future<void> initStoreInfo() async {
    final bool available = await InAppPurchase.instance.isAvailable();

    if (!available) {
      // The store cannot be reached or accessed. Update the UI accordingly.
    } else {
      final ProductDetailsResponse response =
          await InAppPurchase.instance.queryProductDetails(productsID);
      if (response.notFoundIDs.isNotEmpty) {
        // Handle the error.
      } else {
        products = response.productDetails;
        print(products.length);
        setState(() {
          loaded = true;
        });
      }
    }
  }

  ProductDetails choose;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: bgcolor,
        child: Column(
          children: [
            Container(
              height: MediaQuery.of(context).size.height / 2.5,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(300),
                      bottomRight: Radius.circular(300)),
                  image: DecorationImage(
                      image: AssetImage("assets/images/boost.jpeg"),
                      fit: BoxFit.cover)),
            ),
            Padding(
              padding: EdgeInsets.only(top: 10, bottom: 5),
              child: CustomText(
                text: "Profilini Öne Çıkar",
                alignment: Alignment.center,
                fontSize: SizeConfig.blockSizeHorizontal * 5,
                fontWeight: FontWeight.bold,
                fontFamily: "MontserratBold",
                color: appColorBlack,
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 10),
              child: Text(
                choose == null
                    ? "Profilini öne çıkartarak shuffle ekranında görünmesini sağla ve daha çok mesaj al!"
                    : "Profilinin ${choose.id.split("_")[0]} dakika boyunca shuffle ekranında görünmesini sağla ve daha çok mesaj al!",
                textAlign: TextAlign.center,
              ),
            ),
            Container(
              height: 150,
              child: ListView.builder(
                  padding: const EdgeInsets.all(8),
                  itemCount: products.length,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (BuildContext context, int index) {
                    return InkWell(
                      onTap: () {
                        setState(() {
                          choose = products[index];
                        });
                      },
                      child: Container(
                        width: (MediaQuery.of(context).size.width / 3) - 25,
                        margin: EdgeInsets.symmetric(horizontal: 10),
                        padding: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: choose == null
                                    ? Colors.grey.shade400
                                    : choose.id == products[index].id
                                        ? appColorBlue
                                        : Colors.grey.shade400,
                                width: 1.25),
                            borderRadius: BorderRadius.circular(10)),
                        child: Center(
                            child: Column(
                          children: [
                            SizedBox(
                              height: 30,
                            ),
                            Padding(
                              padding: EdgeInsets.only(top: 10, bottom: 5),
                              child: CustomText(
                                text: products[index].description,
                                alignment: Alignment.center,
                                fontSize: SizeConfig.blockSizeHorizontal * 3.8,
                                fontWeight: FontWeight.bold,
                                fontFamily: "MontserratBold",
                                color: appColorBlack,
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 10),
                              child: Divider(
                                color: Colors.grey,
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(top: 5, bottom: 10),
                              child: CustomText(
                                text: products[index].price,
                                alignment: Alignment.center,
                                fontSize: SizeConfig.blockSizeHorizontal * 3.7,
                                fontWeight: FontWeight.w500,
                                color: Colors.black,
                              ),
                            ),
                          ],
                        )),
                      ),
                    );
                  }),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
              child: InkWell(
                onTap: () async {
                  InAppPurchase.instance.buyConsumable(
                      purchaseParam: PurchaseParam(productDetails: choose));
                },
                child: Container(
                  width: double.infinity,
                  height: 50,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      color: appColorBlue),
                  child: Center(
                    child: CustomText(
                      text: "SATIN AL",
                      alignment: Alignment.center,
                      fontSize: SizeConfig.blockSizeHorizontal * 3.8,
                      fontWeight: FontWeight.bold,
                      fontFamily: "MontserratBold",
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
