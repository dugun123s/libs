import 'dart:async';
import 'dart:io';
import 'package:agora_rtc_engine/rtc_engine.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dashed_circle/dashed_circle.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:diemchat/Screens/videoCall/cached_image.dart';
import 'package:diemchat/Screens/videoCall/call.dart';
import 'package:diemchat/Screens/videoCall/call_method.dart';
import 'package:diemchat/constatnt/Constant.dart';
import 'package:diemchat/constatnt/global.dart';
import 'package:diemchat/models/callModal.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shimmer/shimmer.dart';
import 'dart:math' as math;

import '../../helper/sizeconfig.dart';
import 'groupinfo.dart';

// ignore: must_be_immutable
class GroupVoiceCall extends StatefulWidget {
  String documentId;
  String groupName;
  String groupImage;
  bool joined;
  List kisiler;
  GroupVoiceCall({
    @required this.documentId,
    @required this.groupName,
    @required this.groupImage,
    @required this.kisiler,
    @required this.joined,
  });

  @override
  _CallScreenState createState() => _CallScreenState();
}

class _CallScreenState extends State<GroupVoiceCall> {
  final CallMethods callMethods = CallMethods();

  StreamSubscription callStreamSubscription;
  RtcEngine _engine;
  List<int> _users = <int>[];
  final _infoStrings = <String>[];
  bool isJoined = false, switchCamera = true, switchRender = true;
  bool muted = false;
  bool peerUser = false;
  bool currentUser = true;
  bool speaker = true;
  bool mini = false;
  String totalDuration = '0';
  String totalUser = '';

  AudioPlayer player = AudioPlayer();

  permissionAcessPhone() async {
    Map<Permission, PermissionStatus> statuses = await [
      Permission.notification,
      Permission.storage,
      Permission.camera,
      Permission.microphone,
      Permission.mediaLibrary,
    ].request();

    if (await Permission.contacts.request().isGranted) {}
  }

  joinVoiceChat() {
    FirebaseDatabase.instance
        .reference()
        .child('groopCall')
        .child(widget.documentId)
        .update({_auth.currentUser.uid: "inVoiceCall"});
    FirebaseDatabase.instance
        .reference()
        .child('groopCall')
        .child(widget.documentId)
        .child(_auth.currentUser.uid)
        .onDisconnect()
        .remove();
  }

  leaveVoiceChat() {
    FirebaseDatabase.instance
        .reference()
        .child('groopCall')
        .child(widget.documentId)
        .child(_auth.currentUser.uid)
        .remove();
  }

  @override
  void initState() {
    getRandomColor();
    // if (widget.call.callerId == userID) {
    //   _loadsound();
    // }
    permissionAcessPhone();
    super.initState();
    this._initEngine();

    // addPostFrameCallback();
  }

  void _loadsound() async {
    final ByteData data = await rootBundle.load("assets/audio/calling.mp3");
    Directory tempDir = await getTemporaryDirectory();
    File tempFile = File('${tempDir.path}/calling.mp3');
    await tempFile.writeAsBytes(data.buffer.asUint8List(), flush: true);
    String mp3Uri = tempFile.uri.toString();
    _playsound(mp3Uri);
  }

  _playsound(mp3Uri) {
    player.earpieceOrSpeakersToggle();
    player.play(mp3Uri);
  }

  _initEngine() async {
    // ignore: deprecated_member_use
    _engine = await RtcEngine.createWithContext(RtcEngineContext(APP_ID));
    this._addListeners();

    await _engine.enableVideo();
    await _engine.startPreview();
    await _engine.setChannelProfile(ChannelProfile.LiveBroadcasting);
    print('katildi');
    if (widget.joined) {
      await _engine.setClientRole(ClientRole.Broadcaster);
    } else {
      await _engine.setClientRole(ClientRole.Audience);
    }

    initializeAgora();
    joinVoiceChat();
  }

  _addListeners() {
    _engine?.setEventHandler(RtcEngineEventHandler(
      joinChannelSuccess: (channel, uid, elapsed) {
        // ignore: unnecessary_brace_in_string_interps
        // print('joinChannelSuccess ${channel} ${uid} ${elapsed}');
        // callData(channel.toString());
        final info = 'onJoinChannel: $channel, uid: $uid';

        _infoStrings.add(info);
        totalDuration = '0';
        totalUser = '';
        isJoined = true;
      },
      userJoined: (uid, elapsed) {
        // ignore: unnecessary_brace_in_string_interps
        // print('userJoined  ${uid} ${elapsed}'
        //     "👍 ");
        //print('userJoined  ${uid} ${elapsed}');

        final info = 'onUserJoined: $uid';
        _infoStrings.add(info);
        print("👍 " + info.toString());
        _users.add(uid);
        // remoteUid.add(uid);

        if (_users.length > 1) {
          player.stop();
        }
        setState(() {});
      },
      userOffline: (uid, reason) {
        // if call was picked

        _users.removeWhere((element) => element == uid);
        final info = 'userOffline: $uid';
        print("👍 " + info.toString());
        _infoStrings.add(info);
      },
      leaveChannel: (stats) async {
        // print('leaveChannel ${stats.toJson()}');
        leaveVoiceChat();
        setState(() {
          player.stop();
          _infoStrings.add('onLeaveChannel');
          _users.clear();
          isJoined = false;
          _engine.destroy();
        });
      },
      firstRemoteVideoFrame: (
        int uid,
        int width,
        int height,
        int elapsed,
      ) {
        setState(() {
          final info = 'firstRemoteVideo: $uid ${width}x $height';
          _infoStrings.add(info);
        });
      },
      rtcStats: (value) {
        totalDuration = durationToString(value.duration);
        totalUser = value.userCount.toString();
        print("👍👍👍👍👍👍👍👍👍👍👍👍👍👍 " + value.userCount.toString());
        if (value.userCount == 2 || value.userCount == null) {
          player.stop();
        }
        player.onPlayerCompletion.listen((event) {
          // callMethods.endCall(
          //   call: widget.call,
          // );

          player.stop();

          print(value.userCount);
        });
      },
      connectionLost: () {
        leaveVoiceChat();
        setState(() {
          player.stop();
          final info = 'onConnectionLost';
          _infoStrings.add(info);
        });
      },
    ));
  }

  String durationToString(int minutes) {
    var d = Duration(minutes: minutes);
    List<String> parts = d.toString().split(':');
    return '${parts[0].padLeft(2, '0')}:${parts[1].padLeft(2, '0')}';
  }

  Future<void> initializeAgora() async {
    // await widget._engine.enableWebSdkInteroperability(true);
    if (defaultTargetPlatform == TargetPlatform.android) {
      await [Permission.microphone, Permission.camera].request();
    }
    await _engine
        .joinChannel(null, widget.documentId, null,
            DateTime.now().millisecondsSinceEpoch)
        .then((value) {
      setState(() {
        _onSpeaker();
      });
    });
  }

  FirebaseAuth _auth = FirebaseAuth.instance;
  // addPostFrameCallback() {
  //   callStreamSubscription = callMethods
  //       .callStream(uid: _auth.currentUser.uid)
  //       .listen((DocumentSnapshot ds) {
  //     // defining the logic
  //     if (!ds.exists && closed == false) {
  //       player.stop();
  //       // snapshot is null which means that call is hanged and documents are deleted
  //       Navigator.pop(context);
  //     }
  //   });
  // }

  bool closed = false;
  void _onSpeaker() {
    setState(() {
      speaker = !speaker;
    });
    _engine.setEnableSpeakerphone(speaker);
  }

  void _onToggleMute() {
    setState(() {
      muted = !muted;
    });
    _engine.muteLocalAudioStream(muted);
  }

  // void _onSwitchCamera() {
  //   widget._engine.switchCamera();
  // }

  Widget _toolbar() {
    return Container(
      alignment: Alignment.bottomCenter,
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          RawMaterialButton(
            onPressed: _onToggleMute,
            child: Icon(
              muted ? Icons.mic_off : Icons.mic,
              color: muted ? Colors.black : Colors.black,
              size: 20.0,
            ),
            shape: CircleBorder(),
            elevation: 2.0,
            fillColor: muted ? Colors.white : Colors.white,
            padding: const EdgeInsets.all(12.0),
          ),
          RawMaterialButton(
              onPressed: () {
                closed = true;
                // callMethods.endCall(
                //   call: widget.call,
                // );
                leaveVoiceChat();
                setState(() {
                  player.stop();
                });
                Navigator.pop(context);
              },
              child: Image.asset(
                "assets/images/end.png",
                height: 120,
              )),
          RawMaterialButton(
            onPressed: () {
              player.earpieceOrSpeakersToggle();
              _onSpeaker();
            },
            child: Icon(
              speaker ? Icons.volume_up : Icons.volume_off_sharp,
              color: muted ? Colors.black : Colors.black,
              size: 20.0,
            ),
            shape: CircleBorder(),
            elevation: 2.0,
            fillColor: muted ? Colors.white : Colors.white,
            padding: const EdgeInsets.all(12.0),
          ),
        ],
      ),
    );
  }

  Widget noPerson() {
    return Center(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Padding(
          Image.asset(
            "assets/images/noimage.jpeg",
            width: 200,
          ),
          SizedBox(
            height: 15,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(
              "Sesli görüşmede kimse yok",
              textAlign: TextAlign.center,
              style: TextStyle(letterSpacing: 1),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    // clear users

    // rtcStats.
    _users.clear();
    // destroy sdk
    _engine.leaveChannel();
    //AgoraRtcEngine.destroy();
    _engine?.destroy();
    callStreamSubscription.cancel();
    super.dispose();
  }

  List<Color> colors = [];
  getRandomColor() {
    for (var i = 0; i < 100; i++) {
      colors.add(Color.fromRGBO(math.Random().nextInt(200),
          math.Random().nextInt(200), math.Random().nextInt(200), 1));
    }
  }

  List<String> random = [
    'https://randomuser.me/api/portraits/men/64.jpg',
    'https://randomuser.me/api/portraits/women/39.jpg',
    'https://randomuser.me/api/portraits/women/44.jpg'
  ];
  Stream persons;
  int joinlength = 0;
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        leaveVoiceChat();
        return await true;
      },
      child: Scaffold(
        appBar: PreferredSize(
            preferredSize: Size.fromHeight(100), // here the desired height
            child: AppBar(
              flexibleSpace: Container(
                padding: EdgeInsets.only(
                    top: MediaQuery.of(context).padding.top + 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => GroupInfo(
                                    groupName: widget.groupName,
                                    groupKey: widget.documentId,
                                    ids: widget.kisiler,
                                  )),
                        );
                      },
                      child: Container(
                        // height: 40,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            InkWell(
                              onTap: () {
                                Navigator.pop(context);
                              },
                              child: Padding(
                                padding: const EdgeInsets.only(
                                    right: 10, top: 5, bottom: 5, left: 5),
                                child: Icon(
                                  Icons.arrow_back_ios,
                                  color: appColorBlue,
                                ),
                              ),
                            ),
                            widget.groupImage.length > 3
                                ? Container(
                                    height: 40,
                                    width: 40,
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                        width: 0.5,
                                      ),
                                      shape: BoxShape.circle,
                                      color: Colors.red,
                                    ),
                                    child: Material(
                                      child: CachedNetworkImage(
                                        placeholder: (context, url) =>
                                            Container(
                                          child: CupertinoActivityIndicator(),
                                          width: 30.0,
                                          height: 30.0,
                                          padding: EdgeInsets.all(10.0),
                                        ),
                                        errorWidget: (context, url, error) =>
                                            Material(
                                          child: Padding(
                                            padding: const EdgeInsets.all(0.0),
                                            child: Icon(
                                              Icons.person,
                                              size: 30,
                                              color: Colors.grey,
                                            ),
                                          ),
                                          borderRadius: BorderRadius.all(
                                            Radius.circular(8.0),
                                          ),
                                          clipBehavior: Clip.hardEdge,
                                        ),
                                        imageUrl: widget.groupImage,
                                        width: 30.0,
                                        height: 30.0,
                                        fit: BoxFit.cover,
                                      ),
                                      borderRadius: BorderRadius.all(
                                        Radius.circular(100.0),
                                      ),
                                      clipBehavior: Clip.hardEdge,
                                    ))
                                : Container(
                                    height: 40,
                                    width: 40,
                                    decoration: BoxDecoration(
                                        color: Colors.grey[400],
                                        shape: BoxShape.circle),
                                    child: DashedCircle(
                                        gapSize: 20,
                                        dashes: 20,
                                        color: colors.last,
                                        child: Padding(
                                          padding: EdgeInsets.all(0.8),
                                          child: Image.asset(
                                            "assets/images/${widget.groupImage}.png",
                                            fit: BoxFit.cover,
                                          ),
                                        ))),
                            Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Container(
                                    width:
                                        MediaQuery.of(context).size.width / 1.5,
                                    child: Text(
                                      widget.groupName,
                                      style: new TextStyle(
                                          color: appColorBlack,
                                          fontSize: 16.0,
                                          letterSpacing: 0.8,
                                          fontWeight: FontWeight.w600,
                                          fontFamily: "Arial"),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 2.5),
                    StreamBuilder(
                        stream: FirebaseFirestore.instance
                            .collection("groop")
                            .doc(widget.documentId)
                            .snapshots(),
                        builder: (context,
                            AsyncSnapshot<DocumentSnapshot> snapshot2) {
                          if (snapshot2.hasData) {
                            if (snapshot2.data["joins"].length == 0) {
                              return Container();
                            }

                            return Container(
                              height: 40,
                              padding: const EdgeInsets.only(left: 90),
                              child: ListView.builder(
                                  itemCount: snapshot2.data["joins"].length,
                                  scrollDirection: Axis.horizontal,
                                  physics: NeverScrollableScrollPhysics(),
                                  shrinkWrap: true,
                                  itemBuilder: (context, int index) {
                                    return StreamBuilder(
                                        stream: FirebaseFirestore.instance
                                            .collection("users")
                                            .doc(snapshot2.data["joins"][index])
                                            .snapshots(),
                                        builder: (context,
                                            AsyncSnapshot<DocumentSnapshot>
                                                userSnapshot) {
                                          if (userSnapshot.hasData &&
                                              userSnapshot.data != null) {
                                            return Container(
                                              height: 40,
                                              width: 40,
                                              margin:
                                                  EdgeInsets.only(right: 10),
                                              child: DashedCircle(
                                                gapSize: 20,
                                                dashes: 20,
                                                color: colors[snapshot2
                                                    .data["joins"]
                                                    .indexOf(snapshot2
                                                        .data["joins"][index])],
                                                child: Padding(
                                                  padding: EdgeInsets.all(0.8),
                                                  child: CircleAvatar(
                                                    radius: 20,
                                                    foregroundColor:
                                                        Theme.of(context)
                                                            .primaryColor,
                                                    backgroundColor:
                                                        Colors.grey,
                                                    backgroundImage:
                                                        new NetworkImage(
                                                      userSnapshot
                                                          .data["photo"],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            );
                                          }
                                          return Container(
                                            height: 40,
                                            width: 40,
                                            child: CircleAvatar(
                                              //radius: 60,
                                              foregroundColor: Theme.of(context)
                                                  .primaryColor,
                                              backgroundColor: Colors.grey,
                                            ),
                                          );
                                        });
                                  }),
                            );
                          }
                          return Row(
                            children: [
                              Container(
                                height: 35,
                                width: 35,
                                child: CircleAvatar(
                                  //radius: 60,
                                  foregroundColor:
                                      Theme.of(context).primaryColor,
                                  backgroundColor: Colors.grey,
                                ),
                              ),
                            ],
                          );
                        })
                  ],
                ),
              ),
              centerTitle: false,
              elevation: 1,
              backgroundColor: appColorWhite,

              automaticallyImplyLeading: false,
              // leading: false,,
            )),
        body: Container(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(
              height: 10,
            ),
            Text(
              'Katılımcılar',
              style: TextStyle(color: appColor, fontFamily: 'MontserratBold'),
            ),
            Container(
                constraints: BoxConstraints(
                    maxHeight: MediaQuery.of(context).size.height / 2.25),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Container(
                    decoration: BoxDecoration(
                        color: Colors.grey.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(20)),
                    child: StreamBuilder<Event>(
                      stream: FirebaseDatabase.instance
                          .reference()
                          .child('groopCall')
                          .child(widget.documentId)
                          .onValue,
                      builder: (_, snapshot) {
                        if (snapshot.hasError) {
                          return Center(
                            child: CircularProgressIndicator(color: appColor),
                          );
                        }
                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                          return Center(
                            child: CircularProgressIndicator(color: appColor),
                          );
                        }
                        var data = snapshot.data;

                        if (!data.snapshot.exists) {
                          return noPerson();
                        }
                        if (snapshot.data.snapshot.value.keys.length != 0) {
                          return MediaQuery.removePadding(
                            context: context,
                            removeTop: true,
                            child: GridView.builder(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 0, vertical: 8),
                                gridDelegate:
                                    const SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 2,
                                ),
                                itemCount:
                                    snapshot.data.snapshot.value.keys.length,
                                itemBuilder: (BuildContext context, int index) {
                                  return Container(
                                    child: UserPreview(
                                      color: colors[index],
                                      userId: snapshot.data.snapshot.value.keys
                                          .elementAt(index),
                                    ),
                                  );
                                }),
                          );
                        } else {
                          return noPerson();
                        }
                      },
                    ),
                  ),
                )),
            // _toolbar(),
            widget.joined
                ? Container(
                    child: _toolbar(),
                  )
                : Column(
                    children: [
                      _toolbar(),
                      InkWell(
                        onTap: () async {
                          await FirebaseFirestore.instance
                              .collection("chatList")
                              .doc(_auth.currentUser.uid)
                              .collection(_auth.currentUser.uid)
                              .doc(widget.documentId)
                              .set({
                            'timestamp': FieldValue.serverTimestamp(),
                            'chatType': "group"
                          });
                          await FirebaseFirestore.instance
                              .collection("groop")
                              .doc(widget.documentId)
                              .update({
                            "joins":
                                FieldValue.arrayUnion([_auth.currentUser.uid])
                          });

                          setState(() {
                            widget.kisiler.add(_auth.currentUser.uid);
                            widget.joined = true;
                          });
                          this._initEngine();
                        },
                        child: Container(
                          width: double.infinity,
                          height: 50,
                          padding: EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(0),
                            color: appColorBlue,
                          ),
                          child: Center(
                            child: Text("GROOPA KATIL".toUpperCase(),
                                style: TextStyle(
                                    letterSpacing: 0.7,
                                    color: Colors.white,
                                    fontSize:
                                        SizeConfig.blockSizeHorizontal * 4,
                                    fontFamily: "MontserratBold")),
                          ),
                        ),
                      ),
                    ],
                  )
          ],
        )),
      ),
    );
    return Stack(
      children: [
        mini == false
            ? WillPopScope(
                onWillPop: () async {
                  leaveVoiceChat();
                  return await true;
                },
                child: Scaffold(
                  backgroundColor: Colors.white,
                  body: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            callColor1.withOpacity(0.1),
                            callColor2,
                          ]),
                    ),
                    child: Stack(
                      alignment: Alignment.center,
                      children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text(
                                  "Wootsapp Voice Call",
                                  style: TextStyle(
                                    fontSize: 20,
                                  ),
                                ),
                                SizedBox(height: 60),
                                // Text(
                                //   widget.recName != null
                                //       ? widget.recName
                                //       : widget.call.callerName,
                                //   style: TextStyle(
                                //     fontWeight: FontWeight.bold,
                                //     fontSize: 20,
                                //   ),
                                // ),
                                SizedBox(height: 20),
                                // CachedImage(
                                //   widget.recImage != null
                                //       ? widget.recImage
                                //       : widget.call.callerPic,
                                //   isRound: true,
                                //   radius: 180,
                                // ),
                                SizedBox(height: 20),
                                Text(
                                  totalDuration,
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 20,
                                  ),
                                ),
                                // Text(
                                //   totalUser,
                                //   style: TextStyle(
                                //     fontWeight: FontWeight.bold,
                                //     fontSize: 20,
                                //   ),
                                // ),
                                _toolbar()
                              ],
                            ),
                          ],
                        ),
                        // Padding(
                        //   padding: const EdgeInsets.only(top: 40, left: 20),
                        //   child: Align(
                        //     alignment: Alignment.topLeft,
                        //     child: IconButton(
                        //         icon: Icon(Icons.arrow_back_ios, size: 25),
                        //         onPressed: () {
                        //           setState(() {
                        //             mini = true;
                        //           });
                        //         }),
                        //   ),
                        // )
                      ],
                    ),
                  ),
                ),
              )
            : Container(
                height: 50,
                child: Scaffold(
                  backgroundColor: Colors.white,
                  body: InkWell(
                    onTap: () {
                      setState(() {
                        mini = false;
                      });
                    },
                    child: Container(
                      color: appColorGreen,
                    ),
                  ),
                ),
              ),
      ],
    );
  }

  FirebaseDatabase database = new FirebaseDatabase();

  // callData(channelId) {
  //   CallModal model = new CallModal(
  //     widget.call.receiverName,
  //     widget.call.receiverPic,
  //     "voice",
  //     "Outgoing",
  //     widget.call.callerId,
  //     widget.call.receiverId,
  //     widget.call.callerId,
  //     DateTime.now().millisecondsSinceEpoch.toString(),
  //     channelId,
  //   );

  //   database
  //       .reference()
  //       .child("call_history")
  //       .child(widget.call.callerId + channelId)
  //       .set(model.toJson());

  //   CallModal model2 = new CallModal(
  //     widget.call.callerName,
  //     widget.call.callerPic,
  //     "voice",
  //     _auth.currentUser.uid.toString() == widget.call.callerId
  //         ? "Missed"
  //         : "Incoming",
  //     widget.call.callerId,
  //     widget.call.receiverId,
  //     widget.call.receiverId,
  //     DateTime.now().millisecondsSinceEpoch.toString(),
  //     channelId,
  //   );

  //   database
  //       .reference()
  //       .child("call_history")
  //       .child(widget.call.receiverId + channelId)
  //       .set(model2.toJson());
  // }
}

class UserPreview extends StatefulWidget {
  String userId;
  Color color;
  UserPreview({this.userId, this.color});

  @override
  _UserPreviewState createState() => _UserPreviewState();
}

class _UserPreviewState extends State<UserPreview> {
  String photo = '';
  String name = '';
  Future getUserInfo() async {
    print('=================');
    print(widget.userId);
    FirebaseFirestore.instance
        .collection('users')
        .doc(widget.userId)
        .get()
        .then((value) {
      setState(() {
        photo = value['photo'];
        name = value['nick'];
      });
    });
  }

  @override
  void initState() {
    getUserInfo();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    if (photo == '') {
      return Shimmer.fromColors(
        baseColor: Colors.grey.shade300,
        highlightColor: Colors.grey.shade100,
        child: Container(
            child: Column(
          children: [
            CircleAvatar(
              radius: 40,
            )
          ],
        )),
      );
    }
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          DashedCircle(
              gapSize: 20,
              dashes: 20,
              color: widget.color,
              child: Padding(
                padding: EdgeInsets.all(0.8),
                child: CircleAvatar(
                  radius: 40,
                  backgroundImage: NetworkImage(photo),
                ),
              )),
          SizedBox(
            height: 5,
          ),
          Text(
            name,
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
          )
        ],
      ),
    );
  }
}
