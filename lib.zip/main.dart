import 'package:diemchat/app.dart';
import 'package:diemchat/constatnt/Constant.dart';
import 'package:diemchat/provider/user.dart';
import 'package:diemchat/services/auth_service.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import 'package:in_app_purchase_android/in_app_purchase_android.dart';
import 'package:provider/provider.dart';
import 'Screens/splashscreen.dart';
import 'Screens/widgets/provider_widget.dart' as pre;
import 'package:flutter/cupertino.dart';

const iOSLocalizedLabels = true;
const AndroidNotificationChannel channel = AndroidNotificationChannel(
  'high_importance_channel', // id
  'High Importance Notifications', // title
  'This channel is used for important notifications.', // description
  importance: Importance.high,
);
final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();
Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  InAppPurchaseAndroidPlatformAddition.enablePendingPurchases();

  await flutterLocalNotificationsPlugin
      .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>()
      ?.createNotificationChannel(channel);

  /// Update the iOS foreground notification presentation options to allow
  /// heads up notifications.
  await FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
    alert: true,
    badge: true,
    sound: true,
  );
  runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "Diem Chat",
      theme: new ThemeData(
          accentColor: Colors.black,
          primaryColor: Colors.black,
          primaryColorDark: Colors.black),
      home: SplashScreen(),
      routes: <String, WidgetBuilder>{
        APP_SCREEN: (BuildContext context) => new App(),
      },
    ),
);
}

/// MultiChannel Example
