class SharedPreferencesKey {
  static const String IS_USER_LOGGED_IN = "IS_USER_LOGGED_IN";
  static const String LOGGED_IN_USERRDATA = "LOGGED_IN_USERRDATA";
  static const String USERR_TYPE = "USERR_TYPE";
}
