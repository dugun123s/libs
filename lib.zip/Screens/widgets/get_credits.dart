import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:diemchat/constatnt/global.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:toast/toast.dart';
import 'package:http/http.dart' as http;

class GetCredits extends StatefulWidget {
  String userId;
  String userName;
  String peerToken;
  GetCredits({this.userId, this.userName, this.peerToken});
  @override
  State<GetCredits> createState() => _GetCreditsState();
}

class _GetCreditsState extends State<GetCredits> {
  final InAppPurchase _inAppPurchase = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>> _subscription;

  @override
  void initState() {
    print(widget.userId);
    // var list = new List<int>.generate(10, (i) => i + 1);
    // list.forEach((element) {
    //   productsID.add('$element-sticker');
    // });

    final Stream purchaseUpdated = InAppPurchase.instance.purchaseStream;
    _subscription = purchaseUpdated.listen((purchaseDetailsList) {
      _listenToPurchaseUpdated(purchaseDetailsList);
    }, onDone: () {
      _subscription.cancel();
    }, onError: (error) {
      // handle error here.
    });
    initStoreInfo();
    super.initState();
  }

  String token;
  Set<String> productsID = <String>{'android.test.purchased'};

  @override
  void dispose() {
    _subscription.cancel();
    super.dispose();
  }

  FirebaseAuth _auth = FirebaseAuth.instance;
  void _listenToPurchaseUpdated(List<PurchaseDetails> purchaseDetailsList) {
    purchaseDetailsList.forEach((PurchaseDetails purchaseDetails) async {
      if (purchaseDetails.status == PurchaseStatus.pending) {
        // _showPendingUI();
      } else {
        if (purchaseDetails.status == PurchaseStatus.error) {
          print("*********************** ERROR*************************");
          // _handleError(purchaseDetails.error!);
        } else if (purchaseDetails.status == PurchaseStatus.purchased) {
          print(
              "*********************** PURCHASED OR RESTORED*************************");
          if (purchaseDetails.productID.split("_")[0] != "GPA") {
            await FirebaseFirestore.instance
                .collection("users")
                .doc(widget.userId)
                .update({
              "gifts": FieldValue.arrayUnion([
                {
                  'userId': _auth.currentUser.uid,
                  "giftId": purchaseDetails.productID
                }
              ])
            });
            Toast.show(
                widget.userName + " adlı kullanıcıya bir hediye gönderdin!",
                context,
                duration: 5,
                backgroundColor: appColor,
                
                textColor: Colors.white);
            sendNotification(
                widget.peerToken,
                _auth.currentUser.displayName + ' sana bir hediye gönderdi',
                purchaseDetails.productID);
          }
        }
        if (purchaseDetails.pendingCompletePurchase) {
          await InAppPurchase.instance.completePurchase(purchaseDetails);
          print(
              "*********************** Satın ALMA TAMAMLANDI*************************");
        }
      }
    });
  }

  Future<http.Response> sendNotification(
      String peerToken, String content, productID) async {
    final response = await http.post(
      Uri.parse('https://fcm.googleapis.com/fcm/send'),
      headers: {
        HttpHeaders.contentTypeHeader: 'application/json',
        HttpHeaders.authorizationHeader: "key=$serverKey"
      },
      body: jsonEncode({
        "to": peerToken,
        "priority": "high",
        "data": {
          "gift": productID,
          "sound": "default",
          "vibrate": "300",
        },
        "notification": {
          "vibrate": "300",
          "priority": "high",
          "body": content,
          "title": 'Bir Hediye Aldın',
          "sound": "default",
        }
      }),
    );
    return response;
  }

  bool loaded = false;
  List<ProductDetails> products = [];
  Future<void> initStoreInfo() async {
    final bool available = await InAppPurchase.instance.isAvailable();

    if (!available) {
      // The store cannot be reached or accessed. Update the UI accordingly.
    } else {
      final ProductDetailsResponse response =
          await InAppPurchase.instance.queryProductDetails(productsID);
      if (response.notFoundIDs.isNotEmpty) {
        // Handle the error.
      } else {
        products = response.productDetails;
        print(products.length);
        setState(() {
          loaded = true;
        });
      }
    }
  }

  ProductDetails choose;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
      insetPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 50),
      child: Container(
          child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
              width: double.infinity,
              decoration: BoxDecoration(
                  color: appColor,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(10),
                      topRight: Radius.circular(10))),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image.asset(
                    'assets/stickers/gift.png',
                    width: 50,
                    height: 50,
                    color: Colors.white,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    'Send Gift',
                    style: TextStyle(
                        fontSize: 20,
                        letterSpacing: 0.7,
                        color: Colors.white,
                        fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            !loaded
                ? Container(
                    height: 450,
                    child: GridView.builder(
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 4,
                        ),
                        itemCount: 20,
                        itemBuilder: (BuildContext context, int index) {
                          return InkWell(
                            onTap: () {},
                            child: Column(
                              children: [
                                SizedBox(
                                  height: 5,
                                ),
                                Image.asset(
                                  'assets/stickers/$index.png',
                                  width: 60,
                                  height: 60,
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  '.. Kredi',
                                  style: TextStyle(
                                      fontSize: 12,
                                      letterSpacing: 0.2,
                                      color: appColor,
                                      fontWeight: FontWeight.bold),
                                )
                              ],
                            ),
                          );
                        }),
                  )
                : Container(
                    height: 450,
                    child: GridView.builder(
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 4,
                        ),
                        itemCount: products.length,
                        itemBuilder: (BuildContext context, int index) {
                          return InkWell(
                            onTap: () {
                              InAppPurchase.instance.buyConsumable(
                                  purchaseParam: PurchaseParam(
                                productDetails: products[index],
                                applicationUserName: null,
                              ));
                            },
                            child: Column(
                              children: [
                                SizedBox(
                                  height: 5,
                                ),
                                Image.asset(
                                  'assets/stickers/$index.png',
                                  width: 60,
                                  height: 60,
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  '1 Credits',
                                  style: TextStyle(
                                      fontSize: 12,
                                      letterSpacing: 0.2,
                                      color: appColor,
                                      fontWeight: FontWeight.bold),
                                )
                              ],
                            ),
                          );
                        }),
                  ),
          ],
        ),
      )),
    );
  }
}
