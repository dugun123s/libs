import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:diemchat/constatnt/global.dart';
import 'package:diemchat/helper/sizeconfig.dart';
import 'package:timeago/timeago.dart';
//import 'chat.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';

class ArchiveChatList extends StatefulWidget {
  @override
  _ChatListState createState() => _ChatListState();
}

class _ChatListState extends State<ArchiveChatList> {
  String currentusername;
  String currentuserimage;
  String userId;
  final FirebaseDatabase database = new FirebaseDatabase();
  var array = [];
  TextEditingController controller = new TextEditingController();
  FirebaseAuth _auth = FirebaseAuth.instance;
  @override
  void initState() {
    database
        .reference()
        .child('user')
        .orderByChild("status")
        .equalTo("Online")
        .onValue
        .listen((event) {
      var snapshot = event.snapshot;
      snapshot.value.forEach((key, values) {
        array.add(values["userId"]);
      });
    });

    array.clear();

    setState(() {
      userId = _auth.currentUser.uid;

      getUser();
    });

    super.initState();
  }

  List chatList;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: appColorWhite,
        title: Text(
          "Archived Chats",
          style: TextStyle(
              fontFamily: "MontserratBold", fontSize: 17, color: appColorBlack),
        ),
        centerTitle: true,
        leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(
              Icons.arrow_back_ios,
              color: appColorBlue,
            )),
      ),
      body: Column(
        children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(top: 0),
              child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        topRight: Radius.circular(40),
                        topLeft: Radius.circular(40)),
                  ),
                  child: friendListToMessage(userId)),
            ),
          ),
        ],
      ),
    );
  }

  Widget friendListToMessage(String userData) {
    return StreamBuilder(
      stream: FirebaseFirestore.instance
          .collection("chatList")
          .doc(userData)
          .collection(userData)
          .orderBy("timestamp", descending: true)
          .snapshots(),
      builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (snapshot.hasData) {
          return Container(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            child: snapshot.data.docs.length > 0
                ? _searchResult.length != 0 ||
                        controller.text.trim().toLowerCase().isNotEmpty
                    ? ListView.builder(
                        itemCount: _searchResult.length,
                        itemBuilder: (context, int index) {
                          chatList = snapshot.data.docs;
                          return chatList[index]['archive'] != null &&
                                  chatList[index]['archive'] == true
                              ? buildItem(_searchResult, index)
                              : Container();
                        },
                      )
                    : ListView.builder(
                        itemCount: snapshot.data.docs.length,
                        itemBuilder: (context, int index) {
                          chatList = snapshot.data.docs;
                          return chatList[index]['archive'] != null &&
                                  chatList[index]['archive'] == true
                              ? buildItem(chatList, index)
                              : Container();
                        },
                      )
                : Center(
                    child: Text("Currently you don't have any messages"),
                  ),
          );
        }
        return Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          alignment: Alignment.center,
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                CupertinoActivityIndicator(),
              ]),
        );
      },
    );
  }

  Widget buildItem(List chatList, int index) {
    return Column(
      children: <Widget>[
        Slidable(
          actionPane: SlidableDrawerActionPane(),
          actionExtentRatio: 0.25,
          child: Row(
            children: [
              Expanded(
                child: new ListTile(
                  onTap: () {
                    print("userId:" + userId);
                    print("currentusername:" + currentusername);
                    print("currentuserimage:" + currentuserimage);
                    print("id:" + chatList[index]['id']);
                    print("profileImage:" + chatList[index]['profileImage']);
                    print("name:" + chatList[index]['name']);

                    // Navigator.push(
                    //     context,
                    //     CupertinoPageRoute(
                    //         builder: (context) => Chat(
                    //             currentuser: userId,
                    //             currentusername: currentusername,
                    //             currentuserimage: currentuserimage,
                    //             peerID: chatList[index]['id'],
                    //             peerUrl:
                    //                 chatList[index]['profileImage'].length > 0
                    //                     ? chatList[index]['profileImage']
                    //                     : "",
                    //             peerName: chatList[index]['name'],
                    //             archive: chatList[index]['archive'] != null
                    //                 ? chatList[index]['archive']
                    //                 : false)));
                  },
                  onLongPress: () {
                    _settingModalBottomSheet(
                        context,
                        userId,
                        chatList[index]['id'],
                        chatList[index]['archive'] != null
                            ? chatList[index]['archive']
                            : false);
                  },
                  leading: new Stack(
                    children: <Widget>[
                      InkWell(
                        onLongPress: () {
                          database
                              .reference()
                              .child('user')
                              .child(chatList[index]['id'])
                              .once()
                              .then((peerData) {
                            String name = peerData.value['name'];
                            String image = peerData.value['img'];
                            String phone = peerData.value['mobile'];

                            showDialog(
                              context,
                              name,
                              image,
                              phone,
                              chatList[index]['id'],
                            );
                          });
                        },
                        child: chatList[index]['profileImage'] != null &&
                                chatList[index]['profileImage'].length > 0
                            ? Container(
                                height: 50,
                                width: 50,
                                child: CircleAvatar(
                                  //radius: 60,
                                  foregroundColor:
                                      Theme.of(context).primaryColor,
                                  backgroundColor: Colors.grey,
                                  backgroundImage: new NetworkImage(
                                      chatList[index]['profileImage']),
                                ),
                              )
                            : Container(
                                height: 50,
                                width: 50,
                                decoration: BoxDecoration(
                                    color: Colors.grey, shape: BoxShape.circle),
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Icon(Icons.person),
                                )),
                      ),
                      Positioned(
                          bottom: 0.0,
                          right: 0.0,
                          child: array.contains(chatList[index]['id'])
                              ? Container(
                                  height: 15.0,
                                  width: 15.0,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                        color: Colors.white, width: 2.0),
                                    color: Colors.lightGreen,
                                  ),
                                )
                              : Container()
                          //onlineStatus(chatList[index]['id'])
                          )
                    ],
                  ),
                  title: new Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      new Text(
                        chatList[index]['name'],
                        style: new TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  subtitle: new Container(
                    padding: const EdgeInsets.only(top: 0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        chatList[index]['type'] == 1
                            ? Row(
                                children: [
                                  Icon(
                                    Icons.camera_alt,
                                    color: Colors.grey,
                                    size: 17,
                                  ),
                                  Text(
                                    "  Photo",
                                    maxLines: 2,
                                    style: new TextStyle(
                                        color: Colors.grey,
                                        fontSize: 12.0,
                                        fontWeight: FontWeight.normal),
                                  ),
                                ],
                              )
                            : chatList[index]['type'] == 4
                                ? Row(
                                    children: [
                                      Icon(
                                        Icons.video_call,
                                        color: Colors.grey,
                                        size: 17,
                                      ),
                                      Text(
                                        "  Video",
                                        maxLines: 2,
                                        style: new TextStyle(
                                            color: Colors.grey,
                                            fontSize: 12.0,
                                            fontWeight: FontWeight.normal),
                                      ),
                                    ],
                                  )
                                : chatList[index]['type'] == 5
                                    ? Row(
                                        children: [
                                          Icon(
                                            Icons.note,
                                            color: Colors.grey,
                                            size: 17,
                                          ),
                                          Text(
                                            "  File",
                                            maxLines: 2,
                                            style: new TextStyle(
                                                color: Colors.grey,
                                                fontSize: 12.0,
                                                fontWeight: FontWeight.normal),
                                          ),
                                        ],
                                      )
                                    : chatList[index]['type'] == 6
                                        ? Row(
                                            children: [
                                              Icon(
                                                Icons.audiotrack,
                                                color: Colors.grey,
                                                size: 17,
                                              ),
                                              Text(
                                                "  Audio",
                                                maxLines: 2,
                                                style: new TextStyle(
                                                    color: Colors.grey,
                                                    fontSize: 12.0,
                                                    fontWeight:
                                                        FontWeight.normal),
                                              ),
                                            ],
                                          )
                                        : Text(
                                            chatList[index]['content'],
                                            maxLines: 2,
                                            style: new TextStyle(
                                                color: Colors.grey,
                                                fontSize: 12.0,
                                                fontWeight: FontWeight.normal),
                                          ),
                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 10),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 3),
                      child: new Text(
                        format(
                            DateTime.fromMillisecondsSinceEpoch(int.parse(
                              chatList[index]['timestamp'],
                            )),
                            locale: 'en_short'),
                        style: new TextStyle(
                            color: int.parse(chatList[index]['badge']) > 0
                                ? Colors.blue
                                : Colors.grey,
                            fontSize: 14.0,
                            fontWeight: FontWeight.w500),
                      ),
                    ),
                    Container(
                      height: 5,
                    ),
                    int.parse(chatList[index]['badge']) > 0
                        ? Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.blue,
                            ),
                            alignment: Alignment.center,
                            height: 20,
                            width: 20,
                            child: Text(
                              chatList[index]['badge'],
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w900,
                                  fontSize: 12),
                            ),
                          )
                        : Container(child: Text("")),
                  ],
                ),
              ),
            ],
          ),
          secondaryActions: <Widget>[
            IconSlideAction(
              caption: 'More',
              color: Colors.grey[400],
              foregroundColor: Colors.black,
              icon: Icons.more_horiz,
              // onTap: () => _showSnackBar('More'),
            ),
            IconSlideAction(
              caption: 'Archive',
              foregroundColor: Colors.black,
              color: Colors.green,
              icon: Icons.archive,
              //  onTap: () => _showSnackBar('Delete'),
            ),
          ],
        ),
        new Divider(
          height: 10.0,
        ),
      ],
    );
  }

  void _settingModalBottomSheet(context, userId, peerId, arch) {
    showModalBottomSheet(
        context: context,
        builder: (BuildContext bc) {
          return Container(
            child: new Wrap(
              children: <Widget>[
                Center(
                    child: new ListTile(
                        title: Center(child: new Text('Pin')),
                        onTap: () => {})),
                new ListTile(
                  title: Center(child: new Text('Mark as Unread')),
                  onTap: () => {},
                ),
                new ListTile(
                  title: Center(child: new Text('Mute')),
                  onTap: () {},
                ),
                arch == true
                    ? ListTile(
                        title: Center(child: new Text('Unarchive')),
                        onTap: () {
                          Navigator.pop(context);
                          FirebaseFirestore.instance
                              .collection("chatList")
                              .doc(userId)
                              .collection(userId)
                              .doc(peerId)
                              .update({'archive': false});
                        },
                      )
                    : ListTile(
                        title: Center(child: new Text('Archive')),
                        onTap: () {
                          Navigator.pop(context);
                          FirebaseFirestore.instance
                              .collection("chatList")
                              .doc(userId)
                              .collection(userId)
                              .doc(peerId)
                              .update({'archive': true});
                        },
                      ),
                new ListTile(
                  title: Center(child: new Text('View Contact')),
                  onTap: () => {},
                ),
                new ListTile(
                  title: Center(
                    child: new Text(
                      'Delete',
                      style: TextStyle(color: Colors.red),
                    ),
                  ),
                  onTap: () {
                    Navigator.pop(context);
                    FirebaseFirestore.instance
                        .collection("chatList")
                        .doc(userId)
                        .collection(userId)
                        .doc(peerId)
                        .delete();
                  },
                ),
                Center(
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 20),
                    child: new RawMaterialButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      elevation: 2.0,
                      fillColor: Colors.grey[300],
                      child: Icon(
                        Icons.close,
                        size: 20.0,
                      ),
                      padding: EdgeInsets.all(15.0),
                      shape: CircleBorder(),
                    ),
                  ),
                ),
              ],
            ),
          );
        });
  }

  void showDialog(BuildContext context, name, image, phone, id) {
    showGeneralDialog(
      barrierLabel: "Barrier",
      barrierDismissible: true,
      barrierColor: Colors.black.withOpacity(0.5),
      transitionDuration: Duration(milliseconds: 700),
      context: context,
      pageBuilder: (_, __, ___) {
        return Align(
          alignment: Alignment.center,
          child: Container(
            height: SizeConfig.safeBlockVertical * 100,
            width: SizeConfig.screenWidth,
            child: Column(
              children: <Widget>[
                Container(
                    decoration: new BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: new BorderRadius.only(
                          topLeft: const Radius.circular(30.0),
                          topRight: const Radius.circular(30.0),
                        )),
                    height: SizeConfig.safeBlockVertical * 30,
                    width: SizeConfig.screenWidth,
                    child: ClipRRect(
                      borderRadius: BorderRadius.only(
                          topRight: Radius.circular(30.0),
                          topLeft: Radius.circular(30.0)),
                      child: image.length > 0
                          ? Image.network(
                              image,
                              fit: BoxFit.cover,
                            )
                          : Icon(
                              Icons.person,
                              color: Colors.black,
                              size: 50,
                            ),
                    )),
                Material(
                  borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(30.0),
                      bottomLeft: Radius.circular(30.0)),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                          bottomRight: Radius.circular(30.0),
                          bottomLeft: Radius.circular(30.0)),
                    ),
                    height: SizeConfig.blockSizeVertical * 12,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(left: 20, top: 10),
                          child: Text(
                            name,
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: SizeConfig.blockSizeVertical * 2.5),
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.only(
                                left: 20,
                              ),
                              child: Text(
                                phone,
                                style: TextStyle(
                                    fontSize: SizeConfig.blockSizeVertical * 2,
                                    color: Colors.grey),
                              ),
                            ),
                            Row(
                              children: <Widget>[
                                RawMaterialButton(
                                  onPressed: () {
                                    // Navigator.push(
                                    //     context,
                                    //     CupertinoPageRoute(
                                    //         builder: (context) => Chat(
                                    //             currentuser: userId,
                                    //             currentusername:
                                    //                 currentusername,
                                    //             currentuserimage:
                                    //                 currentuserimage,
                                    //             peerID: id,
                                    //             peerUrl: image,
                                    //             peerName: name)));
                                  },
                                  elevation: 2.0,
                                  fillColor: Colors.white,
                                  child: Icon(
                                    Icons.message,
                                    size: 20.0,
                                  ),
                                  shape: CircleBorder(),
                                ),
                                RawMaterialButton(
                                  onPressed: () {},
                                  elevation: 2.0,
                                  fillColor: Colors.white,
                                  child: Icon(
                                    Icons.info,
                                    size: 20.0,
                                  ),
                                  shape: CircleBorder(),
                                )
                              ],
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                )
              ],
            ),
            margin: EdgeInsets.only(bottom: 50, left: 18, right: 18, top: 200),
          ),
        );
      },
      transitionBuilder: (_, anim, __, child) {
        return SlideTransition(
          position: Tween(begin: Offset(0, 1), end: Offset(0, 0)).animate(anim),
          child: child,
        );
      },
    );
  }

  Widget friendName(AsyncSnapshot friendListSnapshot, int index) {
    return Container(
      width: 200,
      alignment: Alignment.topLeft,
      child: RichText(
        text: TextSpan(children: <TextSpan>[
          TextSpan(
            text:
                "${friendListSnapshot.data["firstname"]} ${friendListSnapshot.data["lastname"]}",
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.w900),
          )
        ]),
      ),
    );
  }

  Widget messageButton(AsyncSnapshot friendListSnapshot, int index) {
    // ignore: deprecated_member_use
    return RaisedButton(
      color: Colors.red,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
      child: Text(
        "Message",
        style: TextStyle(fontWeight: FontWeight.w900, color: Colors.white),
      ),
      onPressed: () {},
    );
  }

  getOnlineStatus() {
    database
        .reference()
        .child('user')
        .orderByChild("status")
        .equalTo("Online")
        .onValue
        .listen((event) {
      var snapshot = event.snapshot;
      snapshot.value.forEach((key, values) {
        setState(() {
          array.add(values["userId"]);
          friendListToMessage(userId);
        });
      });
    });
  }

  getUser() async {
    database.reference().child('user').child(userId).once().then((peerData) {
      currentusername = peerData.value['name'];
      currentuserimage = peerData.value['img'];
    });

    setState(() {
      friendListToMessage(userId);
    });
  }

  onSearchTextChanged(String text) async {
    _searchResult.clear();
    if (text.isEmpty) {
      setState(() {});
      return;
    }

    chatList.forEach((userDetail) {
      // for (int i = 0; i < chatList.length; i++) {
      if (userDetail['name'].toLowerCase().contains(text.toLowerCase())
          // ||chatList[i]['name'].toLowerCase().contains(text.toLowerCase())
          ) _searchResult.add(userDetail);
      // }
    });

    setState(() {});
  }
}

List _searchResult = [];
