import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:diemchat/Screens/groupChat/voiceCall.dart';
import 'package:diemchat/Screens/widgets/show_info.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../constatnt/global.dart';
import '../../helper/sizeconfig.dart';
import '../chat.dart';
import '../contactinfo.dart';
import 'get_credits.dart';

class UserPreviewDialog extends StatefulWidget {
  String userId;
  String userToken;
  String userImage;
  String userName;
  String userPhone;
  UserPreviewDialog(
      {@required this.userId,
      @required this.userImage,
      @required this.userPhone,
      @required this.userToken,
      @required this.userName});

  @override
  State<UserPreviewDialog> createState() => _UserPreviewDialogState();
}

class _UserPreviewDialogState extends State<UserPreviewDialog> {
  FirebaseAuth _auth = FirebaseAuth.instance;
  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Container(
        height: SizeConfig.safeBlockVertical * 100,
        width: SizeConfig.screenWidth,
        child: Column(
          children: <Widget>[
            Container(
                decoration: new BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: new BorderRadius.only(
                      topLeft: const Radius.circular(30.0),
                      topRight: const Radius.circular(30.0),
                    )),
                height: SizeConfig.safeBlockVertical * 30,
                width: SizeConfig.screenWidth,
                child: ClipRRect(
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(30.0),
                      topLeft: Radius.circular(30.0)),
                  child: widget.userImage.length > 0
                      ? Image.network(
                          widget.userImage,
                          fit: BoxFit.cover,
                        )
                      : Icon(
                          Icons.person,
                          color: Colors.black,
                          size: 50,
                        ),
                )),
            Material(
              borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(30.0),
                  bottomLeft: Radius.circular(30.0)),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(30.0),
                      bottomLeft: Radius.circular(30.0)),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(left: 20, top: 8),
                      child: Text(
                        widget.userName,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: SizeConfig.blockSizeVertical * 2.5,
                            fontFamily: 'Montserrat'),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 20, top: 10),
                      child: Text(
                        widget.userPhone,
                        style: TextStyle(
                            fontSize: SizeConfig.blockSizeVertical * 2,
                            color: Colors.grey,
                            fontFamily: 'Montserrat'),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: <Widget>[
                        widget.userPhone == ""
                            ? Container()
                            : RawMaterialButton(
                                onPressed: () {
                                  Navigator.of(context, rootNavigator: true)
                                      .pop();

                                  Navigator.push(
                                      context,
                                      CupertinoPageRoute(
                                          builder: (context) => Chat(
                                                peerID: widget.userId,
                                                currentUserId:
                                                    _auth.currentUser.uid,
                                              )));
                                },
                                elevation: 1,
                                fillColor: Colors.white,
                                child: Image.asset(
                                  "assets/images/chat.png",
                                  height: 27,
                                  color: appColorBlue,
                                ),
                                shape: CircleBorder(),
                              ),
                        RawMaterialButton(
                          onPressed: () {
                            showDialog(
                                context: context,
                                builder: (context) {
                                  return GetCredits(
                                    peerToken: widget.userToken,
                                    userId: widget.userId,
                                    userName: widget.userName,
                                  );
                                });
                          },
                          elevation: 1,
                          fillColor: Colors.white,
                          child: Image.asset(
                            'assets/stickers/gift.png',
                            width: 25,
                            height: 25,
                            color: appColorBlue,
                          ),
                          shape: CircleBorder(),
                        ),
                        _auth.currentUser.email != 'admin@admin.com'
                            ? RawMaterialButton(
                                onPressed: () {
                                  showGeneralDialog(
                                    barrierDismissible: true,
                                    barrierLabel: "Barrier",
                                    barrierColor: Colors.black.withOpacity(0.5),
                                    transitionDuration:
                                        Duration(milliseconds: 700),
                                    context: context,
                                    pageBuilder: (_, __, ___) {
                                      return ShowReportDialog(
                                        userId: widget.userId,
                                      );
                                    },
                                    transitionBuilder: (_, anim, __, child) {
                                      return SlideTransition(
                                        position: Tween(
                                                begin: Offset(0, 1),
                                                end: Offset(0, 0))
                                            .animate(anim),
                                        child: child,
                                      );
                                    },
                                  );
                                },
                                elevation: 1,
                                fillColor: Colors.white,
                                child: Image.asset(
                                  'assets/images/report.png',
                                  width: 20,
                                  height: 20,
                                  color: appColorBlue,
                                ),
                                shape: CircleBorder(),
                              )
                            : RawMaterialButton(
                                onPressed: () {
                                  showInfoDialog(context,
                                      'Kullanıcıyı banlamak istiyor musun?',
                                      () {
                                    FirebaseFirestore.instance
                                        .collection('users')
                                        .doc(widget.userId)
                                        .update({'banned': true});
                                  });
                                },
                                elevation: 1,
                                fillColor: Colors.white,
                                child: Icon(
                                  Icons.app_blocking,
                                  color: appColorBlue,
                                ),
                                shape: CircleBorder(),
                              ),
                        widget.userPhone == ""
                            ? Container()
                            : RawMaterialButton(
                                onPressed: () {
                                  Navigator.of(context, rootNavigator: true)
                                      .pop();
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => ContactInfo(
                                              id: widget.userId,
                                              currentUser:
                                                  _auth.currentUser.uid,
                                            )),
                                  );
                                },
                                elevation: 1,
                                fillColor: Colors.white,
                                child: Icon(
                                  Icons.info,
                                  size: 25.0,
                                  color: appColorBlue,
                                ),
                                shape: CircleBorder(),
                              )
                      ],
                    )
                  ],
                ),
              ),
            )
          ],
        ),
        margin: EdgeInsets.only(bottom: 45, left: 18, right: 18, top: 200),
      ),
    );
  }
}
