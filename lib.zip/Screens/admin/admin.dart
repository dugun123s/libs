import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dashed_circle/dashed_circle.dart';
import 'package:diemchat/Screens/widgets/show_info.dart';
import 'package:diemchat/constatnt/Constant.dart';
import 'package:diemchat/constatnt/global.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../contactinfo.dart';

class Admin extends StatefulWidget {
  @override
  State<Admin> createState() => _AdminState();
}

class _AdminState extends State<Admin> {
  FirebaseAuth _auth = FirebaseAuth.instance;
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: bgcolor,
        appBar: AppBar(
          backgroundColor: Colors.white,
          leading: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: Icon(
                Icons.arrow_back,
                color: appColor,
              )),
          title: Text(
            'Admin Panel',
            style: TextStyle(color: appColor, fontFamily: 'MontserratBold'),
          ),
          centerTitle: true,
          bottom: const TabBar(
            labelStyle: TextStyle(color: appColor, fontWeight: FontWeight.bold),
            labelColor: appColor,
            indicatorColor: appColor,
            tabs: [
              Tab(
                text: 'Banli Kullanicilar',
              ),
              Tab(
                text: 'Şikayetler',
              ),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('users')
                    .where('banned', isEqualTo: true)
                    .snapshots(),
                builder: (context, snapshot) {
                  print('snapshot');
                  if (snapshot.hasData) {
                    return ListView.builder(
                        padding: const EdgeInsets.all(0),
                        itemCount: snapshot.data.docs.length,
                        itemBuilder: (BuildContext context, int index) {
                          DocumentSnapshot doc = snapshot.data.docs[index];
                          return Container(
                              color: Colors.white,
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8.0, vertical: 15),
                                child: Column(
                                  children: [
                                    ListTile(
                                      onTap: () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) => ContactInfo(
                                                    id: doc.id,
                                                    currentUser:
                                                        _auth.currentUser.uid,
                                                  )),
                                        );
                                      },
                                      onLongPress: () {
                                        showInfoDialog(context,
                                            'Kullanıcının banını kaldırmak istiyor musun?',
                                            () {
                                          FirebaseFirestore.instance
                                              .collection('users')
                                              .doc(doc.id)
                                              .update({'banned': false});
                                        });
                                      },
                                      leading: InkWell(
                                        child: DashedCircle(
                                          gapSize: 40,
                                          dashes: 20,
                                          strokeWidth: 20,
                                          color: Colors.red,
                                          child: Padding(
                                            padding: const EdgeInsets.all(1.0),
                                            child: CircleAvatar(
                                              radius: 25,
                                              foregroundColor: Theme.of(context)
                                                  .primaryColor,
                                              backgroundColor: Colors.grey,
                                              backgroundImage: new NetworkImage(
                                                doc["photo"],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      title: Text(
                                        doc["nick"],
                                        style: TextStyle(
                                            fontSize: 19,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      subtitle: Padding(
                                        padding: const EdgeInsets.only(top: 5),
                                        child: Text(
                                          doc["bio"],
                                          style: TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ));
                        });
                  } else {
                    return Center(
                      child: CircularProgressIndicator(color: appColor),
                    );
                  }
                }),
            StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('users')
                    .where('complains', isNotEqualTo: []).snapshots(),
                builder: (context, snapshot) {
                  print('snapshot');
                  if (snapshot.hasData) {
                    return ListView.builder(
                        padding: const EdgeInsets.all(0),
                        itemCount: snapshot.data.docs.length,
                        itemBuilder: (BuildContext context, int index) {
                          DocumentSnapshot doc = snapshot.data.docs[index];
                          return Container(
                              color: Colors.white,
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8.0, vertical: 0),
                                child: Column(
                                  children: [
                                    ListTile(
                                      onTap: () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) => ContactInfo(
                                                    id: doc.id,
                                                    currentUser:
                                                        _auth.currentUser.uid,
                                                  )),
                                        );
                                      },
                                      onLongPress: () {
                                        showInfoDialog(context,
                                            'Kullanıcının banını kaldırmak istiyor musun?',
                                            () {
                                          FirebaseFirestore.instance
                                              .collection('users')
                                              .doc(doc.id)
                                              .update({'banned': false});
                                        });
                                      },
                                      leading: InkWell(
                                        onTap: () {
                                          // showUserDialog(
                                          //   context,
                                          //   doc["nick"],
                                          //   doc["photo"],
                                          //   doc["bio"],
                                          //   doc.id,
                                          // );
                                        },
                                        child: DashedCircle(
                                          gapSize: 40,
                                          dashes: 20,
                                          strokeWidth: 20,
                                          color: Colors.red,
                                          child: Padding(
                                            padding: const EdgeInsets.all(1.0),
                                            child: CircleAvatar(
                                              radius: 25,
                                              foregroundColor: Theme.of(context)
                                                  .primaryColor,
                                              backgroundColor: Colors.grey,
                                              backgroundImage: new NetworkImage(
                                                doc["photo"],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      title: Text(
                                        doc["nick"],
                                        style: TextStyle(
                                            fontSize: 19,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      subtitle: Padding(
                                        padding: const EdgeInsets.only(
                                            top: 5, bottom: 5),
                                        child: Text(
                                          doc["bio"],
                                          style: TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 10),
                                      child: Divider(
                                        color: Colors.grey.shade300,
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 15),
                                      child: Container(
                                        alignment: Alignment.centerLeft,
                                        child: Text(
                                          'Şikayet Edenler',
                                          style: TextStyle(
                                              fontSize: 15,
                                              color: appColor,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      height: snapshot.data
                                              .docs[index]['complains'].length *
                                          150.toDouble(),
                                      child: ListView.builder(
                                          itemCount: snapshot.data
                                              .docs[index]['complains'].length,
                                          itemBuilder: (BuildContext context,
                                              int index2) {
                                            var doc = snapshot.data.docs[index]
                                                ['complains'][index2];
                                            return UserPreviewComplaint(
                                              reasons: jsonDecode(snapshot.data
                                                      .docs[index]['complains']
                                                  [index2]['reasons']),
                                              userId:
                                                  snapshot.data.docs[index].id,
                                              complaint:
                                                  snapshot.data.docs[index]
                                                      ['complains'][index2],
                                            );
                                          }),
                                    ),
                                    Divider()
                                  ],
                                ),
                              ));
                        });
                  } else {
                    return Center(
                      child: CircularProgressIndicator(color: appColor),
                    );
                  }
                }),
          ],
        ),
      ),
    );
  }
}

class UserPreviewComplaint extends StatefulWidget {
  var complaint;
  String userId;
  List reasons;
  UserPreviewComplaint(
      {@required this.complaint,
      @required this.reasons,
      @required this.userId});

  @override
  State<UserPreviewComplaint> createState() => _UserPreviewComplaintState();
}

class _UserPreviewComplaintState extends State<UserPreviewComplaint> {
  Future getUser() async {
    await FirebaseFirestore.instance
        .collection('users')
        .doc(widget.complaint['userId'])
        .get()
        .then((value) {
      setState(() {
        userName = value['nick'];
        userphoto = value['photo'];
        userBio = value['bio'];
      });
    });
  }

  void didUpdateWidget(covariant UserPreviewComplaint oldWidget) {
    if (oldWidget.complaint['userId'] != widget.complaint['userId']) {
      getUser();
    }
    super.didUpdateWidget(oldWidget);
  }

  String userName;
  String userBio;
  String userphoto;
  @override
  void initState() {
    print(widget.reasons);
    getUser();
    // TODO: implement initState
    super.initState();
  }

  FirebaseAuth _auth = FirebaseAuth.instance;
  @override
  Widget build(BuildContext context) {
    if (userBio == '') {
      return Container();
    }
    return Container(
        color: Colors.white,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 5),
          child: InkWell(
            onLongPress: () {
              showInfoDialog(context, 'Bu şikayeti kaldırmak istiyor musun?',
                  () {
                FirebaseFirestore.instance
                    .collection('users')
                    .doc(widget.userId)
                    .update({
                  'complains': FieldValue.arrayRemove([widget.complaint])
                });
              });
            },
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => ContactInfo(
                          id: widget.complaint['userId'],
                          currentUser: _auth.currentUser.uid,
                        )),
              );
            },
            child: Column(
              children: [
                ListTile(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => ContactInfo(
                                id: widget.complaint['userId'],
                                currentUser: _auth.currentUser.uid,
                              )),
                    );
                  },
                  onLongPress: () {
                    showInfoDialog(
                        context, 'Bu şikayeti kaldırmak istiyor musun?', () {
                      FirebaseFirestore.instance
                          .collection('users')
                          .doc(widget.userId)
                          .update({
                        'complains': FieldValue.arrayRemove([widget.complaint])
                      });
                    });
                  },
                  leading: InkWell(
                    child: DashedCircle(
                      gapSize: 40,
                      dashes: 20,
                      strokeWidth: 20,
                      color: Colors.red,
                      child: Padding(
                        padding: const EdgeInsets.all(1.0),
                        child: CircleAvatar(
                          radius: 25,
                          foregroundColor: Theme.of(context).primaryColor,
                          backgroundColor: Colors.grey,
                          backgroundImage: new NetworkImage(userphoto),
                        ),
                      ),
                    ),
                  ),
                  title: Text(
                    userName,
                    style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
                  ),
                  subtitle: Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: Text(
                      userBio,
                      overflow: TextOverflow.ellipsis,
                      style:
                          TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Container(
                  height: 75,
                  child: ListView.builder(
                      physics: NeverScrollableScrollPhysics(),
                      padding: const EdgeInsets.all(0),
                      itemCount: widget.reasons.length,
                      itemBuilder: (BuildContext context, int index) {
                        return Container(
                            color: Colors.white,
                            child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8.0, vertical: 5),
                                child: Container(
                                  child: Text(
                                    widget.reasons[index],
                                    style: TextStyle(color: appColor),
                                  ),
                                )));
                      }),
                )
              ],
            ),
          ),
        ));
  }
}
